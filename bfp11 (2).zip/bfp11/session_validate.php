<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['username']) || !isset($_SESSION['userlevel'])) {
    header("Location: login.php?error=Please login to access this page");
    exit();
}
?>
