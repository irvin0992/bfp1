<div class="nav-left-sidebar sidebar-dark" style="background-color:#b92828;">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="../admin/admindashboard.php">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="../marshall/marshalldashboard.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;"><i class="fa fa-fw fa-file-word"></i>Dashboard <span class="badge badge-success">6</span></a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="displaymarshallinspection.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;"><i class='bx bx-street-view' ></i> Inspections Management<span class="badge badge-success">6</span></a>
                            </li>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="displayFSIC.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;"><i class="fa fa-fw fa-file"></i> Fire Safety Permit<span class="badge badge-success">6</span></a>
                            </li>
                    </div>
                </nav>
            </div>
        </div>