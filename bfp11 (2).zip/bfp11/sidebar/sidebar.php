<div class="nav-left-sidebar sidebar-dark" style="background-color:#b92828;">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="../admin/admindashboard.php">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider"></li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/admindashboard.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                            <i class="fa fa-fw fa-tachometer-alt"></i>Dashboard <span class="badge badge-success">6</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/displayusers.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                            <i class="fa fa-fw fa-user-lock"></i>User Management<span class="badge badge-success">6</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/displayapplication.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                            <i class="fa fa-fw fa-file-word"></i>Application Management<span class="badge badge-success">6</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" style="background-color: #b92828; font-family: 'Poppins',sans-serif;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-inspections" aria-controls="submenu-inspections">
                        <i class='bx bx-street-view' ></i></i>Inspection Management
                        </a>
                        <div id="submenu-inspections" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/pending.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Pending
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/passed.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Passed
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/ReadyforInspection.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Ready for Inspection
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/ReadyforReinspection.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Ready for Reinspection
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/Reinspection.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Reinspection
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/forApproval.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    For Approval
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/approved.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    Approved
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="../admin/displayFSIC.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                            <i class="fa fa-fw fa-file"></i>Fire Safety Permit<span class="badge badge-success">6</span>
                        </a>
                    </li>

                    <!-- Dropdown for Generate Report -->
                    <li class="nav-item">
                        <a class="nav-link" href="#" style="background-color: #b92828; font-family: 'Poppins',sans-serif;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-report" aria-controls="submenu-report">
                        <i class='bx bxs-report' ></i></i>Generate Report
                        </a>
                        <div id="submenu-report" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="../ReportGen/Report_Gen_Application.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    <i class='bx bxs-report' ></i></i>Application Management
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../ReportGen/Report_Gen_Inspection.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    <i class='bx bxs-report' ></i></i>Inspections Management
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <!-- Fixed Dropdown for Utilities -->
                    <li class="nav-item">
                        <a class="nav-link" href="#" style="background-color: #b92828; font-family: 'Poppins',sans-serif;" data-toggle="collapse" aria-expanded="false" data-target="#submenu-utilities" aria-controls="submenu-utilities">
                            <i class="fa fa-fw fa-cogs"></i>Utilities
                        </a>
                        <div id="submenu-utilities" class="collapse submenu">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="../backup.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                        <i class="fa fa-fw fa-database"></i>Backup
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/restore.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    <i class='bx bx-refresh' ></i></i>Restore
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/activtylog.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                    <i class='bx bx-dots-vertical-rounded'></i> Activity Log
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../admin/help.php" style="background-color: #b92828; font-family: 'Poppins',sans-serif;">
                                        <i class="fa fa-fw fa-question-circle"></i>Help
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
