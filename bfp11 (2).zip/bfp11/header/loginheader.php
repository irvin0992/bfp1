<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/buttons.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/select.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/fixedHeader.bootstrap4.css">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background-image: url('Images/bfp2.jpeg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
            margin-top: 70px; /* Adjust if needed for header height */
        }
        .custom-container {
            border: 4px solid #b92828;
        }
        .header-container {
            background: linear-gradient(135deg, #b92828, #ff6347); /* Changed gradient direction and colors */
            color: white;
            padding: 5px;
            width: 100%;
        }
        .header-container img {
            height: 80px; /* Adjust the height as needed */
        }
        .header-container .header-title {
            margin-left: 10px;
            font-size: 35px;
        }

        .header-nav {
            display: flex;
            justify-content: flex-end;
        }
        .header-nav ul {
            display: flex;
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .header-nav ul li {
            margin-left: 7px;
        }
        .header-nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .header-nav ul li a:hover {
            background: #fff;
            color: black;
        }
        
        .tracking-form {
            display: flex;
            align-items: center;
        }

        .tracking-form input[type="text"] {
            width: 200px;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            margin-right: 5px;
        }

        .tracking-form button {
            background-color: #fff;
            color: #b92828;
            border: 1px solid #b92828;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .tracking-form button:hover {
            background-color: #b92828;
            color: #fff;
        }
    </style>
</head>
<body class="text-white bg-dark">
<!-- Header Section -->
<div class="container-fluid fixed-top header-container">
    <div class="row align-items-center">
        <div class="col-auto">
            <img src="Images/bfp-logo.png" alt="Logo">
        </div>
        <div class="col">
            <h1 class="header-title" style="font-family: 'Poppins', sans-serif; font-weight: semi-bold;">Bureau of Fire Protection</h1>
        </div>
        <div class="col header-nav">
            <ul>
                <li><a href="login.php">Login</a></li>
                <li><a href="index.php">Home</a></li>
            </ul>
        </div>
    </div>
</div>

<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function () {
        $('#trackButton').on('click', function () {
            var trackingNumber = $('#trackingNumber').val().trim();
            if (trackingNumber === '') {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please enter a tracking number!',
                });
            } else {
                // Perform AJAX request to check if tracking number exists
                $.ajax({
                    url: 'check_tracking.php', // Replace with your actual PHP script to check tracking number
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        trackingNumber: trackingNumber
                    },
                    success: function (response) {
                        if (response.exists) {
                            // Tracking number exists, redirect to requirements.php
                            window.location.href = 'requirements.php?trackingNumber=' + trackingNumber;
                        } else {
                            // Tracking number does not exist
                            Swal.fire({
                                icon: 'error',
                                title: 'Tracking Number Not Found',
                                text: 'The tracking number does not exist in our records.',
                            });
                        }
                    },
                    error: function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong while checking the tracking number!',
                        });
                    }
                });
            }
        });
    });
</script>
</body>
</html>
