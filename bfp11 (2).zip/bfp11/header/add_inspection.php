<?php

include '../connection.php'; // Ensure this is the correct path to your DB connection file
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_GET['application_id'])) {
    $applicationId = intval($_GET['application_id']); // Sanitize application_id as an integer

    // Query to fetch relevant details like email, business name, and FSIC expiry
    $fetchSql = "
        SELECT 
            a.email, 
            b.business_name, 
            a.FSIC_expiry 
        FROM 
            tbl_applications a
        JOIN 
            tbl_businesses b 
        ON 
            a.business_id = b.business_id 
        WHERE 
            a.application_id = $applicationId";

    $result = $conn->query($fetchSql);

    if ($result && $result->num_rows > 0) {
        // Fetch the result as an associative array
        $row = $result->fetch_assoc();
        $applicantEmail = $row['email'];
        $businessName = $row['business_name'];
        $FsicExpiry = $row['FSIC_expiry'];

        // Update query to set notification to 1 for the specified application_id
        $updateSql = "UPDATE tbl_applications SET notification = 1 WHERE application_id = $applicationId";

        // Execute the update query
        if ($conn->query($updateSql) === TRUE) {
            // Send email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'bfp.sflu@gmail.com'; // Replace with your Gmail
                $mail->Password   = 'dxjg cfci fpvc yqjr';   // Replace with your app password
                $mail->SMTPSecure = 'ssl';
                $mail->Port       = 465;

                // Recipient
                $mail->setFrom('bfp.sflu@gmail.com', 'Bureau of Fire Protection'); // Replace with your Gmail and name
                $mail->addAddress($applicantEmail); // Send to the applicant's email fetched from the database

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Business FSIC Expiry';
                $mail->Body = "
                <div style='font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;'>
                    <div style='background-color: #001f3f; padding: 15px; border-radius: 5px; text-align: center;'>
                        <h1 style='color: #fff; margin: 0;'>FSIC Expiry Notice</h1>
                    </div>
                    <div style='background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;'>
                        <p style='font-size: 16px; color: #001f3f;'>Dear {$businessName},</p>
                        <p style='font-size: 16px; color: #001f3f;'>Your FSIC is expiring on <strong>{$FsicExpiry}</strong>.</p>
                        <p style='font-size: 16px; color: #001f3f;'>Please ensure to take necessary actions before this date.</p>
                        <p style='font-size: 14px; color: #777;'>Regards, <br> Bureau of Fire Protection</p>
                    </div>
                    <div style='text-align: center; font-size: 12px; color: #999; margin-top: 20px;'>
                        <p>This is an automated message. Please do not reply to this email.</p>
                    </div>
                </div>";
                // Send email
                $mail->send();
                // If the email was sent successfully, redirect to displayinspection.php
                header("Location: ../admin/displayinspection.php?application_id={$applicationId}");
                exit(); // Make sure to exit after the redirect
            } catch (Exception $e) {
                // Handle email sending failure
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            // If the query fails, handle the error (you can redirect to an error page or display an error message)
            echo "Error updating notification: " . $conn->error;
        }
    } else {
        // Handle case where no application is found for the given ID
        echo "Application not found.";
    }

} else {
    // Handle missing or invalid application ID
    echo "Invalid application ID.";
}

// Close the database connection
$conn->close();
?>
