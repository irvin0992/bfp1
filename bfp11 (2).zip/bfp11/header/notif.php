<?php

ob_start(); // Start output buffering
include '../connection.php'; // Ensure this is the correct path to your DB connection file
header('Content-Type: application/json'); // Set the content type to JSON

// $currentDate = date('Y-m-d');
// $oneMonthLater = date('Y-m-d', strtotime('+1 month'));

// Query to get applications expiring within the next month
$sql = "
    SELECT * 
    FROM tbl_applications AS a
    JOIN tbl_businesses AS b ON a.business_id = b.business_id
    WHERE a.FSIC_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
    AND a.notification = 0
";

$result = $conn->query($sql);

$notifications = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Generate a URL that redirects to displayinspection.php with a query parameter for business_name
        $businessName = urlencode($row['business_name']);
        $inspectionUrl = "displayinspection.php?business_name={$businessName}";

        $notifications[] = [
            'description' => "FSIC for {$row['business_name']} expiring on {$row['FSIC_expiry']}",
            'url' => "../header/add_inspection.php?application_id={$row['application_id']}" // Add application_id to the URL
        ];
    }
}

echo json_encode($notifications);
ob_end_flush(); // Flush the output buffer
?>
