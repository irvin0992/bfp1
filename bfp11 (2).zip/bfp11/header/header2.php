<?php
include '../connection.php'; // Ensure this is the correct path to your DB connection file
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/buttons.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/select.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/fixedHeader.bootstrap4.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Integrated Fire Safety Compliance Management System</title>
    <style>
        ul.navbar-nav li a {
            color: rgb(207, 214, 200) !important;
        }

        ul.navbar-nav li a i {
            color: rgb(207, 214, 200) !important;
        }

        .navbar-brand {
            color: rgb(255, 55, 0) !important;
        }
   /* Dropdown menu customization for better visibility */
   .dropdown-menu-scrollable {
        max-height: 300px; /* Limit the height to prevent overflow */
        overflow-y: auto; /* Enable vertical scrolling */
        width: 300px; /* Adjust the width as needed */
        position: absolute; /* Position the dropdown relative to the parent */
    }

    /* Ensuring the dropdown is properly positioned */
    .navbar .dropdown-menu {
        top: 50px; /* Adjust to position the dropdown menu below the icon */
        left: auto;
        right: 0; /* Align to the right of the screen */
    }

        /* Profile image */
        #profileImage {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #013701;
            font-size: 16px;
            color: #fff;
            text-align: center;
            line-height: 41px;
            margin: 0px 0;
        }
    </style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg fixed-top"
                style="background-color: #b92828; background: linear-gradient(135deg, #b92828, #ff6347);">
                <img src="../Images/bfp-logo.png" alt="image"
                    style="height: 60px; align-items: center; margin-left: 15px; margin-top: 5px; margin-bottom: 5px;">
                <header style="background-image:url(../Images/bfp-logo.png) height: 70px; align-items: center;">
                    <div class="container">
                        <div class="column col100">
                            <div id="schoolinfo">
                                <div id="schoolheader"
                                    style="font-family: 'Poppins',sans-serif; color: #FFFFFF; font-size: 125%;">
                                    Integrated Fire Safety Compliance Management System</div>
                                <div id="schoolheader"
                                    style="font-family: 'Poppins',sans-serif; color: #FFFFFF; font-size: 110%;">Bureau
                                    of Fire Protection</div>

                            </div>
                        </div>
                    </div>
                </header>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <ul class="navbar-nav ml-auto navbar-right-top">
                           
                        
                            <li class="nav-item dropdown nav-user">
                                <a class="nav-link nav-user-img" style="color: #013701;" href="#" id="logoutLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <div id="profileImage"></div>
                                    <!-- <img src="../assets/images/256-128.webp" alt="" class="user-avatar-md rounded-circle"> -->
                                </a>
                                <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                                    aria-labelledby="navbarDropdownMenuLink2">
                                    <div class="nav-user-info"
                                        style="background-color: #b92828; border-radius: 10px; width: 200px;">
                                        <h5 class="mb-0 text-white nav-user-name" style="font-size: 125%;">
                                            <?php
                                            if (isset($_SESSION['userlevel'])) {
                                                echo 'Logged in as ' . htmlspecialchars($_SESSION['username']);
                                            }
                                            ?>
                                        </h5> <br>
                                        <a href="#" onclick="confirmLogout()"><i class="fas fa-power-off mr-2"></i><span
                                                class="ml-3">Logout</span></a>

                                    </div>
                                </div>
                            </li>
                        </ul>
                </div>
            </nav>

        </div>

        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
    </div>


    <script>
  function fetchNotifications() {
    fetch('../header/notif.php') // Ensure this is the correct path to your PHP file
        .then(response => response.json())
        .then(data => {
            const notificationList = document.getElementById('notificationList');
            const countBadge = document.querySelector('.count');
            notificationList.innerHTML = ''; // Clear existing notifications

            let count = 0;
            if (data.length > 0) {
                data.forEach(notification => {
                    const li = document.createElement('li');
                    // Add the notification description and set the URL as the href
                    li.innerHTML = `<a class="dropdown-item" href="${notification.url}">${notification.description}</a>`;
                    notificationList.appendChild(li);
                    count++;
                });
            } else {
                const li = document.createElement('li');
                li.innerHTML = `<a class="dropdown-item" href="#">No notifications</a>`;
                notificationList.appendChild(li);
            }

            // Update the badge count
            countBadge.textContent = count;
        })
        .catch(error => console.error('Error fetching notifications:', error));
  }

  // Fetch notifications every 5 seconds
  setInterval(fetchNotifications, 5000);
  fetchNotifications();
</script>



</script>

    <script>

        // Logout confirmation function
        function confirmLogout() {
            Swal.fire({
                title: 'Are you sure?',
                text: "You will be logged out!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Logout'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Logout Successfully',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function () {
                        window.location.href = '../login.php';
                    });
                }
            });
        }
    </script>
</body>

</html>