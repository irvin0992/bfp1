function fetchNotifications() {
    fetch('notif.php')
        .then(response => response.json())
        .then(data => {
            const notificationList = document.getElementById('notificationList');
            const countBadge = document.querySelector('.count');
            notificationList.innerHTML = ''; // Clear existing notifications

            let count = 0;
            if (data.length > 0) {
                data.forEach(notification => {
                    const li = document.createElement('li');
                    li.innerHTML = `<a class="dropdown-item" href="#">${notification.description}</a>`;
                    notificationList.appendChild(li);
                    count++;
                });
            } else {
                const li = document.createElement('li');
                li.innerHTML = `<a class="dropdown-item" href="#">No notifications</a>`;
                notificationList.appendChild(li);
            }

            // Update the badge count
            countBadge.textContent = count;
        })
        .catch(error => console.error('Error fetching notifications:', error));
}

// Fetch notifications every 5 seconds
setInterval(fetchNotifications, 5000);
fetchNotifications();