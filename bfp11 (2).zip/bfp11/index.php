
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../assets/libs/css/style.css">
<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
<link rel="stylesheet" href="../assets/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/buttons.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/select.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="../assets/vendor/datatables/css/fixedHeader.bootstrap4.css">
<title>Integrated Fire Safety Compliance Management System</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
<style>
    body {
        font-family: "Poppins" , sans-serif;
        background-image: url('Images/bfp2.jpeg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 30px;
        margin-top: 70px;
    }
    .custom-container {
        border: 4px solid #b92828;
    }
    .header-container {
        background-color: #b92828;
        color: white;
        background: linear-gradient(135deg, #b92828, #ff6347);
        padding: 5px;
        width: 100%;
    }
    .header-container img {
        height: 80px;
    }
    .header-container .header-title {
        margin-left: 10px;
        font-size: 35px;
    }
    .header-nav {
        display: flex;
        justify-content: flex-end;
    }
    .header-nav ul {
        display: flex;
        margin: 0;
        padding: 0;
        list-style: none;
    }
    .header-nav ul li {
        margin-left: 7px;
    }
    .header-nav ul li a {
        text-decoration: none;
        color: #fff;
        font-size: 18px;
        font-weight: 500;
        padding: 8px 15px;
        border-radius: 5px;
        transition: all 0.3s ease;
    }
    .header-nav ul li a:hover {
        background: #fff;
        color: black;
    }
    .center {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
    }
    .center .logo {
        margin-bottom: 20px;
    }
    .center .logo img {
        margin-top: 35px;
        max-width: 160px;
        height: auto;
    }
    .center .title {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        /* font-family: "Arial" , sans-serif; */
        color: #fff;
        font-size: 40px;
        font-weight: 1000;
    }
    .center .sub_title {
        color: #fff;
        font-size: 23px;
        font-weight: 400;
    }
    .center .btns {
        margin-top: 20px;
    }
    .center .btns button {
        height: 55px;
        width: 170px;
        border-radius: 5px;
        border: none;
        margin: 0 10px;
        border: 2px solid white;
        font-size: 20px;
        font-weight: 500;
        padding: 0 10px;
        cursor: pointer;
        outline: none;
        transition: all 0.3s ease;
    }
    .center .btns button:first-child {
        color: #fff;
        background: none;
    }
    .btns button:first-child:hover {
        background: white;
        color: black;
    }
    .center .btns button:last-child {
        background: white;
        color: black;
    }
</style>
</head>
<?php include('header/loginheader.php');?>
<body class="text-white bg-dark">
<!-- Header Section -->
<!-- <div class="container-fluid fixed-top header-container">
    <div class="row align-items-center">
        <div class="col-auto">
            <img src="Images/bfp-logo.png" alt="Logo">
        </div>
        <div class="col">
            <h1 class="header-title" style="  font-family: 'Poppins' , sans-serif; font-weight: semi-bold;">Bureau of Fire Protection</h1>
        </div>
        <div class="col header-nav">
            <ul>
                <li><a href="index.php">Registration</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="">Help</a></li>
                <li><a href="index.php">Home</a></li>
            </ul>
        </div>
    </div>
</div> -->
<div class="center">
    <div class="logo">
        <img src="Images/bfp-logo.png" alt="Logo">
    </div>
    <div class="title">Integrated Fire Safety Compliance Management System.</div>
    <div class="sub_title">Bureau of Fire Protection</div>
    <div class="sub_title">City of San Fernando La Union</div>
    <div class="btns">
        <center><button onclick="window.location.href = 'login.php';">Login</button></center>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <!-- SweetAlert JS -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</body>
</html>
