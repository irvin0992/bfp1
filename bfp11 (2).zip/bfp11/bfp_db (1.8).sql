-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2024 at 11:22 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bfp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activity_log`
--

CREATE TABLE `tbl_activity_log` (
  `log_id` int(10) NOT NULL,
  `id` varchar(50) NOT NULL,
  `activity_type` enum('login','logout','insert','update') NOT NULL,
  `activity_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activity_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_activity_log`
--

INSERT INTO `tbl_activity_log` (`log_id`, `id`, `activity_type`, `activity_time`, `activity_desc`) VALUES
(15, '10000028', 'login', '2024-10-17 09:28:30', 'User logged in'),
(16, '10000028', 'login', '2024-10-17 09:32:38', 'User logged in'),
(17, '10000028', 'login', '2024-10-17 09:41:16', 'User logged in'),
(18, '10000028', 'logout', '2024-10-17 09:45:36', 'User logged out'),
(19, '10000028', 'login', '2024-10-17 09:45:58', 'User logged in'),
(20, '10000028', 'logout', '2024-10-17 09:46:03', 'User logged out'),
(21, '10000031', 'login', '2024-10-17 09:47:16', 'User logged in'),
(22, '10000028', 'login', '2024-10-17 09:47:31', 'User logged in'),
(23, '10000032', 'insert', '2024-10-17 09:51:57', 'User registered: Admin2'),
(24, '10000033', 'insert', '2024-10-17 09:54:11', 'User registered: Admin3'),
(25, '10000035', 'insert', '2024-10-17 10:04:10', 'User registered: City Fire Marshalls'),
(26, '10000031', 'login', '2024-10-17 10:25:19', 'User logged in'),
(27, '10000035', 'login', '2024-10-17 11:48:38', 'User logged in'),
(28, '10000035', 'logout', '2024-10-18 07:52:45', 'User logged out'),
(29, '10000031', 'login', '2024-10-18 07:53:53', 'User logged in'),
(30, '10000028', 'login', '2024-10-18 08:23:21', 'User logged in'),
(31, '10000031', 'login', '2024-10-18 08:24:06', 'User logged in'),
(32, '10000028', 'login', '2024-10-18 09:04:41', 'User logged in'),
(33, '10000031', 'login', '2024-10-18 09:05:43', 'User logged in'),
(34, '10000035', 'login', '2024-10-18 09:17:53', 'User logged in'),
(35, '10000035', 'logout', '2024-10-18 09:23:01', 'User logged out'),
(36, '10000028', 'login', '2024-10-18 09:29:08', 'User logged in'),
(37, '10000031', 'login', '2024-10-18 09:46:19', 'User logged in'),
(38, '10000028', 'login', '2024-10-18 11:33:27', 'User logged in'),
(39, '10000028', 'logout', '2024-10-18 11:33:34', 'User logged out'),
(40, '10000031', 'login', '2024-10-18 11:33:46', 'User logged in'),
(41, '10000031', 'login', '2024-10-18 11:48:26', 'User logged in'),
(42, '10000035', 'login', '2024-10-18 14:14:01', 'User logged in'),
(43, '10000035', 'logout', '2024-10-19 09:02:53', 'User logged out'),
(44, '10000031', 'login', '2024-10-19 09:03:01', 'User logged in'),
(45, '10000028', 'login', '2024-10-19 09:13:53', 'User logged in'),
(46, '10000028', 'logout', '2024-10-19 09:14:31', 'User logged out'),
(47, '10000031', 'login', '2024-10-19 09:14:50', 'User logged in'),
(48, '10000028', 'login', '2024-10-19 09:19:24', 'User logged in'),
(49, '10000028', 'logout', '2024-10-19 09:20:05', 'User logged out'),
(50, '10000035', 'login', '2024-10-19 09:20:23', 'User logged in'),
(51, '10000035', 'logout', '2024-10-19 09:20:51', 'User logged out'),
(52, '10000028', 'login', '2024-10-19 09:21:02', 'User logged in');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_applications`
--

CREATE TABLE `tbl_applications` (
  `application_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `requirements_file` varchar(255) DEFAULT NULL,
  `FSIC_expiry` date NOT NULL,
  `notification` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_applications`
--

INSERT INTO `tbl_applications` (`application_id`, `business_id`, `owner_id`, `building_id`, `email`, `requirements_file`, `FSIC_expiry`, `notification`) VALUES
(34, 131, 125, 108, 'pasionalexcole@gmail.com', '../Requirements/a20e4f92-61f0-488a-9d11-b9ed67756395.png', '2024-11-15', 1),
(35, 132, 126, 109, 'elefantemarkjay@gmail.com', '../Requirements/449522515_446528258351023_5700337348665471729_n.jpg', '2024-10-12', 1),
(37, 134, 128, 111, 'pasionalexcole@gmail.com', '../Requirements/448567083_358428020282461_9018958581242975613_n.jpg', '2024-11-17', 1),
(38, 135, 129, 112, 'kherbycampilla@gmail.com', '../Requirements/5228b379-9296-42de-bb92-9349c07f5816.jpg', '2024-12-25', 1),
(39, 136, 130, 113, 'kherbycampilla@gmail.com', '../Requirements/448927753_781373724019213_5548903270573943559_n.jpg', '2024-11-18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bbuilding_details`
--

CREATE TABLE `tbl_bbuilding_details` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) NOT NULL,
  `construction_type` varchar(20) DEFAULT NULL,
  `wall_type` varchar(10) DEFAULT NULL,
  `floor_type` varchar(10) DEFAULT NULL,
  `basement_usage` varchar(255) DEFAULT NULL,
  `ground_floor_usage` varchar(255) DEFAULT NULL,
  `second_floor_usage` varchar(255) DEFAULT NULL,
  `third_floor_usage` varchar(255) DEFAULT NULL,
  `nth_floor_usage` varchar(255) DEFAULT NULL,
  `occupant_load` int(11) DEFAULT NULL,
  `stories_num` int(11) DEFAULT NULL,
  `building_height` decimal(5,2) DEFAULT NULL,
  `mezzanine_type` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bhazards`
--

CREATE TABLE `tbl_bhazards` (
  `id` int(11) NOT NULL,
  `hazard_contents` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `hazard_pla` varchar(255) NOT NULL,
  `maq` enum('Yes','No') NOT NULL,
  `hazard_no` varchar(255) NOT NULL,
  `hazard_classification` enum('Low','Ordinary','High') NOT NULL,
  `class` varchar(255) NOT NULL,
  `flash_point` varchar(255) NOT NULL,
  `sealed_containers` enum('Passed','Failed') NOT NULL,
  `properly_dispensed` enum('Passed','Failed') NOT NULL,
  `no_smoking_sign` enum('Passed','Failed') NOT NULL,
  `no_smoking_area` enum('Passed','Failed') NOT NULL,
  `gasoline_storage` enum('passed','failed') NOT NULL,
  `HMSWresult_1` enum('passed','failed') NOT NULL,
  `HMSWresult_2` enum('passed','failed') NOT NULL,
  `HMSWresult_3` enum('passed','failed') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buildings`
--

CREATE TABLE `tbl_buildings` (
  `building_id` int(11) NOT NULL,
  `building_name` varchar(255) NOT NULL,
  `building_height` decimal(10,2) NOT NULL,
  `total_area` decimal(10,2) NOT NULL,
  `number_of_floors` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_buildings`
--

INSERT INTO `tbl_buildings` (`building_id`, `building_name`, `building_height`, `total_area`, `number_of_floors`) VALUES
(108, 'Building 1', '5.00', '2.00', 6),
(109, 'Building 1', '10.00', '3.00', 2),
(111, 'Building 1', '2.00', '2.00', 2),
(112, 'Robinson', '3.00', '6.00', 2),
(113, 'Robinsons', '3.00', '3.00', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_building_details`
--

CREATE TABLE `tbl_building_details` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `occupancy_type` varchar(255) DEFAULT NULL,
  `construction_type` varchar(255) DEFAULT NULL,
  `floor_area` decimal(10,2) DEFAULT NULL,
  `occupant_load` int(11) DEFAULT NULL,
  `building_height` int(11) DEFAULT NULL,
  `Stories_num` int(11) DEFAULT NULL,
  `Portion_Occupied` decimal(10,2) DEFAULT NULL,
  `mezzanine_type` varchar(10) DEFAULT NULL,
  `Handrails_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_building_details`
--

INSERT INTO `tbl_building_details` (`id`, `inspection_id`, `occupancy_type`, `construction_type`, `floor_area`, `occupant_load`, `building_height`, `Stories_num`, `Portion_Occupied`, `mezzanine_type`, `Handrails_type`) VALUES
(36, 35, 'Mercantile', 'timber', '3423.00', 2, 2, 2, '2.00', 'yes', 'yes'),
(43, 36, 'Residential', '', '3423.00', 2, 2, 2, '2.00', '', ''),
(45, 39, 'Mercantile', '', '3423.00', 12, 12, 1, '2.00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_businesses`
--

CREATE TABLE `tbl_businesses` (
  `business_id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `business_nature` varchar(255) NOT NULL,
  `occupancy_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_businesses`
--

INSERT INTO `tbl_businesses` (`business_id`, `business_name`, `district`, `barangay`, `business_nature`, `occupancy_type`) VALUES
(131, 'Kiffares', 'District IV', 'San Agustin', 'Gas Station', 'Mercantile'),
(132, 'kee fee pares', 'District X', 'Cadaclan', 'Gas Station', 'Residential'),
(134, 'tangina', 'District X', 'Cadaclan', 'Good and Services', 'Business'),
(135, 'Innapoyan', 'District X', 'Cadaclan', 'Good and Services', 'Mercantile'),
(136, 'Kaldingan ', 'District I', 'Barangay I', 'Good and Services', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_business_details`
--

CREATE TABLE `tbl_business_details` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `business_name` varchar(255) NOT NULL,
  `building_name` varchar(255) NOT NULL,
  `business_address` text NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `business_nature` varchar(255) NOT NULL,
  `policy_number` varchar(255) DEFAULT NULL,
  `pol_date_issued` date DEFAULT NULL,
  `fsic_number` varchar(255) DEFAULT NULL,
  `fsic_date_issued` date DEFAULT NULL,
  `fsec_number` varchar(255) DEFAULT NULL,
  `fsec_date_issued` date DEFAULT NULL,
  `building_permit` varchar(255) DEFAULT NULL,
  `rp_date_issued` date DEFAULT NULL,
  `bpermit_number` varchar(255) DEFAULT NULL,
  `bp_date_issued` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_business_details`
--

INSERT INTO `tbl_business_details` (`id`, `inspection_id`, `business_name`, `building_name`, `business_address`, `owner_name`, `contact_number`, `business_nature`, `policy_number`, `pol_date_issued`, `fsic_number`, `fsic_date_issued`, `fsec_number`, `fsec_date_issued`, `building_permit`, `rp_date_issued`, `bpermit_number`, `bp_date_issued`) VALUES
(34, 35, 'Kiffares', 'Building 1', 'District IV, San Agustin', 'Anne Lee Rice', '09288494666', 'Gas Station', '34543', '2024-10-17', '2345', '2024-10-17', '2345', '2024-10-17', '23243543', '2024-10-17', '1234543', '2024-10-17'),
(41, 36, 'kee fee pares', 'Building 1', 'District X, Cadaclan', 'jackson hayes', '09288494666', 'Gas Station', '34543', '2024-10-18', '2345', '2024-10-18', '2345', '2024-10-18', '23243543', '2024-10-18', '1234543', '2024-10-18'),
(43, 39, 'Innapoyan', 'Robinson', 'District X, Cadaclan', 'Jokic nikola', '09574577474', 'Good and Services', '34543', '2024-10-26', '2345', '2024-10-26', '2345', '2024-10-26', '23243543', '2024-11-02', '1234543', '2024-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exit_access_requirements`
--

CREATE TABLE `tbl_exit_access_requirements` (
  `id` int(11) NOT NULL,
  `EA1_dimensions` decimal(5,2) NOT NULL,
  `EA1_status` enum('passed','failed') DEFAULT NULL,
  `EA2_dimensions` decimal(5,2) NOT NULL,
  `EA2_status` enum('passed','failed') DEFAULT NULL,
  `EA3_dimensions` decimal(5,2) NOT NULL,
  `EA3_status` enum('passed','failed') DEFAULT NULL,
  `EA4_dimensions` decimal(5,2) NOT NULL,
  `EA4_status` enum('passed','failed') DEFAULT NULL,
  `EA5_status` enum('passed','failed') DEFAULT NULL,
  `EA6_status` enum('passed','failed') DEFAULT NULL,
  `EA7_status` enum('passed','failed') DEFAULT NULL,
  `EA8_status` enum('passed','failed') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exit_components`
--

CREATE TABLE `tbl_exit_components` (
  `id` int(11) NOT NULL,
  `stairs_type` varchar(50) DEFAULT NULL,
  `stairs_type1` varchar(50) DEFAULT NULL,
  `stairs_type2` varchar(50) DEFAULT NULL,
  `stairs_type4` varchar(50) DEFAULT NULL,
  `ED_clear_width` decimal(5,2) DEFAULT NULL,
  `ED_status` enum('passed','failed') DEFAULT NULL,
  `NS_clear_width` decimal(5,2) DEFAULT NULL,
  `NS_status` enum('passed','failed') DEFAULT NULL,
  `CS_clear_width` decimal(5,2) DEFAULT NULL,
  `CS_status` enum('passed','failed') DEFAULT NULL,
  `WS_clear_width` decimal(5,2) DEFAULT NULL,
  `WS_status` enum('passed','failed') DEFAULT NULL,
  `HE_clear_width` decimal(5,2) DEFAULT NULL,
  `HE_status` enum('passed','failed') DEFAULT NULL,
  `OS_clear_width` decimal(5,2) DEFAULT NULL,
  `OS_status` enum('passed','failed') DEFAULT NULL,
  `EP_clear_width` decimal(5,2) DEFAULT NULL,
  `EP_status` enum('passed','failed') DEFAULT NULL,
  `FES_clear_width` decimal(5,2) DEFAULT NULL,
  `FES_status` enum('passed','failed') DEFAULT NULL,
  `FEL_clear_width` decimal(5,2) DEFAULT NULL,
  `FEL_status` enum('passed','failed') DEFAULT NULL,
  `SE_clear_width` decimal(5,2) DEFAULT NULL,
  `SE_status` enum('passed','failed') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exit_doors_requirements`
--

CREATE TABLE `tbl_exit_doors_requirements` (
  `id` int(11) NOT NULL,
  `ED1_dimensions` varchar(50) DEFAULT NULL,
  `ED1_status` enum('passed','failed') DEFAULT NULL,
  `ED2_dimensions` varchar(50) DEFAULT NULL,
  `ED2_status` enum('passed','failed') DEFAULT NULL,
  `ED3_dimensions` varchar(50) DEFAULT NULL,
  `ED3_status` enum('passed','failed') DEFAULT NULL,
  `ED4_dimensions` varchar(50) DEFAULT NULL,
  `ED4_status` enum('passed','failed') DEFAULT NULL,
  `ED5_dimensions` varchar(50) DEFAULT NULL,
  `ED5_status` enum('passed','failed') DEFAULT NULL,
  `ED6_dimensions` varchar(50) DEFAULT NULL,
  `ED6_status` enum('passed','failed') DEFAULT NULL,
  `ED7_dimensions` varchar(50) DEFAULT NULL,
  `ED7_status` enum('passed','failed') DEFAULT NULL,
  `ED8_dimensions` varchar(50) DEFAULT NULL,
  `ED8_status` enum('passed','failed') DEFAULT NULL,
  `ED9_dimensions` varchar(50) DEFAULT NULL,
  `ED9_status` enum('passed','failed') DEFAULT NULL,
  `ED10_dimensions` varchar(50) DEFAULT NULL,
  `ED10_status` enum('passed','failed') DEFAULT NULL,
  `ED11_status` enum('passed','failed') DEFAULT NULL,
  `ED12_status` enum('passed','failed') DEFAULT NULL,
  `ED13_status` enum('passed','failed') DEFAULT NULL,
  `ED14_status` enum('passed','failed') DEFAULT NULL,
  `ED15_status` enum('passed','failed') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fire_protection`
--

CREATE TABLE `tbl_fire_protection` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `fire_extinguisher_size` varchar(10) DEFAULT NULL,
  `minimum_number_extinguisher` varchar(10) DEFAULT NULL,
  `location_status` varchar(10) DEFAULT NULL,
  `seals_tags` varchar(10) DEFAULT NULL,
  `markings` varchar(10) DEFAULT NULL,
  `condition_status` varchar(10) DEFAULT NULL,
  `pressure` varchar(10) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `quantity` varchar(10) DEFAULT NULL,
  `capacity` varchar(10) DEFAULT NULL,
  `ELS_provided` varchar(3) DEFAULT NULL,
  `ELS_functional` varchar(3) DEFAULT NULL,
  `ELS_Locations` varchar(50) DEFAULT NULL,
  `ELS_others` varchar(255) DEFAULT NULL,
  `FDA_provided` varchar(50) DEFAULT NULL,
  `FDA_functional` varchar(3) DEFAULT NULL,
  `UPF` varchar(50) DEFAULT NULL,
  `FDA_adequate` varchar(3) DEFAULT NULL,
  `LCP` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_fire_protection`
--

INSERT INTO `tbl_fire_protection` (`id`, `inspection_id`, `fire_extinguisher_size`, `minimum_number_extinguisher`, `location_status`, `seals_tags`, `markings`, `condition_status`, `pressure`, `remarks`, `type`, `quantity`, `capacity`, `ELS_provided`, `ELS_functional`, `ELS_Locations`, `ELS_others`, `FDA_provided`, `FDA_functional`, `UPF`, `FDA_adequate`, `LCP`) VALUES
(36, 35, 'passed', 'passed', 'passed', 'passed', 'passed', 'passed', 'passed', '', '234234', '32423', '23454', 'yes', 'yes', 'high', '', 'manual', 'yes', '4545', 'yes', '3454'),
(43, 36, '', '', '', '', '', '', '', '', '234 ', '234 ', '234 ', '', '', '', '', '', '', '', '', '3454 '),
(45, 39, '', '', '', '', '', '', '', '', '234234 ', '32423 ', '23454 ', '', '', '', '', '', '', '', '', '3454 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fire_protection_inspection`
--

CREATE TABLE `tbl_fire_protection_inspection` (
  `id` int(11) NOT NULL,
  `sprinkler_pumps` enum('passed','failed') NOT NULL,
  `sprinkler_valves` enum('passed','failed') NOT NULL,
  `sprinkler_alarm` enum('passed','failed') NOT NULL,
  `cabinet_door` enum('passed','failed') NOT NULL,
  `hose_condition` enum('passed','failed') NOT NULL,
  `nozzle` enum('passed','failed') NOT NULL,
  `hose_hung` enum('passed','failed') NOT NULL,
  `valves_handles` enum('passed','failed') NOT NULL,
  `pump_system` enum('passed','failed') NOT NULL,
  `pippings` enum('passed','failed') NOT NULL,
  `motor` enum('passed','failed') NOT NULL,
  `electrical_system` enum('passed','failed') NOT NULL,
  `valves_in_place` enum('passed','failed') NOT NULL,
  `fire_detection` enum('passed','failed') NOT NULL,
  `location_signs` enum('passed','failed') NOT NULL,
  `alarm_panels` enum('passed','failed') NOT NULL,
  `lifts_home` enum('passed','failed') NOT NULL,
  `lift_fans` enum('passed','failed') NOT NULL,
  `fireman_lift` enum('passed','failed') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fire_safety_inspection`
--

CREATE TABLE `tbl_fire_safety_inspection` (
  `id` int(11) NOT NULL,
  `fire_extinguisher_size` enum('1','0') NOT NULL,
  `num_extinguishers` enum('1','0') NOT NULL,
  `extinguisher_location` enum('1','0') NOT NULL,
  `seals_tags` enum('1','0') NOT NULL,
  `markings` enum('1','0') NOT NULL,
  `condition` enum('1','0') NOT NULL,
  `pressure_gauge` enum('1','0') NOT NULL,
  `battery_lights` enum('passed','failed') NOT NULL,
  `hoods_vents` enum('passed','failed') NOT NULL,
  `hoods_filter` enum('passed','failed') NOT NULL,
  `utilities_cooking` enum('passed','failed') NOT NULL,
  `hvac` enum('passed','failed') NOT NULL,
  `smoke_control_systems` enum('passed','failed') NOT NULL,
  `AHR` enum('AHR') DEFAULT NULL,
  `PSRA` enum('PSRA') DEFAULT NULL,
  `EACM` enum('EACM') DEFAULT NULL,
  `USWF` enum('USWF') DEFAULT NULL,
  `AMH` enum('AMH') DEFAULT NULL,
  `AOBS` enum('AOBS') DEFAULT NULL,
  `chutes_incinerators` enum('passed','failed') NOT NULL,
  `CIS` enum('CIS') DEFAULT NULL,
  `PMEC` enum('PMEC') DEFAULT NULL,
  `fire_wall` enum('yes','no') NOT NULL,
  `fw_extension` enum('yes','no') NOT NULL,
  `wall_type` enum('125mm_solid_concrete','150mm_solid_masonry','200mm_hollow_unit_masonry') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general_information`
--

CREATE TABLE `tbl_general_information` (
  `id` int(11) NOT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `occupancy_type` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `business_nature` varchar(255) DEFAULT NULL,
  `GIoccufsic` varchar(10) DEFAULT NULL,
  `fsec_number` varchar(50) DEFAULT NULL,
  `fsec_date_issued` date DEFAULT NULL,
  `building_permit_number` varchar(50) DEFAULT NULL,
  `bp_date_issued` date DEFAULT NULL,
  `GINRAOfsec` varchar(10) DEFAULT NULL,
  `fsic_number` varchar(50) DEFAULT NULL,
  `fsic_date_issued` date DEFAULT NULL,
  `certificate_fire_drill` varchar(50) DEFAULT NULL,
  `CFD_date_issued` date DEFAULT NULL,
  `building_renovation_permit` varchar(50) DEFAULT NULL,
  `rp_date_issued` date DEFAULT NULL,
  `fire_insurance_policy_number` varchar(50) DEFAULT NULL,
  `policy_date_issued` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hazards`
--

CREATE TABLE `tbl_hazards` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `hazard_classification` varchar(50) DEFAULT NULL,
  `storage_clearance` varchar(3) DEFAULT NULL,
  `FS_clearance` varchar(3) DEFAULT NULL,
  `fsdate_issued` date DEFAULT NULL,
  `control_num` varchar(50) DEFAULT NULL,
  `hazard_content` text DEFAULT NULL,
  `total_volume` varchar(50) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `CC_status` varchar(10) DEFAULT NULL,
  `GDD_status` varchar(10) DEFAULT NULL,
  `LPG` varchar(3) DEFAULT NULL,
  `ins_clearance` varchar(3) DEFAULT NULL,
  `isndate_issued` date DEFAULT NULL,
  `inscontrol_num` varchar(50) DEFAULT NULL,
  `ssmc` varchar(3) DEFAULT NULL,
  `NSS` varchar(3) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_hazards`
--

INSERT INTO `tbl_hazards` (`id`, `inspection_id`, `hazard_classification`, `storage_clearance`, `FS_clearance`, `fsdate_issued`, `control_num`, `hazard_content`, `total_volume`, `location`, `CC_status`, `GDD_status`, `LPG`, `ins_clearance`, `isndate_issued`, `inscontrol_num`, `ssmc`, `NSS`, `remarks`) VALUES
(36, 35, 'low', 'yes', 'yes', '2024-10-17', '123', '32', '324324', 'fdsfsdf', 'passed', 'passed', 'yes', 'yes', '2024-10-24', 'er4234234', 'yes', 'yes', ''),
(43, 36, '', '', '', '2024-10-18', ' 4234423434234', ' 32', ' 324324', 'fdsfsdf ', '', '', '', '', '2024-10-25', '23232', '', '', ''),
(45, 39, '', '', '', '2024-10-09', ' 4234423434234', ' 23', ' 324324', 'fdsfsdf ', '', '', '', '', '2024-10-24', '23323232', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_horizontal_components_summary`
--

CREATE TABLE `tbl_horizontal_components_summary` (
  `id` int(11) NOT NULL,
  `GOC_type` varchar(50) NOT NULL,
  `doors_dimensions` decimal(5,2) NOT NULL,
  `doors_status` enum('passed','failed') NOT NULL,
  `doors_remarks` varchar(255) DEFAULT NULL,
  `corridors_dimensions` decimal(5,2) NOT NULL,
  `corridors_status` enum('passed','failed') NOT NULL,
  `corridors_remarks` varchar(255) DEFAULT NULL,
  `passageways_dimensions` decimal(5,2) NOT NULL,
  `passageways_status` enum('passed','failed') NOT NULL,
  `passageways_remarks` varchar(255) DEFAULT NULL,
  `lobby_dimensions` decimal(5,2) NOT NULL,
  `lobby_status` enum('passed','failed') NOT NULL,
  `lobby_remarks` varchar(255) DEFAULT NULL,
  `ramps_dimensions` decimal(5,2) NOT NULL,
  `ramps_status` enum('passed','failed') NOT NULL,
  `ramps_remarks` varchar(255) DEFAULT NULL,
  `common_path_dimensions` decimal(5,2) NOT NULL,
  `common_path_status` enum('passed','failed') NOT NULL,
  `common_path_remarks` varchar(255) DEFAULT NULL,
  `dead_end_dimensions` decimal(5,2) NOT NULL,
  `dead_end_status` enum('passed','failed') NOT NULL,
  `dead_end_remarks` varchar(255) DEFAULT NULL,
  `travel_distance_dimensions` decimal(5,2) NOT NULL,
  `travel_distance_status` enum('passed','failed') NOT NULL,
  `travel_distance_remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_inspections`
--

CREATE TABLE `tbl_inspections` (
  `inspection_id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `inspector_fname` varchar(100) NOT NULL,
  `inspector_mname` varchar(100) NOT NULL,
  `inspector_lname` varchar(100) NOT NULL,
  `inspection_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_issued` date NOT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_inspections`
--

INSERT INTO `tbl_inspections` (`inspection_id`, `application_id`, `inspector_fname`, `inspector_mname`, `inspector_lname`, `inspection_date`, `status`, `date_issued`, `remarks`) VALUES
(35, 34, 'Jeric', 'Irving', 'Laron', '2024-10-24', 'Approved', '2024-10-16', NULL),
(36, 35, 'Jeric', 'Irving', 'Laron', '2024-10-26', 'Approved', '2024-10-18', NULL),
(38, 37, 'Jeric', 'Irving', 'Laron', '2024-11-01', 'Ready for Inspection', '2024-10-18', NULL),
(39, 38, 'Jeric', 'Irving', 'Laron', '2024-10-31', 'Approved', '2024-10-19', NULL),
(40, 39, '', '', '', '0000-00-00', '', '0000-00-00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_inspection_references`
--

CREATE TABLE `tbl_inspection_references` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) NOT NULL,
  `order_no` varchar(50) DEFAULT NULL,
  `date_issued` date DEFAULT NULL,
  `date_inspected` date DEFAULT NULL,
  `inspection_type` varchar(255) DEFAULT NULL,
  `other_inspection_type` varchar(255) DEFAULT NULL,
  `occufsic` tinyint(1) DEFAULT NULL,
  `fsscr` tinyint(1) DEFAULT NULL,
  `fsscr_applicable` tinyint(1) DEFAULT NULL,
  `nra_ofsec` tinyint(1) DEFAULT NULL,
  `fsmr` tinyint(1) DEFAULT NULL,
  `fsmr_applicable` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_means_of_egress`
--

CREATE TABLE `tbl_means_of_egress` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `doors_dim` varchar(50) DEFAULT NULL,
  `doors_status` varchar(10) DEFAULT NULL,
  `corridor_dim` varchar(50) DEFAULT NULL,
  `corridor_status` varchar(10) DEFAULT NULL,
  `exitsdoors_dim` varchar(50) DEFAULT NULL,
  `exitsdoors_status` varchar(10) DEFAULT NULL,
  `stairs_dim` varchar(50) DEFAULT NULL,
  `stairs_status` varchar(10) DEFAULT NULL,
  `horizontalexit_dim` varchar(50) DEFAULT NULL,
  `horizontalexit_status` varchar(10) DEFAULT NULL,
  `MLH_status` varchar(10) DEFAULT NULL,
  `EED_status` varchar(10) DEFAULT NULL,
  `ESPI_status` varchar(10) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_means_of_egress`
--

INSERT INTO `tbl_means_of_egress` (`id`, `inspection_id`, `doors_dim`, `doors_status`, `corridor_dim`, `corridor_status`, `exitsdoors_dim`, `exitsdoors_status`, `stairs_dim`, `stairs_status`, `horizontalexit_dim`, `horizontalexit_status`, `MLH_status`, `EED_status`, `ESPI_status`, `remarks`) VALUES
(36, 35, '12', 'passed', '234', 'passed', '23', 'passed', '23432', 'passed', 'we', 'passed', 'passed', 'passed', 'passed', ''),
(43, 36, '12', '', '234', 'passed', '42323423', '', 'ewe', 'passed', '2343', '', '', 'passed', '', ''),
(45, 39, '12', '', '234', 'passed', '23', '', 'ewe', '', 'we', 'passed', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_owners`
--

CREATE TABLE `tbl_owners` (
  `owner_id` int(11) NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `contact_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_owners`
--

INSERT INTO `tbl_owners` (`owner_id`, `owner_name`, `contact_number`) VALUES
(125, 'Anne Lee Rice', '09288494666'),
(126, 'jackson hayes', '09288494666'),
(128, 'jackson hayes', '09574577474'),
(129, 'Jokic nikola', '09574577474'),
(130, 'Ako Si Pulis', '09574577474');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reference`
--

CREATE TABLE `tbl_reference` (
  `id` int(11) NOT NULL,
  `inspection_id` int(11) DEFAULT NULL,
  `order_no` varchar(255) NOT NULL,
  `date_issued` date NOT NULL,
  `date_inspected` date NOT NULL,
  `inspection_type` text NOT NULL,
  `others` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reference`
--

INSERT INTO `tbl_reference` (`id`, `inspection_id`, `order_no`, `date_issued`, `date_inspected`, `inspection_type`, `others`) VALUES
(36, 35, '2345', '2024-10-17', '2024-10-17', 'PEZA', ''),
(43, 36, '2345', '2024-10-18', '2024-10-18', '', ''),
(45, 39, '123456', '2024-10-19', '2024-10-19', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_signs_lighting_exits`
--

CREATE TABLE `tbl_signs_lighting_exits` (
  `id` int(11) NOT NULL,
  `actual_dim_1` varchar(50) DEFAULT NULL,
  `status_A_0` enum('passed','failed') DEFAULT NULL,
  `actual_dim_2` varchar(50) DEFAULT NULL,
  `status_A_1` enum('passed','failed') DEFAULT NULL,
  `actual_dim_3` varchar(50) DEFAULT NULL,
  `status_A_2` enum('passed','failed') DEFAULT NULL,
  `location_status` enum('Passed','Failed') DEFAULT NULL,
  `location_status1` varchar(50) DEFAULT NULL,
  `actual_dim1` varchar(50) DEFAULT NULL,
  `status1` enum('passed','failed') DEFAULT NULL,
  `actual_dim2` varchar(50) DEFAULT NULL,
  `status2` enum('passed','failed') DEFAULT NULL,
  `actual_dim3` varchar(50) DEFAULT NULL,
  `status3` enum('passed','failed') DEFAULT NULL,
  `lux_time_1` varchar(50) DEFAULT NULL,
  `result_1` enum('passed','failed') DEFAULT NULL,
  `lux_time_2` varchar(50) DEFAULT NULL,
  `result_2` enum('passed','failed') DEFAULT NULL,
  `measurement_stairs` varchar(50) DEFAULT NULL,
  `result_stairs` enum('passed','failed') DEFAULT NULL,
  `measurement_lighting` varchar(50) DEFAULT NULL,
  `result_lighting` enum('passed','failed') DEFAULT NULL,
  `measurement_system` varchar(50) DEFAULT NULL,
  `result_system` enum('passed','failed') DEFAULT NULL,
  `measurement_testing` varchar(50) DEFAULT NULL,
  `result_testing` enum('passed','failed') DEFAULT NULL,
  `emergency_option_215_9mm` varchar(255) DEFAULT NULL,
  `emergency_option_457_2mm` varchar(255) DEFAULT NULL,
  `emergency_option_914_4mm` varchar(255) DEFAULT NULL,
  `emergency_option_10_8lux` varchar(255) DEFAULT NULL,
  `emergency_option_1_5_hour` varchar(255) DEFAULT NULL,
  `emergency_option_written_record` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(8) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `pword` varchar(100) NOT NULL,
  `userlevel` varchar(50) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `fname`, `mname`, `lname`, `pword`, `userlevel`, `status`) VALUES
(10000028, 'Admin1', 'Kherby', 'Campilla', 'Elefante', '$2y$10$XI2GGlZr/GpCXUw1hkokCONhOUn4hDcJZydgSJfmVAASdaO8JpMfy', 'Administrator', 0),
(10000029, 'Inspector', 'Kiboloy', 'Roxas', 'Castro', '$2y$10$0adSXIBqmpt9.hWytX411.FJPAiGRA.XN59xy7nuapKV8dTlnKCX6', 'Inspector', 0),
(10000030, 'City Fire Marshall', 'Johnyy', 'Maximo', 'Agbulos', '$2y$10$VL64N6bvXn53NcMzzflklOzRGRDGfQlRaxha/so2iQZrpf/qqzsFK', 'Fire Marshall', 0),
(10000031, 'jeric', 'Jeric', 'Irving', 'Laron', '$2y$10$1XY4VNXik0lWCQDR9/gOrudIXPHSQKNAsVOQFXNyD0q718Ev9sJra', 'Inspector', 0),
(10000032, 'Admin2', 'Vien', 'Daryl', 'Saliganan', '$2y$10$lKEfPd9B9RATzElRBAuAL.vSUAwX7R1.Ea4O9WNXmWL.qS1g1.hoe', 'Administrator', 0),
(10000034, 'Inspector2', 'Ian Noels', 'Roxas', 'Laron', '$2y$10$1MXKS/xwb0DNR4IrD2J4A.FZ09Qr.dHV/YKDeK5ZVrfzZ62/At/wW', 'Inspector', 0),
(10000035, 'Marshall', 'Kherbyss', 'Irving', 'Castrooa', '$2y$10$1L661iP37PfDXReJ9Xj9I.FF9e7/MCioyoNKTV7TY7YQUz0WDon.S', 'Fire Marshall', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activity_log`
--
ALTER TABLE `tbl_activity_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `tbl_applications`
--
ALTER TABLE `tbl_applications`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `business_id` (`business_id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `building_id` (`building_id`);

--
-- Indexes for table `tbl_bbuilding_details`
--
ALTER TABLE `tbl_bbuilding_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_bhazards`
--
ALTER TABLE `tbl_bhazards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_buildings`
--
ALTER TABLE `tbl_buildings`
  ADD PRIMARY KEY (`building_id`);

--
-- Indexes for table `tbl_building_details`
--
ALTER TABLE `tbl_building_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_businesses`
--
ALTER TABLE `tbl_businesses`
  ADD PRIMARY KEY (`business_id`);

--
-- Indexes for table `tbl_business_details`
--
ALTER TABLE `tbl_business_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_exit_access_requirements`
--
ALTER TABLE `tbl_exit_access_requirements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exit_components`
--
ALTER TABLE `tbl_exit_components`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exit_doors_requirements`
--
ALTER TABLE `tbl_exit_doors_requirements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fire_protection`
--
ALTER TABLE `tbl_fire_protection`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_fire_protection_inspection`
--
ALTER TABLE `tbl_fire_protection_inspection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fire_safety_inspection`
--
ALTER TABLE `tbl_fire_safety_inspection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_general_information`
--
ALTER TABLE `tbl_general_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hazards`
--
ALTER TABLE `tbl_hazards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_horizontal_components_summary`
--
ALTER TABLE `tbl_horizontal_components_summary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_inspections`
--
ALTER TABLE `tbl_inspections`
  ADD PRIMARY KEY (`inspection_id`),
  ADD KEY `application_id` (`application_id`);

--
-- Indexes for table `tbl_inspection_references`
--
ALTER TABLE `tbl_inspection_references`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_means_of_egress`
--
ALTER TABLE `tbl_means_of_egress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_owners`
--
ALTER TABLE `tbl_owners`
  ADD PRIMARY KEY (`owner_id`);

--
-- Indexes for table `tbl_reference`
--
ALTER TABLE `tbl_reference`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inspection_id` (`inspection_id`);

--
-- Indexes for table `tbl_signs_lighting_exits`
--
ALTER TABLE `tbl_signs_lighting_exits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activity_log`
--
ALTER TABLE `tbl_activity_log`
  MODIFY `log_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `tbl_applications`
--
ALTER TABLE `tbl_applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbl_bbuilding_details`
--
ALTER TABLE `tbl_bbuilding_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bhazards`
--
ALTER TABLE `tbl_bhazards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_buildings`
--
ALTER TABLE `tbl_buildings`
  MODIFY `building_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `tbl_building_details`
--
ALTER TABLE `tbl_building_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tbl_businesses`
--
ALTER TABLE `tbl_businesses`
  MODIFY `business_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `tbl_business_details`
--
ALTER TABLE `tbl_business_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tbl_exit_access_requirements`
--
ALTER TABLE `tbl_exit_access_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_exit_components`
--
ALTER TABLE `tbl_exit_components`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_exit_doors_requirements`
--
ALTER TABLE `tbl_exit_doors_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_fire_protection`
--
ALTER TABLE `tbl_fire_protection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tbl_fire_protection_inspection`
--
ALTER TABLE `tbl_fire_protection_inspection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_fire_safety_inspection`
--
ALTER TABLE `tbl_fire_safety_inspection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_general_information`
--
ALTER TABLE `tbl_general_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_hazards`
--
ALTER TABLE `tbl_hazards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tbl_horizontal_components_summary`
--
ALTER TABLE `tbl_horizontal_components_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_inspections`
--
ALTER TABLE `tbl_inspections`
  MODIFY `inspection_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tbl_inspection_references`
--
ALTER TABLE `tbl_inspection_references`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_means_of_egress`
--
ALTER TABLE `tbl_means_of_egress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `tbl_owners`
--
ALTER TABLE `tbl_owners`
  MODIFY `owner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `tbl_reference`
--
ALTER TABLE `tbl_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tbl_signs_lighting_exits`
--
ALTER TABLE `tbl_signs_lighting_exits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000036;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_applications`
--
ALTER TABLE `tbl_applications`
  ADD CONSTRAINT `tbl_applications_ibfk_1` FOREIGN KEY (`business_id`) REFERENCES `tbl_businesses` (`business_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_applications_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `tbl_owners` (`owner_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_applications_ibfk_3` FOREIGN KEY (`building_id`) REFERENCES `tbl_buildings` (`building_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_bbuilding_details`
--
ALTER TABLE `tbl_bbuilding_details`
  ADD CONSTRAINT `tbl_bbuilding_details_ibfk_1` FOREIGN KEY (`inspection_id`) REFERENCES `tbl_inspections` (`inspection_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_inspections`
--
ALTER TABLE `tbl_inspections`
  ADD CONSTRAINT `tbl_inspections_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `tbl_applications` (`application_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_inspection_references`
--
ALTER TABLE `tbl_inspection_references`
  ADD CONSTRAINT `fk_inspection_id` FOREIGN KEY (`inspection_id`) REFERENCES `tbl_inspections` (`inspection_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
