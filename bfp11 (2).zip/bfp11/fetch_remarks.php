<?php
// Include database connection
include 'connection.php';

// Check if trackingNumber is provided
if (isset($_GET['trackingNumber'])) {
    $trackingNumber = $_GET['trackingNumber'];

    // Prepare SQL statement to fetch remarks
    $sql = "SELECT r.remarks
            FROM tbl_registrations reg
            INNER JOIN tbl_registrations r ON reg.registration_id = r.registration_id
            WHERE reg.tracking_number = '$trackingNumber'";

    $result = $conn->query($sql);

    if ($result) {
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Output data as JSON
            echo json_encode($row);
        } else {
            // No remarks found for the provided tracking number
            echo json_encode(array('remarks' => 'No remarks found for the provided tracking number.'));
        }
    } else {
        // Error executing the SQL query
        echo json_encode(array('error' => 'Error: ' . $conn->error));
    }
} else {
    // No tracking number provided
    echo json_encode(array('error' => 'Tracking number is not provided.'));
}

// Close connection
$conn->close();
?>
