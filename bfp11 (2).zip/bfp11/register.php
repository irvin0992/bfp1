<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form data
    $buildingName = mysqli_real_escape_string($conn, $_POST['buildingName']);
    $buildingHeight = floatval($_POST['buildingHeight']);
    $squareMeters = floatval($_POST['squareMeters']);
    $numberOfFloors = intval($_POST['numberOfFloors']);
    $businessAddress = mysqli_real_escape_string($conn, $_POST['businessAddress']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay']);
    $businessName = mysqli_real_escape_string($conn, $_POST['businessName']);
    $occupancy = mysqli_real_escape_string($conn, $_POST['Occupancy']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $contactNumber = mysqli_real_escape_string($conn, $_POST['contactNumber']);
    $businessNature = mysqli_real_escape_string($conn, $_POST['businessNature']);

    // Generate tracking number (you can adjust this based on your requirements)
    $trackingNumber = uniqid('BFP-', true);

    // Process uploaded file
    if ($_FILES['DTIPhotos']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['DTIPhotos']['tmp_name'];
        $fileName = basename($_FILES['DTIPhotos']['name']);
        $uploadDir = 'DTIuploads/';
        $uploadPath = $uploadDir . $fileName;

        // Move uploaded file to desired location
        if (move_uploaded_file($fileTmpPath, $uploadPath)) {
            // Start transaction
            mysqli_begin_transaction($conn);

            // Insert into tbl_buildings
            $sqlBuilding = "INSERT INTO tbl_buildings (building_name, building_height, total_area, number_of_floors)
                            VALUES ('$buildingName', $buildingHeight, $squareMeters, $numberOfFloors)";
            $resultBuilding = mysqli_query($conn, $sqlBuilding);

            if ($resultBuilding) {
                $lastInsertedBuildingId = mysqli_insert_id($conn);

                // Insert into tbl_businesses
                $sqlBusiness = "INSERT INTO tbl_businesses (business_name, business_address, barangay, business_nature, occupancy_type)
                                VALUES ('$businessName', '$businessAddress', '$barangay', '$businessNature', '$occupancy')";
                $resultBusiness = mysqli_query($conn, $sqlBusiness);

                if ($resultBusiness) {
                    $lastInsertedBusinessId = mysqli_insert_id($conn);

                    // Insert into tbl_owners
                    $sqlOwner = "INSERT INTO tbl_owners (owner_name, owner_address, contact_number)
                                 VALUES ('$owner', '$businessAddress', '$contactNumber')";
                    $resultOwner = mysqli_query($conn, $sqlOwner);

                    if ($resultOwner) {
                        $lastInsertedOwnerId = mysqli_insert_id($conn);

                        // Insert into tbl_registrations
                        $sqlRegistration = "INSERT INTO tbl_registrations (business_id, owner_id, building_id, tracking_number, dti_photos, status)
                                            VALUES ($lastInsertedBusinessId, $lastInsertedOwnerId, $lastInsertedBuildingId, '$trackingNumber', '$fileName', 'pending')";
                        $resultRegistration = mysqli_query($conn, $sqlRegistration);

                        if ($resultRegistration) {
                            // Commit transaction
                            mysqli_commit($conn);

                            // Registration successfully inserted
                            $response = [
                                'status' => 'success',
                                'trackingNumber' => $trackingNumber
                            ];
                            echo json_encode($response);
                        } else {
                            // Rollback transaction on error
                            mysqli_rollback($conn);

                            $response = [
                                'status' => 'error',
                                'message' => mysqli_error($conn)
                            ];
                            echo json_encode($response);
                        }
                    } else {
                        // Rollback transaction on error inserting into tbl_owners
                        mysqli_rollback($conn);

                        $response = [
                            'status' => 'error',
                            'message' => mysqli_error($conn)
                        ];
                        echo json_encode($response);
                    }
                } else {
                    // Rollback transaction on error inserting into tbl_businesses
                    mysqli_rollback($conn);

                    $response = [
                        'status' => 'error',
                        'message' => mysqli_error($conn)
                    ];
                    echo json_encode($response);
                }
            } else {
                // Rollback transaction on error inserting into tbl_buildings
                mysqli_rollback($conn);

                $response = [
                    'status' => 'error',
                    'message' => mysqli_error($conn)
                ];
                echo json_encode($response);
            }
        } else {
            // Error moving uploaded file
            $response = [
                'status' => 'error',
                'message' => 'Failed to move uploaded file.'
            ];
            echo json_encode($response);
        }
    } else {
        // No file uploaded or other file upload error
        $response = [
            'status' => 'error',
            'message' => 'No file uploaded or other file upload error.'
        ];
        echo json_encode($response);
    }
}
?>
