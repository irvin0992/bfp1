<?php
include('../session_validate.php');
include('../header/header.php');
include('../sidebar/sidebar.php');
include '../connection.php';
?>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>

                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="admindashboard.php"
                                            class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Generate Report</li>
                                    <li class="breadcrumb-item active" aria-current="page">Generate Report Inspection</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10 p-5" style="border: 5px solid #b92828; border-radius: 12px; background-color: #f5f5f5;">
            <div class="row mb-5">
                <div class="col-md-6">
                    <label for="fromDate" class="form-label">From Date:</label>
                    <input type="date" id="fromDate" name="from_date" class="form-control"
                        style="border: 2px solid #ced4da; padding: 10px; font-size: 18px;">
                </div>
                <div class="col-md-6">
                    <label for="toDate" class="form-label">To Date:</label>
                    <input type="date" id="toDate" name="to_date" class="form-control"
                        style="border: 2px solid #ced4da; padding: 10px; font-size: 18px;">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <button id="generateReportBtn" class="btn btn-secondary w-100" style="padding: 10px; font-size: 18px;">Generate Report</button>
                </div>
            </div>
        </div>
    </div>

    <form id="reportForm" action="../ReportGen/generate_inspections_report.php" method="POST" target="_blank">
        <input type="hidden" id="startDate" name="start_date">
        <input type="hidden" id="endDate" name="end_date">
    </form>
</div>

<style>
    .container {
        max-width: 800px;
        margin: 0 auto;
    }

    label.form-label {
        font-weight: 600;
        font-size: 16px;
        margin-bottom: 8px;
    }

    input.form-control {
        border-radius: 6px;
    }

    button {
        font-size: 18px;
        padding: 15px;
        border-radius: 6px;
    }

    #generateReportBtn {
        background-color: #6c757d;
        border-color: #6c757d;
        transition: all 0.3s ease;
    }

    #generateReportBtn:hover {
        background-color: #5a6268;
        border-color: #545b62;
    }
</style>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="generate_inspections.js"></script>
<script>
    document.getElementById('generateReportBtn').addEventListener('click', function () {
        document.getElementById('startDate').value = document.getElementById('fromDate').value;
        document.getElementById('endDate').value = document.getElementById('toDate').value;
        document.getElementById('reportForm').submit();
    });
</script>
