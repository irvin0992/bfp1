<?php
require('../ReportGen/fpdf185/fpdf.php'); // Include FPDF library
include('../connection.php'); // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $district = $_POST['district'];
    $barangay = $_POST['barangay'];

    // Create instance of FPDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Set the title of the document
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, "Business Report for $district - $barangay", 0, 1, 'C');
    $pdf->Ln(10); // Line break

    // Fetch business info from database
    $query = "
    SELECT a.*, b.business_name, o.owner_name, o.contact_number, b.district, b.barangay
    FROM tbl_applications a
    INNER JOIN tbl_businesses b ON a.business_id = b.business_id
    INNER JOIN tbl_owners o ON a.owner_id = o.owner_id 
    WHERE district = ? AND barangay = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $district, $barangay);
    $stmt->execute();
    $result = $stmt->get_result();  

    // Check if there are results
    if ($result->num_rows > 0) {
        // Set font for table headers
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(50, 10, 'Business Name', 1);
        $pdf->Cell(50, 10, 'Owner Name', 1);
        $pdf->Cell(50, 10, 'Address', 1);
        $pdf->Cell(40, 10, 'Contact', 1);
        $pdf->Ln(); // Move to next row

        // Set font for table data
        $pdf->SetFont('Arial', '', 10);

        // Output each row of the result set
        while ($row = $result->fetch_assoc()) {
            $pdf->Cell(50, 10, $row['business_name'], 1);
            $pdf->Cell(50, 10, $row['owner_name'], 1);
            $pdf->Cell(50, 10, $row['district'] . ', ' . $row['barangay'], 1, 0, 'C');
            $pdf->Cell(40, 10, $row['contact_number'], 1);
            $pdf->Ln();
        }
    } else {
        // If no data is found
        $pdf->SetFont('Arial', 'I', 12);
        $pdf->Cell(0, 10, 'No businesses found for the selected district and barangay.', 0, 1, 'C');
    }

    // Close the prepared statement and result
    $stmt->close();
}

// Output the PDF
$pdf->Output();

// Close database connection
$conn->close();
?>
