$(document).ready(function() {
   

    // Generate Report button click handler
    $('#generateReportBtn').on('click', function () {
        var fromDate = $('#fromDate').val();
        var toDate = $('#toDate').val();

        // Update hidden fields with selected dates or clear them if no dates are selected
        $('#startDate').val(fromDate);
        $('#endDate').val(toDate);

        // Submit the form to generate the PDF report
        $('#reportForm').submit();
    });

    // Edit button click handler to populate the modal with inspection data
    $('#inspectionTable').on('click', '.edit-btn', function () {
        var businessName = $(this).data('business');
        var inspectorName = $(this).data('inspector-name');
        var inspectionDate = $(this).data('inspection-date');

        $('#businessName').val(businessName);
        $('#inspectorName').val(inspectorName);
        $('#inspectionDate').val(inspectionDate);
    });

    // Filter button click handler to filter inspection data
    $('#filterBtn').on('click', function () {
        var fromDate = $('#fromDate').val();
        var toDate = $('#toDate').val();

        if (fromDate === '' || toDate === '') {
            Swal.fire('Please select both start and end dates');
            return;
        }

        $.ajax({
            url: 'filter_inspections.php',
            type: 'POST',
            data: { from_date: fromDate, to_date: toDate },
            success: function (response) {
                $('#inspectionTable tbody').html(response);
            },
            error: function () {
                Swal.fire('Error filtering data');
            }
        });
    });
});