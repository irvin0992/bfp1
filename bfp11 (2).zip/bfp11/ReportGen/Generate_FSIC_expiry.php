<?php
// Include FPDF library
require('../ReportGen/fpdf185/fpdf.php');
// Include the database connection file
include('../connection.php');

// Get the date range from the POST request
$startDate = $_POST['start_date'] ?? '';
$endDate = $_POST['end_date'] ?? '';
if (!empty($startDate) && !empty($endDate)) {
    $query = "
    SELECT a.*, b.business_name, o.owner_name, a.FSIC_expiry, b.district, b.barangay
    FROM tbl_applications a
    INNER JOIN tbl_businesses b ON a.business_id = b.business_id
    INNER JOIN tbl_owners o ON a.owner_id = o.owner_id
    WHERE a.FSIC_expiry BETWEEN '$startDate' AND '$endDate'
    ";
} else {
// Query to fetch data based on the provided date range or fetch all data if no date range is specified
$query = "
    SELECT a.*, b.business_name, o.owner_name, a.FSIC_expiry, b.district, b.barangay
    FROM tbl_applications a
    INNER JOIN tbl_businesses b ON a.business_id = b.business_id
    INNER JOIN tbl_owners o ON a.owner_id = o.owner_id
";
}
// Run the query and check for errors
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);  // Display error message if query fails
}

$pdf = new FPDF('P', 'mm', 'A4'); // Set page size to A4
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 10); // Add page break if content exceeds page height

// Set document title and date range
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'FSIC Expiry Report', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'From: ' . $startDate . ' To: ' . $endDate, 0, 1, 'C');
$pdf->Ln(10); // Line break

// Table header styling (with red background)
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(255, 100, 100); // Light red background
$pdf->SetTextColor(255, 255, 255); // White text color for header
$pdf->Cell(40, 12, 'Business Name', 1, 0, 'C', true);
$pdf->Cell(60, 12, 'Owner Name', 1, 0, 'C', true);
$pdf->Cell(50, 12, 'Business Address', 1, 0, 'C', true);
$pdf->Cell(40, 12, 'FSIC Expiry', 1, 1, 'C', true);

// Set font for table content
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0, 0, 0); // Reset text color to black
$pdf->SetFillColor(255, 230, 230); // Lighter red for alternating row background

// Add data to the table with alternating row colors
$fill = false;
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(40, 10, $row['business_name'], 1, 0, 'C', $fill);
    $pdf->Cell(60, 10, $row['owner_name'], 1, 0, 'C', $fill);
    $pdf->Cell(50, 10, $row['district'] . ', ' . $row['barangay'], 1, 0, 'C', $fill);
    $pdf->Cell(40, 10, $row['FSIC_expiry'], 1, 1, 'C', $fill);
    $fill = !$fill; // Toggle alternating row background
}

// Output the PDF to the browser
$pdf->Output();

// Close the database connection
$conn->close();

?>
