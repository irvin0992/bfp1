<?php
include('../connection.php');

$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';

$query = "
    SELECT i.*, b.business_name 
    FROM tbl_inspections i
    INNER JOIN tbl_applications r ON i.application_id = r.application_id
    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
";

if (!empty($from_date) && !empty($to_date)) {
    $query .= " WHERE i.inspection_date BETWEEN '$from_date' AND '$to_date'";
}

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $status = 'Pending';
        if (!empty($row['inspector_name']) && !empty($row['inspection_date'])) {
            $status = 'Ready to Inspect';
        }
        echo "<tr>
                <td>".htmlspecialchars($row['business_name'])."</td>
                <td>".htmlspecialchars($row['inspector_name'])."</td>
                <td>".htmlspecialchars($row['inspection_date'])."</td>
                <td class='".($status == 'Pending' ? 'status-pending' : 'status-ready')."'>".htmlspecialchars($status)."</td>
                <td>
                    <center>
                        <button class='btn custom-btn edit-btn ".($status == 'Ready to Inspect' ? 'disabled' : '')."' 
                            data-business='".htmlspecialchars($row['business_name'])."'
                            data-inspector-name='".htmlspecialchars($row['inspector_name'])."'
                            data-inspection-date='".htmlspecialchars($row['inspection_date'])."'
                            data-toggle='modal' data-target='#editModal' ".($status == 'Ready to Inspect' ? 'disabled' : '').">
                            <i class='fa fa-calendar'></i>
                        </button>
                    </center>
                </td>
            </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No records found</td></tr>";
}

$conn->close();
?>
