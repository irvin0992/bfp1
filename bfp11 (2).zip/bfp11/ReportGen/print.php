<?php
require('../ReportGen/fpdf185/fpdf.php');

// Database connection
$host = "localhost";  // Replace with your database host
$dbUsername = "root";    // Replace with your database username
$dbPassword = "";        // Replace with your database password
$dbName = "bfp_db";  // Replace with your database name

// Establish the connection
$connection = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check if the connection is established
if ($connection->connect_error) {
    die('Database connection error: ' . $connection->connect_error);
}

// Get the inspection_id from the URL (or use a different ID if appropriate)
$inspectionId = isset($_GET['inspection_id']) ? intval($_GET['inspection_id']) : 0;

if ($inspectionId == 0) {
    die('Invalid inspection ID.');
}

// Query to get inspection details for a specific inspection
$query = "SELECT i.*, b.business_name, b.district, b.barangay, b.occupancy_type, 
                 o.owner_name, o.contact_number, r.email, r.FSIC_expiry,
                 bu.building_name, bu.building_height, bu.total_area, bu.number_of_floors, 
                 r.application_id
          FROM tbl_inspections i 
          JOIN tbl_applications r ON i.application_id = r.application_id
          JOIN tbl_businesses b ON r.business_id = b.business_id
          JOIN tbl_owners o ON r.owner_id = o.owner_id
          LEFT JOIN tbl_buildings bu ON r.building_id = bu.building_id
          WHERE i.inspection_id = $inspectionId";   

$result = mysqli_query($connection, $query);

if (!$result) {
    die('Query Failed: ' . mysqli_error($connection));
}

if (mysqli_num_rows($result) == 0) {
    die('No records found for the specified inspection.');
}

// Define the PDF class
class PDF extends FPDF
{
    // Page header
    function Header()
    {
        // Add logo
        // $this->Image('../path/to/logo.png', 10, 6, 30); // Adjust logo path
        // Set font
        $this->SetFont('Arial', 'B', 16);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, 'Fire Safety Inspection Report', 0, 1, 'C');
        $this->SetFont('Arial', 'I', 12);
        $this->Cell(0, 10, 'Generated on: ' . date('Y-m-d'), 0, 1, 'C');
        $this->Ln(10); // Line break
    }

    // Page footer
    function Footer()
    {
        // Go to 1.5 cm from bottom
        $this->SetY(-15);
        // Select Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }

    // Table layout for inspection details
    function InspectionDetailsTable($data)
    {
        // Add some spacing
        $this->Ln(10);

        // Set the font for table content
        $this->SetFont('Arial', '', 12);
        
        // First Column (Labels)
        $this->SetFillColor(230, 230, 230); // Light gray fill for labels
        $this->Cell(60, 10, 'Business Name:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['business_name'], 1, 1, 'L');

        $this->Cell(60, 10, 'Building Name:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['building_name'], 1, 1, 'L');

        $this->Cell(60, 10, 'Address:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['district'] . ', ' . $data['barangay'], 1, 1, 'L');

        $this->Cell(60, 10, 'Owner Name:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['owner_name'], 1, 1, 'L');

        $this->Cell(60, 10, 'Occupancy Type:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['occupancy_type'], 1, 1, 'L');

        $this->Cell(60, 10, 'Contact Number:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['contact_number'], 1, 1, 'L');

        $this->Cell(60, 10, 'Building Height:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['building_height'] . ' meters', 1, 1, 'L');

        $this->Cell(60, 10, 'Total Area:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['total_area'] . ' sqm', 1, 1, 'L');

        $this->Cell(60, 10, 'Number of Floors:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['number_of_floors'], 1, 1, 'L');

        $this->Cell(60, 10, 'Email:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['email'], 1, 1, 'L');

        $this->Cell(60, 10, 'FSIC Expiration:', 1, 0, 'L', true);
        $this->Cell(130, 10, $data['FSIC_expiry'], 1, 1, 'L');
    }
}

// Create PDF instance
$pdf = new PDF();
$pdf->AddPage();

// Fetch data and generate PDF content
if ($row = mysqli_fetch_assoc($result)) {
    $inspectionData = array(
        'business_name' => $row['business_name'] ?? 'N/A',
        'building_name' => $row['building_name'] ?? 'N/A',
        'district' => $row['district'] ?? 'N/A',
        'barangay' => $row['barangay'] ?? 'N/A',
        'owner_name' => $row['owner_name'] ?? 'N/A',
        'occupancy_type' => $row['occupancy_type'] ?? 'N/A',
        'contact_number' => $row['contact_number'] ?? 'N/A',
        'building_height' => $row['building_height'] ?? 'N/A',
        'total_area' => $row['total_area'] ?? 'N/A',
        'number_of_floors' => $row['number_of_floors'] ?? 'N/A',
        'email' => $row['email'] ?? 'N/A',
        'FSIC_expiry' => $row['FSIC_expiry'] ?? 'N/A'
    );
}

// Table with inspection data
$pdf->InspectionDetailsTable($inspectionData);

// Output PDF
$pdf->Output('I', 'inspection_details.pdf');

// Close the database connection
$connection->close();
?>
