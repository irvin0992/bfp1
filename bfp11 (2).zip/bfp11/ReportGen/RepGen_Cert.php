<?php
require('../ReportGen/fpdf185/fpdf.php');
include('../connection.php');  // This includes your MySQLi connection

// Get application_id from POST request
$application_id = isset($_POST['application_id']) ? $_POST['application_id'] : null;

if ($application_id === null) {
    die('Application ID is missing.');
}

// Prepare the SQL statement for fetching application data
$sql = "SELECT a.*, b.building_name, b.building_height, b.total_area, b.number_of_floors, 
               bu.business_name, bu.district, bu.barangay, o.owner_name, bu.occupancy_type, 
               o.contact_number, a.requirements_file, bu.business_nature, bd.fsic_number
        FROM tbl_applications a
        LEFT JOIN tbl_buildings b ON a.building_id = b.building_id
        LEFT JOIN tbl_businesses bu ON a.business_id = bu.business_id
        LEFT JOIN tbl_owners o ON a.owner_id = o.owner_id
        LEFT JOIN tbl_inspections i ON a.application_id = i.application_id
        LEFT JOIN tbl_business_details bd ON bd.inspection_id = i.inspection_id
        WHERE a.application_id = ?";

// Prepare and bind
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $application_id);  // 'i' indicates the application_id is an integer
$stmt->execute();
$result = $stmt->get_result();
$applicationData = $result->fetch_assoc();

// Fetch the business name from the result
$business_name = $applicationData['business_name'];
$owner_name = $applicationData['owner_name'];
$business_address = $applicationData['district'] . ', ' . $applicationData['barangay'];
$total_area = $applicationData['total_area'];
$fsic_number = $applicationData['fsic_number'];

// SQL query to get active administrator and fire marshal from tbl_users
$sql_users = "SELECT * FROM tbl_users 
              WHERE status = 0 AND (userlevel = 'Administrator' OR userlevel = 'Fire Marshall')";

// Execute the query
$result_users = $conn->query($sql_users);

// Check if the query failed
if (!$result_users) {
    die("Error executing query: " . $conn->error);
}

$admin_name = '';
$fire_marshal_name = '';

while ($row = $result_users->fetch_assoc()) {
    if ($row['userlevel'] == 'Administrator') {
        $admin_name = $row['fname'] . ' ' . $row['mname'] . ' ' . $row['lname'];
    } elseif ($row['userlevel'] == 'Fire Marshall') {
        $fire_marshal_name = $row['fname'] . ' ' . $row['mname'] . ' ' . $row['lname'];
    }
}

// Set current date and next year's date
$currentDate = date('Y-m-d');
$nextYearDate = date('Y-m-d', strtotime('+1 year'));

// Static values for the insertion
$province = 'Province of La Union';
$station = 'City of San Fernando, La Union';
$station_address = 'Quezon Ave, City of San Fernando, La Union';
$tel_num = 'Tel.No.(072) 607 788';

// Insert new data into tbl_cert or update existing record if application_id already exists
$insertCertQuery = "INSERT INTO tbl_cert (application_id, Province, Station, Station_Address, Tel_Num, Date_Today, NY_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                    Province = VALUES(Province),
                    Station = VALUES(Station),
                    Station_Address = VALUES(Station_Address),
                    Tel_Num = VALUES(Tel_Num),
                    Date_Today = VALUES(Date_Today),
                    NY_date = VALUES(NY_date)";

// Prepare and bind parameters
if ($stmtInsert = $conn->prepare($insertCertQuery)) {
    $stmtInsert->bind_param('issssss', $application_id, $province, $station, $station_address, $tel_num, $currentDate, $nextYearDate);
    $stmtInsert->execute();
    $stmtInsert->close();
} else {
    die("Error preparing insert query: " . $conn->error);
}



// SQL query to get all data from tbl_cert
$sql_cert = "SELECT * FROM tbl_cert";
$result_cert = $conn->query($sql_cert);

// Check if the query failed
if (!$result_cert) {
    die("Error executing query: " . $conn->error);
}

$certData = $result_cert->fetch_assoc();  // Assuming you only need the first row

// Fetch specific values from tbl_cert (e.g., Province, Station, etc.)
$province = $certData['Province'];
$station = $certData['Station'];
$station_address = $certData['Station_Address'];
$tel_num = $certData['Tel_Num'];  // Fetch Tel_Num
$date_today = $certData['Date_Today'];
$ny_date = $certData['NY_date'];

class PDF extends FPDF
{
    public $tel_num;  // Declare a public property for telephone number

    function Header()
    {
        $this->Ln(5); // Line break
        // DILG and BFP logos, adjusted for alignment
        $this->Image('../logos/dilg.png', 5, 10, 65); // DILG logo on the left
        $this->Image('../logos/BFP.png', 161, 18, 26); // BFP logo on the right

        // Set font for the title
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'Republic of the Philippines', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 5, 'Department of the Interior and Local Government', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 5, 'BUREAU OF FIRE PROTECTION', 0, 1, 'C');
        $this->SetFont('Arial', '', 12);
        $this->Cell(0, 5, 'Region 1', 0, 1, 'C');

        // Add lines with no extra space between
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');

        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'District/Provincial Office', 0, 1, 'C');

        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Station', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Station Address', 0, 1, 'C');

        // Now use the class property for the telephone number
        $this->SetFont('Arial', 'B', 20);
        $this->Cell(0, 5, '      ' . $this->tel_num . '    ', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Telephone No./Email Address', 0, 1, 'C');
    }

    function Footer()
    {
        // Set a thicker line width for the border
        $this->SetLineWidth(1.5); // Adjust the value for a thicker border
        $this->Rect(10, 10, 190, 277); // A4 page width = 210mm, height = 297mm, so margin is 10mm
    }
}




// Create a new PDF document with 1-inch margins on left and right
$pdf = new PDF('P', 'mm', 'A4');
$pdf->SetMargins(25.4, 10, 25.4); // Set 1-inch margins on the left and right, 10mm top and bottom
$pdf->AddPage();


$pdf->SetFont('Arial', 'B', 10);
$pdf->Ln(5); // Line break

$pdf->SetTextColor(255, 0, 0);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'FSIC NO. R'.$fsic_number.'', 0, 0, 'L');
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', 'U', 13);
$pdf->Cell(0, 5, '      '.$date_today.'    ', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, 'Date              ', 0, 1, 'R');

$pdf->SetFont('Arial', 'B', 17);
$pdf->Ln(5);
$pdf->Cell(0, 10, 'FIRE SAFETY INSPECTION CERTIFICATE', 0, 1, 'C');

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, 'FOR CERTIFICATE OF OCCUPANCY', 0, 1, 'C');
$pdf->Cell(0, 5, 'FOR BUSINESS PERMIT (NEW/RENEWAL)', 0, 1, 'C');
$pdf->Cell(0, 5, 'OTHERS ____________________', 0, 1, 'C');

$pdf->Ln(5);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 5, 'TO WHOM IT MAY CONCERN:', 0, 1, 'L');
$pdf->Ln(5);

$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 5, '           By virtue of the provisions of RA 9514, otherwise known as the Fire Code of the Philippines of', 0, 'J');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, '2008,       the        application       for       FIRE       SAFETY      INSPECTION      CERTIFICATE      of', 0, 1, 'J');

$pdf->SetFont('Arial', 'U', 13);
$pdf->Cell(0, 5, '                                                       ' . $business_name . '                                                        ', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Name of Establishment)', 0, 1, 'C');  // Print the fetched business name
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(40, 5, 'owned and managed by ', 0, 0, 'L');  // Regular text
$pdf->SetFont('Arial', 'U', 13);  // Set underline for owner name
$pdf->Cell(83, 5, '                    ' . $owner_name . '                    ', 0, 0, 'L');  // Underlined owner name with defined width
$pdf->SetFont('Arial', '', 10);  // Reset to regular text
$pdf->Cell(0, 5, ' with postal address at', 0, 1, 'L');  // Continue with regular text


$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Name of Owner/Representative)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->SetFont('Arial', 'U', 13);
$pdf->Cell(0, 5, '                                             ' . $business_address . '                                         ', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Address)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->MultiCell(0, 5, 'is hereby GRANTED after said building structure or facility has been duly inspected with the finding that it has fully complied with the fire safety and protection requirements of the Fire Code of the Philippines of 2008 and its Revised Implementing Rules and Regulations.', 0, 'J');

$pdf->Ln(2);

$pdf->Cell(44, 5, 'This certification is valid for', 0, 0, 'L');  // Regular text
$pdf->SetFont('Arial', 'U', 13);  // Set underline for owner name
$pdf->Cell(83, 5, '       ' . $business_name . ' with ' . $total_area . 'sqm total floor area                       ', 0, 1, 'L');  // Underlined owner name with defined width
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Description)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->SetFont('Arial', 'U', 13);  // Set underline for owner name
$pdf->Cell(95, 5, 'located at ' . $business_address . '                   ', 0, 0, 'L');  // Regular text
$pdf->SetFont('Arial', '', 10);  // Set underline for owner name
$pdf->Cell(17, 5, 'valid until', 0, 0, 'L');  // Underlined owner name with defined width
$pdf->SetFont('Arial', 'U', 13);  // Reset to regular text
$pdf->Cell(0, 5, '       '.$ny_date.'         ', 0, 1, 'L');  // Continue with regular text
$pdf->SetFont('Arial', '', 10);
$pdf->SetFont('Arial', '', 10);

$pdf->Ln(5);

$pdf->MultiCell(0, 5, '                Violation of Fire Code provisions shall cause this certificate null and void after appropriate ', 0, 'J');
$pdf->MultiCell(0, 5, ' proceeding and hold the owner liable to the penalties provided for by the said Fire Code.', 0, 'J');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'RECOMMEND APPROVAL:                ', 0, 1, 'R');
$pdf->SetFont('Arial', 'U', 13);
$pdf->Cell(0, 7, '       '.$admin_name.'', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 3, 'Chief, Fire Safety Enforcement Section', 0, 1, 'R');

$pdf->Ln(6);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'APPROVED:                                        ', 0, 1, 'R');
$pdf->SetFont('Arial', 'U', 13);
$pdf->Cell(0, 7, '       '.$fire_marshal_name.' ', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 3, 'City/Municipal Fire Marshal          ', 0, 1, 'R');

$pdf->Ln(5);

$pdf->SetFont('Arial', 'I', 10);
$pdf->MultiCell(0, 4, '                NOTE: "This Certificate does not take the place of any license required by law and is not ', 0, 'J');
$pdf->SetFont('Arial', 'I', 10);
$pdf->MultiCell(0, 4, 'transferable. Any change in the use of occupancy of the premises shall require a new certificate."', 0, 'R');


$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 7, 'THIS CERTIFICATE SHALL BE POSTED CONSPICUOUSLY', 0, 1, 'C');

$pdf->SetTextColor(255, 0, 0);

$pdf->SetFont('Arial', '', 7);
$pdf->MultiCell(0, 3, '"PAALALA: MAHIGPIT NA IPINAGBABAWAL NG PAMUNUAN NG BUREAU OF FIRE PROTECTION SA MGA KAWANI NITO ', 0, 'C');
$pdf->MultiCell(0, 5, 'ANG MAGBENTA O MAGREREKOMENDA NG ANOMANG BRAND NG FIRE EXTINGUISHER"', 0, 'C');

// Reset text color to black (optional if you want to go back to default color after this)
$pdf->SetTextColor(0, 0, 0);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 5, '"FIRE SAFETY IS OUR MAIN CONCERN"', 0, 1, 'C');

$pdf->Output('fire_safety_inspection_certificate.pdf', 'I');
?>