<?php
include('../session_validate.php');
include('../header/header.php');
include('../sidebar/sidebar.php');
include '../connection.php';
?>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>

                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="admindashboard.php"
                                            class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Generate Report</li>
                                    <li class="breadcrumb-item active" aria-current="page">Generate Report Application</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8 p-4 shadow"
            style="border: 4px solid #b92828; border-radius: 10px; background-color: #fff;">
            <h3 class="text-center mb-4" style="font-family: 'Poppins', sans-serif; color: #b92828;">FSIC Generate
                Report</h3>

            <!-- Filter Dropdown -->
            <div class="form-group mb-4">
                <label for="filterData" class="form-label"
                    style="font-weight: 600; font-family: 'Poppins', sans-serif; color: #b92828;">Filter Report</label>
                <select name="filter_option" id="filterData" class="form-control"
                    style="border: 2px solid #ced4da; padding: 6px;" onchange="navigateToReport()">
                    <option value="">Select Report</option>
                    <option value="category_1">FSIC Expiration</option>
                    <option value="category_2">Bussiness Address</option>
                    <option value="category_3">Category 3</option>
                </select>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <label for="businessAddress" class="text-dark">Business District</label>
                    <select class="form-control" id="businessAddress" name="businessAddress" required>
                        <option value="">Select San Fernando City</option>
                        <option value="District I">District I</option>
                        <option value="District II">District II</option>
                        <option value="District III">District III</option>
                        <option value="District IV">District IV</option>
                        <option value="District V">District V</option>
                        <option value="District VI">District VI</option>
                        <option value="District VII">District VII</option>
                        <option value="District VIII">District VIII</option>
                        <option value="District IX">District IX</option>
                        <option value="District X">District X</option>
                        <option value="District XI">District XI</option>
                        <option value="District XII">District XII</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="barangay" class="text-dark">Barangay</label>
                    <select class="form-control" id="barangay" name="barangay" required>
                        <option value="">Select Barangay</option>
                    </select>
                </div>
            </div>

            <!-- Generate Report Button -->
            <div class="row mt-4">
                <div class="col-md-6 offset-md-3">
                    <button id="generateReportBtn" class="btn btn-secondary w-100"
                        style="padding: 12px; font-size: 18px;">Generate Report</button>
                </div>
            </div>

            <form id="reportForm" action="../ReportGen/Generate_BusAdd.php" method="POST" target="_blank">
                <input type="hidden" id="district" name="district">
                <input type="hidden" id="barangayField" name="barangay">
            </form>
        </div>
    </div>
</div>
<!-- Update the Generate Report button to submit the form -->
<script>
    document.getElementById('generateReportBtn').addEventListener('click', function () {
        document.getElementById('district').value = document.getElementById('businessAddress').value;
        document.getElementById('barangayField').value = document.getElementById('barangay').value;
        document.getElementById('reportForm').submit();
    });
</script>
<script>
    function navigateToReport() {
        var selectedValue = document.getElementById('filterData').value;
        if (selectedValue === 'category_1') {
            window.location.href = 'FSIC_report.php'; // Replace with your PHP page path
        } else if (selectedValue === 'category_2') {
            window.location.href = 'BusAdd_Report.php'; // Adjust as necessary
        } else if (selectedValue === 'category_3') {
            window.location.href = 'path/to/yet_another_php_page.php'; // Adjust as necessary
        } else {
            alert('Please select a valid category.');
        }
    }
</script>
<script>
    // District to Barangay mapping
    const barangays = {
        "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
        "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
        "District III": ["Catbangen", "Parian", "Madayegdeg"],
        "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
        "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
        "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
        "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
        "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
        "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
        "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
        "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
        "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
    };

    // Event listener for District select
    document.getElementById('businessAddress').addEventListener('change', function () {
        const district = this.value;
        const barangaySelect = document.getElementById('barangay');

        // Clear previous options
        barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

        // Populate Barangay based on selected District
        if (barangays[district]) {
            barangays[district].forEach(function (barangay) {
                const option = document.createElement('option');
                option.value = barangay;
                option.textContent = barangay;
                barangaySelect.appendChild(option);
            });
        }
    });
</script>

<!-- Styles -->
<style>
    .container {
        max-width: 700px;
    }

    h3 {
        font-weight: bold;
    }

    .form-group label {
        font-size: 16px;
        margin-bottom: 8px;
    }

    select.form-control {
        border-radius: 5px;
    }

    button {
        padding: 12px;
        border-radius: 5px;
        font-weight: bold;
    }

    .shadow {
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
</style>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>