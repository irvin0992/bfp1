<?php
require('../ReportGen/fpdf185/fpdf.php');
include('../connection.php');

// Get the date range from the POST request
$startDate = $_POST['start_date'] ?? '';
$endDate = $_POST['end_date'] ?? '';

// Query to fetch data based on the provided date range or fetch all data if no date range is specified
if (!empty($startDate) && !empty($endDate)) {
    $query = "
        SELECT i.*, b.business_name, i.inspector_fname, i.inspector_mname, i.inspector_lname
        FROM tbl_inspections i
        INNER JOIN tbl_applications r ON i.application_id = r.application_id
        INNER JOIN tbl_businesses b ON r.business_id = b.business_id
        WHERE i.inspection_date BETWEEN '$startDate' AND '$endDate'
    ";
} else {
    $query = "
        SELECT i.*, b.business_name, i.inspector_fname, i.inspector_mname, i.inspector_lname
        FROM tbl_inspections i
        INNER JOIN tbl_applications r ON i.application_id = r.application_id
        INNER JOIN tbl_businesses b ON r.business_id = b.business_id
    ";
}

$result = $conn->query($query);

// Check if the query was successful
if (!$result) {
    die("Query failed: " . $conn->error);  // This will display the SQL error if the query fails
}

$pdf = new FPDF('P', 'mm', 'A4'); // Set the page size to A4
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 10);

$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Inspection Records', 0, 1, 'C');

// Corrected these lines to use the correct variables
if (!empty($startDate) && !empty($endDate)) {
    $pdf->Cell(0, 10, 'From ' . $startDate . ' to ' . $endDate, 0, 1, 'C');
} else {
    $pdf->Cell(0, 10, 'All Records', 0, 1, 'C');
}
$pdf->Ln(10);

// Table header styling (with red background)
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(255, 100, 100); // Light red color
$pdf->SetTextColor(255, 255, 255); // White text color for header
$pdf->Cell(60, 12, 'Business Name', 1, 0, 'C', true);
$pdf->Cell(50, 12, 'Inspector Name', 1, 0, 'C', true);
$pdf->Cell(35, 12, 'Inspection Date', 1, 0, 'C', true);
$pdf->Cell(50, 12, 'Status', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(0, 0, 0); // Reset text color to black
$pdf->SetFillColor(255, 230, 230); // Lighter red for alternating row background

// Add data to the table with improved layout
$fill = false;
while ($row = $result->fetch_assoc()) {
    $inspectorName = $row['inspector_fname'] . ' ' . $row['inspector_mname'] . ' ' . $row['inspector_lname'];
    
    $pdf->Cell(60, 10, $row['business_name'], 1, 0, 'C', $fill);
    $pdf->Cell(50, 10, $inspectorName, 1, 0, 'C', $fill);
    $pdf->Cell(35, 10, $row['inspection_date'], 1, 0, 'C', $fill);
    $pdf->Cell(50, 10, ucfirst($row['status']), 1, 1, 'C', $fill);
    
    $fill = !$fill; // Alternate row colors
}

// Output the PDF
$pdf->Output();

$conn->close();

?>
