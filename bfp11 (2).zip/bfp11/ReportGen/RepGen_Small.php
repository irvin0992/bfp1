<?php
require('../ReportGen/fpdf185/fpdf.php');
include('../connection.php');  

$inspectionId = isset($_GET['inspection_id']) ? intval($_GET['inspection_id']) : 0;

if ($inspectionId === 0) {
    die('Inspection ID is required.');
}

$query = "
    SELECT 
        bd.building_name,
        b.district,
        b.barangay,
        b.business_name,
        b.occupancy_type,
        o.owner_name,
        o.contact_number,
        b.business_nature,
        i.status,
        a.order_no,
        a.date_issued,
        a.date_inspected, 
        a.inspection_type,
        a.others,
        c.policy_number,
        c.pol_date_issued,
        c.fsic_number,
        c.fsic_date_issued,
        c.fsec_number,
        c.fsec_date_issued,
        c.building_permit,
        c.rp_date_issued,
        c.bpermit_number,
        c.bp_date_issued,
        d.construction_type,
        d.floor_area,
        d.occupant_load,
        d.building_height,
        d.Stories_num,
        d.Portion_Occupied,
        d.mezzanine_type,
        d.Handrails_type,
        e.doors_dim,
        e.doors_status,
        e.corridor_dim,
        e.corridor_status,
        e.exitsdoors_dim,
        e.exitsdoors_status,
        e.stairs_dim,
        e.stairs_status,
        e.horizontalexit_dim,
        e.horizontalexit_status,
        e.MLH_status,
        e.EED_status,
        e.ESPI_status,
        e.remarks,
        f.hazard_classification,
        f.storage_clearance,
        f.FS_clearance,
        f.fsdate_issued,
        f.control_num,
        f.hazard_content,
        f.total_volume,
        f.location,
        f.CC_status,
        f.GDD_status,
        f.LPG,
        f.ins_clearance,
        f.isndate_issued,
        f.inscontrol_num,
        f.ssmc,
        f.NSS,
        f.remarks,
        g.fire_extinguisher_size,
        g.minimum_number_extinguisher,
        g.location_status,
        g.seals_tags,
        g.markings,
        g.condition_status,
        g.pressure,
        g.remarks,
        g.type,
        g.quantity,
        g.capacity,
        g.ELS_provided,
        g.ELS_functional,
        g.ELS_Locations,
        g.ELS_others,
        g.FDA_provided,
        g.FDA_functional,
        g.UPF,
        g.FDA_adequate,
        g.LCP
    FROM tbl_inspections i
    INNER JOIN tbl_applications r ON i.application_id = r.application_id
    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
    INNER JOIN tbl_buildings bd ON r.building_id = bd.building_id
    INNER JOIN tbl_reference a ON i.inspection_id = a.inspection_id
    INNER JOIN tbl_business_details c ON i.inspection_id = c.inspection_id
    INNER JOIN tbl_building_details d ON i.inspection_id = d.inspection_id
    INNER JOIN tbl_means_of_egress e ON i.inspection_id = e.inspection_id
    INNER JOIN tbl_hazards f ON i.inspection_id = f.inspection_id
    INNER JOIN tbl_fire_protection g ON i.inspection_id = g.inspection_id
    WHERE i.inspection_id = ? AND i.status = 'Reinspection'
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("i", $inspectionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('No data found for inspection ID: ' . $inspectionId);
}

// Fetch the result into $row
$row = $result->fetch_assoc();

if (!$row) {
    die('No data found.');
}

// Assign retrieved values to variables
$buildingName = $row['building_name'];
$businessAddress = $row['district'] . ', ' . $row['barangay'];
$businessName = $row['business_name'];
$occupancyType = $row['occupancy_type'];
$ownerName = $row['owner_name'];
$contactNumber = $row['contact_number'];
$businessNature = $row['business_nature'];
$status = $row['status']; // Fetch the status

$orderNo = $row['order_no'];
$dateIssued = $row['date_issued'];
$dateInspected = $row['date_inspected'];
$inspectionTypes = explode(',', $row['inspection_type']);

// Additional variables from the database
$policyNumber = $row['policy_number'];
$polDateIssued = $row['pol_date_issued'];
$fsicNumber = $row['fsic_number'];
$fsicDateIssued = $row['fsic_date_issued'];
$fsecNumber = $row['fsec_number'];
$fsecDateIssued = $row['fsec_date_issued'];
$buildingPermit = $row['building_permit'];
$rpDateIssued = $row['rp_date_issued'];
$bPermitNumber = $row['bpermit_number'];
$bPDateIssued = $row['bp_date_issued'];
$constructionTypes = explode(',', $row['construction_type']);
$floorArea = $row['floor_area'];
$occupantLoad = $row['occupant_load'];
$buildingHeight = $row['building_height'];
$storiesNum = $row['Stories_num'];
$portionOccupied = $row['Portion_Occupied'];
$mezzanineType = explode(',', $row['mezzanine_type']);
$handrailsType = explode(',', $row['Handrails_type']);

$doorsDim = $row['doors_dim'];
$doorsStatus = $row['doors_status'];
$corridorDim = $row['corridor_dim'];
$corridorStatus = $row['corridor_status'];
$exitsdoorsDim = $row['exitsdoors_dim'];
$exitsdoorsStatus = $row['exitsdoors_status'];
$stairsDim = $row['stairs_dim'];
$stairsStatus = $row['stairs_status'];
$horizontalexitDim = $row['horizontalexit_dim'];
$horizontalexitStatus = $row['horizontalexit_status'];
$MLHStatus = $row['MLH_status'];
$EEDStatus = $row['EED_status'];
$ESPIStatus = $row['ESPI_status'];
$remarks = $row['remarks'];

$hazardClassification = explode(',', $row['hazard_classification']);
$storageClearance = explode(',', $row['storage_clearance']);
$FSClearance = explode(',', $row['FS_clearance']);
$FSDateIssued = $row['fsdate_issued'];
$controlNum = $row['control_num'];
$hazardContent = $row['hazard_content'];
$totalVolume = $row['total_volume'];
$location = $row['location'];
$CCStatus = explode(',', $row['CC_status']);
$GDDStatus = explode(',', $row['GDD_status']);
$LPG = explode(',', $row['LPG']);
$insClearance = explode(',', $row['ins_clearance']);
$insDateIssued = $row['isndate_issued'];
$insControlNum = $row['inscontrol_num'];
$SSMC = explode(',', $row['ssmc']);
$NSS = explode(',', $row['NSS']);
$remarks = $row['remarks'];

$fireExtinguisherSize = explode(',', $row['fire_extinguisher_size']);
$minimumNumberExtinguisher = explode(',', $row['minimum_number_extinguisher']);
$locationStatus = explode(',', $row['location_status']);
$sealsTags = explode(',', $row['seals_tags']);
$markings = explode(',', $row['markings']);
$conditionStatus = explode(',', $row['condition_status']);
$pressure = explode(',', $row['pressure']);
$type = $row['type'];
$quantity = $row['quantity'];
$capacity = $row['capacity'];
$ELSProvided = explode(',', $row['ELS_provided']);
$ELSFunctional = explode(',', $row['ELS_functional']);
$ELSLocations = explode(',', $row['ELS_Locations']);
$ELSOthers = $row['ELS_others'];
$FDAProvided = explode(',', $row['FDA_provided']);
$FDAFunctional = explode(',', $row['FDA_functional']);
$UPF = $row['UPF'];
$FDAAdequate = explode(',', $row['FDA_adequate']);
$LCP = $row['LCP'];

// Create instance of FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Header
$pdf->Cell(0, 10, 'Small Business Inspection Checklist', 0, 1, 'C');

// Section: Reference
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'I. REFERENCE', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(50, 10, 'Inspection Order No:', 0, 0);
$pdf->Cell(0, 10, $orderNo, 0, 1);
$pdf->Cell(50, 10, 'Date Issued:', 0, 0);
$pdf->Cell(0, 10, $dateIssued, 0, 1);
$pdf->Cell(50, 10, 'Date Inspected:', 0, 0);
$pdf->Cell(0, 10, $dateInspected, 0, 1);

// Section: Nature of Inspection Conducted
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'II. NATURE OF INSPECTION CONDUCTED', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$inspectionTypesMap = [
    'construction' => 'Inspection during construction',
    'PEZA' => 'FSIC for Certificate of Annual Inspection (PEZA)',
    'fsic_occupancy' => 'FSIC for Certificate for Occupancy',
    'verification' => 'Verification Inspection for Compliance',
    'fsic_new' => 'FSIC for Business Permit (New)',
    'ntc' => 'NTC',
    'ntcv' => 'NTCV',
    'abatement' => 'Abatement',
    'closure' => 'Closure',
    'fsic_renewal' => 'FSIC for Business Permit (Renewal)',
    'disapproval' => 'Notice of Disapproval, if Certificate of Occupancy',
    'others' => 'Others (Specify)'
];
foreach ($inspectionTypes as $type) {
    if (array_key_exists($type, $inspectionTypesMap)) {
        $pdf->Cell(0, 10, '- ' . $inspectionTypesMap[$type], 0, 1);
    }
}

// Section: General Information
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'III. GENERAL INFORMATION', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(50, 10, 'Business Name:', 0, 0);
$pdf->Cell(0, 10, $businessName, 0, 1);
$pdf->Cell(50, 10, 'Building Name:', 0, 0);
$pdf->Cell(0, 10, $buildingName, 0, 1);
$pdf->Cell(50, 10, 'Business Address:', 0, 0);
$pdf->Cell(0, 10, $businessAddress, 0, 1);
$pdf->Cell(50, 10, 'Occupancy Type:', 0, 0);
$pdf->Cell(0, 10, $occupancyType, 0, 1);
$pdf->Cell(50, 10, 'Owner Name:', 0, 0);
$pdf->Cell(0, 10, $ownerName, 0, 1);
$pdf->Cell(50, 10, 'Contact Number:', 0, 0);
$pdf->Cell(0, 10, $contactNumber, 0, 1);
$pdf->Cell(50, 10, 'Business Nature:', 0, 0);
$pdf->Cell(0, 10, $businessNature, 0, 1);

// New Fields Added
$pdf->Cell(50, 10, 'FSEC No:', 0, 0);
$pdf->Cell(0, 10, $fsecNumber, 0, 1);
$pdf->Cell(50, 10, 'FSEC Date Issued:', 0, 0);
$pdf->Cell(0, 10, $fsecDateIssued, 0, 1);
$pdf->Cell(50, 10, 'Building Permit:', 0, 0);
$pdf->Cell(0, 10, $buildingPermit, 0, 1);
$pdf->Cell(50, 10, 'Building Permit Date Issued:', 0, 0);
$pdf->Cell(0, 10, $rpDateIssued, 0, 1);
$pdf->Cell(50, 10, 'Business Permit No:', 0, 0);
$pdf->Cell(0, 10, $bPermitNumber, 0, 1);
$pdf->Cell(50, 10, 'Business Permit Date Issued:', 0, 0);
$pdf->Cell(0, 10, $bPDateIssued, 0, 1);

// Section: Other Information
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'IV. OTHER INFORMATION', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(50, 10, 'Occupancy Type:', 0, 0);
$pdf->Cell(0, 10, $occupancyType, 0, 1);

// Construction Type (Radio buttons)
$pdf->Cell(50, 10, 'Construction Type:', 0, 0);
$constructionTypeText = '';
if (in_array('timber', $constructionTypes)) $constructionTypeText .= 'Timber Framed and Walls, ';
if (in_array('reinforced_concrete', $constructionTypes)) $constructionTypeText .= 'Reinforced Concrete Framed with Masonry Walls, ';
if (in_array('steel', $constructionTypes)) $constructionTypeText .= 'Steel Framed and Walls, ';
if (in_array('mixed_construction', $constructionTypes)) $constructionTypeText .= 'Mixed Construction';
$pdf->Cell(0, 10, rtrim($constructionTypeText, ', '), 0, 1);

// Floor Area
$pdf->Cell(50, 10, 'Total Floor Area:', 0, 0);
$pdf->Cell(0, 10, $floorArea . ' m²', 0, 1);

// Occupant Load
$pdf->Cell(50, 10, 'Occupant Load:', 0, 0);
$pdf->Cell(0, 10, $occupantLoad, 0, 1);

// Building Height
$pdf->Cell(50, 10, 'Building Height:', 0, 0);
$pdf->Cell(0, 10, $buildingHeight . ' m', 0, 1);

// Number of Stories
$pdf->Cell(50, 10, 'No of Stories:', 0, 0);
$pdf->Cell(0, 10, $storiesNum, 0, 1);

// Portion Occupied
$pdf->Cell(50, 10, 'Portion Occupied:', 0, 0);
$pdf->Cell(0, 10, $portionOccupied . ' m²', 0, 1);

// Mezzanine
$pdf->Cell(50, 10, 'With Mezzanine:', 0, 0);
$pdf->Cell(0, 10, in_array('yes', $mezzanineType) ? 'Yes' : 'No', 0, 1);

// Handrails Provided
$pdf->Cell(50, 10, 'Handrails Provided:', 0, 0);
$pdf->Cell(0, 10, in_array('yes', $handrailsType) ? 'Yes' : 'No', 0, 1);

$pdf->Cell(0, 10, 'Means of Egress and Signage Report', 0, 1, 'C');

// Section: Means of Egress
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'V. MEANS OF EGRESS SECTION', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 10, 'A. EXIT ACCESS', 0, 1, 'L');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(80, 10, 'Horizontal Components', 1);
$pdf->Cell(40, 10, 'Actual Dim.', 1);
$pdf->Cell(30, 10, 'Passed', 1);
$pdf->Cell(30, 10, 'Failed', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 10, 'Doors', 1);
$pdf->Cell(40, 10, $doorsDim, 1);
$pdf->Cell(30, 10, ($doorsStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($doorsStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'Corridors/ Hallways', 1);
$pdf->Cell(40, 10, $corridorDim, 1);
$pdf->Cell(30, 10, ($corridorStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($corridorStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

// B. EXITS
$pdf->Cell(0, 10, 'B. EXITS', 0, 1, 'L');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(80, 10, 'Horizontal Components', 1);
$pdf->Cell(40, 10, 'Actual Dim.', 1);
$pdf->Cell(30, 10, 'Passed', 1);
$pdf->Cell(30, 10, 'Failed', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 10, 'Exits Doors', 1);
$pdf->Cell(40, 10, $exitsdoorsDim, 1);
$pdf->Cell(30, 10, ($exitsdoorsStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($exitsdoorsStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'Stairs', 1);
$pdf->Cell(40, 10, $stairsDim, 1);
$pdf->Cell(30, 10, ($stairsStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($stairsStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'Horizontal Exits', 1);
$pdf->Cell(40, 10, $horizontalexitDim, 1);
$pdf->Cell(30, 10, ($horizontalexitStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($horizontalexitStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

// Section: Signs, Lighting, and Exits Signage
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'VI. SIGNS, LIGHTING, AND EXITS SIGNAGE', 0, 1, 'L');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(80, 10, 'Components', 1);
$pdf->Cell(30, 10, 'Passed', 1);
$pdf->Cell(30, 10, 'Failed', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 10, 'Mininum letter height, 150mm; Width of Stroke, 19mm', 1);
$pdf->Cell(30, 10, ($MLHStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($MLHStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'EXIT signs are posted along Exit access, Exits, and Exit discharge', 1);
$pdf->Cell(30, 10, ($EEDStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($EEDStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'EXIT signs are properly illuminated.', 1);
$pdf->Cell(30, 10, ($ESPIStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($ESPIStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

// Remarks
$pdf->Cell(80, 10, 'Remarks:', 1);
$pdf->MultiCell(0, 10, htmlspecialchars($remarks), 1);

$pdf->Cell(0, 10, 'Hazard Assessment Report', 0, 1, 'C');

// Section: Hazard
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'VII. HAZARD', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(0, 10, 'Hazard Classification:', 0, 1, 'L');
$pdf->Cell(0, 10, 'Low: ' . ($hazardClassification === 'low' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'Ordinary: ' . ($hazardClassification === 'ordinary' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'High: ' . ($hazardClassification === 'high' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Storage Clearance Required:', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($storageClearance === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($storageClearance === 'no' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Fire Safety Clearance For Storage:', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($FSClearance === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($FSClearance === 'no' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Date Issued: ' . htmlspecialchars($FSDateIssued), 0, 1, 'L');
$pdf->Cell(0, 10, 'Control No.: ' . htmlspecialchars($controlNum), 0, 1, 'L');
$pdf->Cell(0, 10, 'Hazard Content: ' . htmlspecialchars($hazardContent), 0, 1, 'L');
$pdf->Cell(0, 10, 'Total Volume: ' . htmlspecialchars($totalVolume), 0, 1, 'L');
$pdf->Cell(0, 10, 'Location: ' . htmlspecialchars($location), 0, 1, 'L');

// Section: First Aid Fire Protection
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 10, 'A. First Aid Fire Protection (Fire Extinguishers)', 0, 1, 'L');

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(80, 10, 'Components', 1);
$pdf->Cell(30, 10, 'Passed', 1);
$pdf->Cell(30, 10, 'Failed', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 10, 'Clearance of stocks from the Ceiling', 1);
$pdf->Cell(30, 10, ($CCStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($CCStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

$pdf->Cell(80, 10, 'Gas Detector and Shut Off Device for LPG', 1);
$pdf->Cell(30, 10, ($GDDStatus === 'passed' ? '/' : ''), 1);
$pdf->Cell(30, 10, ($GDDStatus === 'failed' ? '/' : ''), 1);
$pdf->Ln();

// LPG Systems
$pdf->Cell(0, 10, 'LPG Systems provided with Approved Plans (if 300 kgs. 300 GWC):', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($LPG === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($LPG === 'no' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Installation Clearance:', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($insClearance === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($insClearance === 'no' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Date Issued: ' . htmlspecialchars($insDateIssued), 0, 1, 'L');
$pdf->Cell(0, 10, 'Control No.: ' . htmlspecialchars($insControlNum), 0, 1, 'L');

$pdf->Cell(0, 10, 'Stored in sealed metal Container:', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($SSMC === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($SSMC === 'no' ? '/' : ''), 0, 1, 'L');

$pdf->Cell(0, 10, 'Provided with "NO SMOKING" sign?', 0, 1, 'L');
$pdf->Cell(0, 10, 'Yes: ' . ($NSS === 'yes' ? '/' : ''), 0, 1, 'L');
$pdf->Cell(0, 10, 'No: ' . ($NSS === 'no' ? '/' : ''), 0, 1, 'L');


// Footer
$pdf->SetFont('Arial', 'I', 8);
$pdf->SetY(-15);
$pdf->Cell(0, 10, 'End of Report', 0, 0, 'C');

// Output PDF to browser
$pdf->Output('I', 'Inspection_Report.pdf');
?>
