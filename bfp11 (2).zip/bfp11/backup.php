<?php

// Database config
$servername = "localhost";
$username = "root";
$password = "";
$database = "bfp_db";

// Create database connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch all tables from the database
$tables = array();
$sql = "SHOW TABLES";
$result = mysqli_query($conn, $sql);

if ($result) {
    while ($row = mysqli_fetch_row($result)) {
        $tables[] = $row[0]; // Store table names
    }
} else {
    die("Error fetching table names: " . mysqli_error($conn));
}

$sqlScript = "";

foreach ($tables as $table) {

    // Get the CREATE TABLE statement for the table structure
    $query = "SHOW CREATE TABLE $table";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_row($result);
        $sqlScript .= "\n\n" . $row[1] . ";\n\n";
    } else {
        die("Error fetching table structure for $table: " . mysqli_error($conn));
    }

    // Fetch table data
    $query = "SELECT * FROM $table";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $columnCount = mysqli_num_fields($result);

        // Prepare SQL script for dumping data for each table
        while ($row = mysqli_fetch_row($result)) {
            $sqlScript .= "INSERT INTO $table VALUES(";
            for ($j = 0; $j < $columnCount; $j++) {
                $row[$j] = mysqli_real_escape_string($conn, $row[$j]);

                if (isset($row[$j])) {
                    $sqlScript .= '"' . $row[$j] . '"';
                } else {
                    $sqlScript .= '""';
                }

                if ($j < ($columnCount - 1)) {
                    $sqlScript .= ',';
                }
            }
            $sqlScript .= ");\n";
        }
    } else {
        die("Error fetching data for $table: " . mysqli_error($conn));
    }

    $sqlScript .= "\n";
}

// If the SQL script is not empty, proceed to output it to the browser
if (!empty($sqlScript)) {

    // Generate filename with the database name and current timestamp (YYYY-MM-DD)
$timestamp = date("Y-m-d"); // Include hours, minutes, and seconds
$backup_file_name = $database . '_backup_' . $timestamp . '.sql';

// Optionally, sanitize the filename to ensure it's valid
$backup_file_name = preg_replace('/[^a-zA-Z0-9_\-]/', '.', $backup_file_name);

    // Set headers for file download without saving to the server
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $backup_file_name . '"');
    header('Content-Length: ' . strlen($sqlScript));

    // Output the SQL script directly to the browser
    echo $sqlScript;
}

// Close the database connection
mysqli_close($conn);
?>