<?php
session_start();
error_reporting(0);
$host = "localhost";
$user = "root";
$password = "";
$db = "bfp_db";
$data = mysqli_connect($host, $user, $password, $db);

if ($data === false) {
    die("Connection error");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['username'];
    $pass = $_POST['pword'];

    // Use mysqli_real_escape_string to prevent SQL injection
    $name = mysqli_real_escape_string($data, $name);
    $pass = mysqli_real_escape_string($data, $pass);

    // Fetch user details
    $sql = "SELECT * FROM tbl_users WHERE username='$name'";
    $result = mysqli_query($data, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        if ($row) {
            // Verify password
            if (password_verify($pass, $row['pword'])) {
                // Check if user status is active
                if ($row['status'] == 0) {
                    // Set session variables
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['userlevel'] = $row['userlevel'];

                    // Log the login activity
                    $user_id = $row['id'];
                    $activity_type = 'login';
                    $activity_desc = 'User logged in';
                    $activity_time = date('Y-m-d H:i:s'); // Set the current time

                    $log_sql = "INSERT INTO tbl_activity_log (id, activity_type, activity_time, activity_desc)
                                VALUES ('$user_id', '$activity_type', NOW(), '$activity_desc')";
                    
                    if (!mysqli_query($data, $log_sql)) {
                        die("Logging failed: " . mysqli_error($data));
                    }

                    // Redirect to the login page with success parameter
                    header("Location: login.php?success=1&userlevel=" . urlencode($row['userlevel']));
                    exit();
                } else {
                    header("Location: login.php?error=Account inactive");
                    exit();
                }
            } else {
                header("Location: login.php?error=Incorrect username or password");
                exit();
            }
        } else {
            header("Location: login.php?error=User not found");
            exit();
        }
    } else {
        die("Query failed");
    }
}
?>
