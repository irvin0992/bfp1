<?php include('header/loginheader.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Integrated Fire Safety Compliance Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
        body {
            background-image: url('Images/bfp2.jpeg');
            background-repeat: no-repeat; 
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
        }
        .custom-container {
            border: 4px solid #b92828;
            margin-top: 100px;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.3);
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body class="text-white bg-dark">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <form action="loginVal.php" method="post" class="custom-container">
                    <!-- Logo -->
                    <div class="text-center mb-4">
                        <img src="Images/bfp-logo.png" alt="Logo" style="width: 150px; height: auto;">
                    </div>

                    <h2 class="text-center" style="color:black; font-weight: bold; font-family: sans-serif; font-size: 2.8em;">IFSCMS</h2>
                    <h3 class="text-center" style="color:black; font-weight: lighter; font-size: 1.2em;">Integrated Fire Safety Compliance Management System.</h3>
                    
                    <?php if (isset($_GET['error'])) { ?>
                        <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php } ?>

                    <div class="form-floating mb-2 mt-2">
                        <input type="text" class="form-control form-control-lg shadow-sm" id="username" autocomplete="off" name="username" placeholder="Username" required>
                        <label for="username" style="color:black;">Username</label>
                    </div>
                    <div class="form-floating mb-2">
                    <input type="password" class="form-control form-control-lg shadow-sm" id="pword" name="pword" placeholder="Password"  required maxlength="9"  title="Password must be exactly 8 digits">
                    <label for="pword" style="color:black;">Password</label>
                </div>

                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" id="showPasswordCheck">
                    <label class="form-check-label" for="showPasswordCheck" style="color:black;">
                        Show Password
                    </label>
                </div>
             <button class="w-100 btn btn-lg btn-primary shadow-sm" type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        <?php if (isset($_GET['success']) && $_GET['success'] == '1') { ?>
            Swal.fire({
                icon: 'success',
                title: 'Login Successfully',
                showConfirmButton: false,
                timer: 1500
            }).then(function() {
                // Redirect based on userlevel
                var userlevel = "<?php echo $_GET['userlevel']; ?>";
                if (userlevel === "CRO") {
                    window.location.href = ".../../CRO/CROdashboard.php";
                } else if (userlevel === "Administrator") {
                    window.location.href = ".../../admin/admindashboard.php";
                } else if (userlevel === "Inspector") {
                    window.location.href = ".../../inspector/inspectordashboard.php";
                } else if (userlevel === "Chief FSES") {
                    window.location.href = ".../../Chief FSES/fsesdashboard.php";
                } else if (userlevel === "Fire Marshall") {
                    window.location.href = ".../../Marshall/marshalldashboard.php";
                } else {
                    window.location.href = "login.php?error=Unknown userlevel";
                }
            });
        <?php } ?>
        // Toggle show/hide password using checkbox
document.getElementById('showPasswordCheck').addEventListener('change', function () {
    var passwordInput = document.getElementById('pword');
    if (this.checked) {
        passwordInput.type = 'text';
    } else {
        passwordInput.type = 'password';
    }
});
    </script>
</body>
</html>
