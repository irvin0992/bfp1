<?php include ('header/loginheader.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10">
    <style>
        body {
            background-image: url('Images/bfp2.jpeg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding-top: 90px; /* Ensure space for fixed header */
        }

        .custom-container {
            width: 100%;
            max-width: 1200px; /* Set maximum width */
            border: 4px solid #b92828;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            border-radius: 10px;
        }

        .header-container {
            background-color: #b92828;
            color: white;
            background: linear-gradient(135deg, #b92828, #ff6347);
            padding: 5px;
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 1000;
        }

        .header-container img {
            height: 80px;
        }

        .header-container .header-title {
            margin-left: 10px;
            font-size: 35px;
        }

        .header-nav {
            display: flex;
            justify-content: flex-end;
        }

        .header-nav ul {
            display: flex;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .header-nav ul li {
            margin-left: 7px;
        }

        .header-nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .header-nav ul li a:hover {
            background: #fff;
            color: black;
        }
    </style>
</head>

<body>
    <!-- Registration Form -->
    <div class="custom-container">
        <h1 class="text-center mb-4 text-dark">Registration Form</h1>
        <form id="registrationForm" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="buildingName" class="text-dark">Name of Building</label>
                        <input type="text" class="form-control" id="buildingName" name="buildingName" required>
                    </div>
                    <div class="form-group">
                        <label for="buildingHeight" class="text-dark">Building Height (in meters)</label>
                        <input type="number" step="1" class="form-control" id="buildingHeight" name="buildingHeight" required min="0">
                    </div>
                    <div class="form-group">
                        <label for="squareMeters" class="text-dark">Total Area (in square meters)</label>
                        <input type="number" step="1" class="form-control" id="squareMeters" name="squareMeters" required min="0">
                    </div>
                    <div class="form-group">
                        <label for="numberOfFloors" class="text-dark">Number of Floors</label>
                        <input type="number" class="form-control" id="numberOfFloors" name="numberOfFloors" required min="0">
                    </div>
                    <div class="form-group">
                        <label for="businessAddress" class="text-dark">Business Address</label>
                        <select class="form-control" id="businessAddress" name="businessAddress" required>
                            <option value="">Select San Fernando City</option>
                            <option value="District I">District I</option>
                            <option value="District II">District II</option>
                            <option value="District III">District III</option>
                            <option value="District IV">District IV</option>
                            <option value="District V">District V</option>
                            <option value="District VI">District VI</option>
                            <option value="District VII">District VII</option>
                            <option value="District VIII">District VIII</option>
                            <option value="District IX">District IX</option>
                            <option value="District X">District X</option>
                            <option value="District XI">District XI</option>
                            <option value="District XII">District XII</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="barangay" class="text-dark">Barangay</label>
                        <select class="form-control" id="barangay" name="barangay" required>
                            <option value="">Select Barangay</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="owner" class="text-dark">Name of Owner/Representative</label>
                        <input type="text" class="form-control" id="owner" name="owner" required>
                    </div>
                    <div class="form-group">
                        <label for="contactNumber" class="text-dark">Contact Number</label>
                        <input type="text" class="form-control" id="contactNumber" name="contactNumber"  required maxlength = "11">
                    </div>
                    <div class="form-group">
                        <label for="businessNature" class="text-dark">Nature of Business</label>
                        <input type="text" class="form-control" id="businessNature" name="businessNature" required>            
                    </div>
                    <div class="form-group">
                        <label for="businessName" class="text-dark">Business Name</label>
                        <input type="text" class="form-control" id="businessName" name="businessName" required>
                    </div>
                    <div class="form-group">
                        <label for="Occupancy" class="text-dark">Type of Occupancy</label>
                        <select class="form-control" id="Occupancy" name="Occupancy" required>
                            <option value="">Select Occupancy</option>
                            <option value="Mercantile">Mercantile</option>
                            <option value="Business">Business</option>
                            <option value="Places of Assembly">Places of Assembly</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Educational">Educational</option>
                            <option value="Residential">Residential</option>
                            <option value="Industrial">Industrial</option>
                            <option value="Storage">Storage</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="DTIPhotos" class="text-dark">Upload DTI Photo</label>
                        <input type="file" class="form-control" id="DTIPhotos" name="DTIPhotos" accept="image/*" required>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="reset" class="btn btn-secondary">Clear</button>
            </div>
        </form>

        <!-- Bootstrap JS and dependencies -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <!-- SweetAlert JS -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script>
            $(document).ready(function () {
                const barangays = {
                    "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
                    "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
                    "District III": ["Catbangen", "Parian", "Madayegdeg"],
                    "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
                    "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
                    "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
                    "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
                    "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
                    "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
                    "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
                    "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
                    "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
                };

                $('#businessAddress').change(function () {
                    const district = $(this).val();
                    const barangaySelect = $('#barangay');

                    barangaySelect.empty();
                    barangaySelect.append('<option value="">Select Barangay</option>');

                    if (district in barangays) {
                        barangays[district].forEach(barangay => {
                            barangaySelect.append(new Option(barangay, barangay));
                        });
                    }
                });

                $('#registrationForm').on('submit', function (e) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Confirm Submission',
                        text: "Are you sure you want to submit?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'register.php',
                                type: 'POST',
                                data: new FormData(this),
                                processData: false,
                                contentType: false,
                                dataType: 'json',
                                success: function (response) {
                                    if (response.status === "success") {
                                        Swal.fire({
                                            title: 'Processing',
                                            html: `Registration is being processed. Your tracking number is <strong>${response.trackingNumber}</strong> <button class="btn btn-sm btn-primary" onclick="copyToClipboard('${response.trackingNumber}')">Copy</button>`,
                                            icon: 'info',
                                            confirmButtonText: 'OK'
                                        }).then(() => {
                                            window.location.reload();  // Reload the page after success confirmation
                                        });
                                    } else {
                                        Swal.fire({
                                            title: 'Error',
                                            text: response.message || 'Unknown error occurred.',
                                            icon: 'error',
                                            confirmButtonText: 'OK'
                                        });
                                    }
                                },
                                error: function (xhr, status, error) {
                                    Swal.fire({
                                        title: 'Error',
                                        text: 'There was an error processing your registration.',
                                        html: `<pre>${xhr.responseText}</pre>`,  // Display detailed error message
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                }
                            });
                        }
                    });
                });
            });

            function copyToClipboard(text) {
                navigator.clipboard.writeText(text).then(function () {
                    Swal.fire({
                        title: 'Copied',
                        text: 'Tracking number copied to clipboard',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    });
                }, function (err) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Could not copy to clipboard',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                });
            }
        </script>
</body>

</html>
