<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "bfp_db";
$data = mysqli_connect($host, $user, $password, $db);

if ($data === false) {
    die("Connection error: " . mysqli_connect_error());
}

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Log the logout activity
    $activity_type = 'logout';
    $activity_desc = 'User logged out';
    
    // Prepare the SQL statement
    $log_sql = "INSERT INTO tbl_activity_log (id, activity_type, activity_time, activity_desc)
                VALUES (?, ?, NOW(), ?)";
    
    // Use prepared statements for security
    $stmt = mysqli_prepare($data, $log_sql);
    mysqli_stmt_bind_param($stmt, 'sss', $user_id, $activity_type, $activity_desc);

    // Execute the statement and check for errors
    if (!mysqli_stmt_execute($stmt)) {
        die("Logging failed: " . mysqli_error($data));
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);
}

// Destroy the session
session_destroy();

// Redirect to login page
header("Location:login.php");
exit();
?>
