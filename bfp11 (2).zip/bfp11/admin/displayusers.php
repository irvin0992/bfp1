<?php include('../session_validate.php'); ?>
<?php include('../header/header.php'); ?>
<!-- ============================================================== -->
<!-- end navbar -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- left sidebar -->
<!-- ============================================================== -->
<?php include('../sidebar/sidebar.php'); ?>
<!-- ============================================================== -->
<!-- end left sidebar -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- wrapper  -->
<!-- ============================================================== -->
<?php include '../connection.php' ?>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>

                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Users</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
        <style>
            .modal-header {
                background-color: #dc3545;
                border-bottom: none;
            }

            .modal-body {
                font-size: 1.1rem;
            }

            .modal-footer {
                border-top: none;
                justify-content: center;
            }

            .btn-outline-success,
            .btn-outline-info {
                width: 48%;
                padding: 15px;
                font-size: 1rem;
            }

            .btn-outline-success:hover,
            .btn-outline-info:hover {
                background-color: #28a745;
                color: #fff;
            }

            .btn-outline-info:hover {
                background-color: #17a2b8;
                color: #fff;
            }

            /* Increase size of the action icons */
            td .fa-edit,
            td .fa-eye {
                font-size: 20px;
                /* Increase size of icons */
                margin-right: 10px;
                /* Add space between icons */
            }

            /* Add padding around the table cells */
            td {
                padding: 15px;
            }

            /* Improve hover effect for icons */
            td a {
                transition: transform 0.2s ease, color 0.2s ease;
            }

            /* On hover, make the icons larger and change color */
            td a:hover {
                color: #007bff;
                /* Change color on hover */
                transform: scale(1.2);
                /* Slightly increase size */
            }

            /* Add a responsive table layout */
            table {
                width: 100%;
                /* Ensure table spans full width */
                max-width: 100%;
                margin-bottom: 1rem;
                background-color: transparent;
                border-spacing: 0;
                border-collapse: collapse;
            }

            /* Make the table more user-friendly on smaller screens */
            @media (max-width: 768px) {

                table td,
                table th {
                    font-size: 14px;
                    padding: 10px;
                }

                td .fa-edit,
                td .fa-eye {
                    font-size: 18px;
                }
            }
        </style>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header"><i class="fa fa-fw fa-user-lock"></i> Users Information</h5>
                    <div class="card-body">
                        <div id="message"></div>
                        <!-- Button to trigger modal -->
                        <button type="button" class="btn btn-sm"
                            style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                            data-toggle="modal" data-target="#addUserModal">
                            <i class="fa fa-fw fa-user-plus"></i> Add User
                        </button><br><br>

                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-striped table-bordered first">
                                <thead style="position: sticky; top: 0; background-color: #fff; z-index: 1;">
                                    <tr>
                                        <th scope="col">Username</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Userlevel</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $view = mysqli_query($conn, "SELECT * from tbl_users ORDER BY id desc");
                                    while ($data = mysqli_fetch_assoc($view)) {
                                        $id = $data['id'];
                                        $username = $data['username'];
                                        $fname = $data['fname'];
                                        $mname = $data['mname'];
                                        $lname = $data['lname'];
                                        $userlevel = $data['userlevel'];
                                        $status = $data['status'];
                                        ?>
                                        <tr>
                                            <td><?php echo $username; ?></td>
                                            <td><?php echo htmlspecialchars($lname . ', ' . $fname . ' ' . $mname); ?></td>
                                            <td><?php echo $userlevel; ?></td>

                                            <td>
                                                <?php if ($status == 1) { ?>
                                                    <!-- Dark red for Inactive -->
                                                    <a onclick="Active('<?php echo $username; ?>', '<?php echo $userlevel; ?>')"
                                                        type="button" style="background-color: #b30000; color: white;"
                                                        class="btn btn-secondary">Inactive</a>
                                                <?php } else { ?>
                                                    <!-- Light red for Active -->
                                                    <?php if ($userlevel === 'Administrator' || $userlevel === 'Fire Marshall') { ?>
                                                        <a onclick="Inactive('<?php echo $username; ?>', '<?php echo $userlevel; ?>')"
                                                            type="button" class="btn"
                                                            style="background-color: #ff0000; color: white;" <?php echo $status == 1 ? 'disabled' : ''; ?>>Active</a>
                                                    <?php } else { ?>
                                                        <a onclick="Inactive('<?php echo $username; ?>', '<?php echo $userlevel; ?>')"
                                                            type="button" class="btn"
                                                            style="background-color: #ff0000; color: white;">Active</a>
                                                    <?php } ?>
                                                <?php } ?>
                                            </td>

                                            <td class="align-right">
                                                <!-- Edit user icon -->
                                                <a href="javascript:void(0);" onclick="editUser(<?php echo $data['id']; ?>)"
                                                    class="text-secondary font-weight-bold text-xs" data-toggle="tooltip"
                                                    data-original-title="Edit user">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <!-- View user icon -->
                                                <a href="javascript:void(0);" onclick="viewUser(<?php echo $data['id']; ?>)"
                                                    class="text-secondary font-weight-bold text-xs" data-toggle="tooltip"
                                                    data-original-title="View user">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-white">
                    <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="addUserForm" action="add-user-process.php" method="POST">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" id="username" name="username"
                                oninput="checkUsername()" required>
                            <span id="check_username" for="username"></span>
                        </div>

                        <script>
                            function checkUsername() {
                                jQuery.ajax({
                                    url: "userVerif.php",
                                    data: 'username=' + $("#username").val(),
                                    type: "POST",
                                    success: function (data) {
                                        $("#check_username").html(data);
                                    },
                                    error: function () { }
                                });
                            }
                        </script>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" required minlength="8" id="pword"
                                class="form-control" oninput="checkPassword()" required>
                            <input type="checkbox" id="show_password" onclick="togglePasswordVisibility()"> Show
                            Password
                            <span id="check_password" for="password"></span>
                        </div>

                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="confirmpassword" required minlength="8" id="cpword"
                                class="form-control" oninput="checkPassword()" required>
                            <span id="check_confirm_password" for="confirmpassword"></span>
                        </div>

                        <script>
                            function checkPassword() {
                                var password = $("#pword").val();
                                var confirmPassword = $("#cpword").val();
                                var minLength = 8;
                                var passwordMessage = '';
                                var confirmPasswordMessage = '';
                                var passwordColor = '';
                                var confirmPasswordColor = '';

                                // Check password length
                                if (password.length < minLength) {
                                    passwordMessage = 'Password must be at least ' + minLength + ' characters long.';
                                    passwordColor = 'red';
                                } else {
                                    passwordMessage = 'Password is valid.';
                                    passwordColor = 'green';
                                }

                                // Update password message
                                $("#check_password").html(passwordMessage).css('color', passwordColor);

                                // Check if passwords match
                                if (password && confirmPassword) {
                                    if (password !== confirmPassword) {
                                        confirmPasswordMessage = 'Passwords do not match.';
                                        confirmPasswordColor = 'red';
                                    } else {
                                        confirmPasswordMessage = 'Passwords match.';
                                        confirmPasswordColor = 'green';
                                    }
                                } else {
                                    confirmPasswordMessage = ''; // Clear message if either field is empty
                                    confirmPasswordColor = ''; // Clear color if either field is empty
                                }

                                // Update confirm password message
                                $("#check_confirm_password").html(confirmPasswordMessage).css('color', confirmPasswordColor);
                            }

                            function togglePasswordVisibility() {
                                var passwordField = document.getElementById("pword");
                                var confirmPasswordField = document.getElementById("cpword");
                                var showPasswordCheckbox = document.getElementById("show_password");

                                // Toggle password visibility based on checkbox status
                                if (showPasswordCheckbox.checked) {
                                    passwordField.type = "text";
                                    confirmPasswordField.type = "text";
                                } else {
                                    passwordField.type = "password";
                                    confirmPasswordField.type = "password";
                                }
                            }
                        </script>

                        <div class="form-group">
                            <label>Firstname</label>
                            <input type="text" name="fname" id="fname" class="form-control" required
                                oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                        </div>
                        <div class="form-group">
                            <label>Middlename</label>
                            <input type="text" name="mname" id="mname" class="form-control" required
                                oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                        </div>
                        <div class="form-group">
                            <label>Lastname</label>
                            <input type="text" name="lname" id="lname" class="form-control" required
                                oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                        </div>

                        <div class="form-group">
                            <label for="userlevel">UserLevel</label>
                            <select class="form-control" id="userlevel" name="userlevel" required>
                                <option value="" disabled selected>Select User Level</option>
                                <option value="Administrator">Administrator</option>
                                <option value="Inspector">Inspector</option>
                                <option value="Fire Marshall">City Fire Marshall</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header text-white">
                <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editUserForm" action="edit-user-process.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" id="editUserId" name="id">
                    <div class="form-group">
                        <label for="editUsername">Username</label>
                        <input type="text" class="form-control" id="editUsername" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="editFname">Firstname</label>
                        <input type="text" name="fname" id="editFname" class="form-control" required
                            pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                            oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                    </div>
                    <div class="form-group">
                        <label for="editMname">Middlename</label>
                        <input type="text" name="mname" id="editMname" class="form-control" required
                            pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                            oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                    </div>
                    <div class="form-group">
                        <label for="editLname">Lastname</label>
                        <input type="text" name="lname" id="editLname" class="form-control" required
                            pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                            oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================================== -->
<!-- end main wrapper -->
<!-- ============================================================== -->
<!-- Optional JavaScript -->
<script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
<script src="../assets/libs/js/main-js.js"></script>
<script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
<script src="../assets/vendor/datatables/js/data-table.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Function to activate a user
    function Active(username, userlevel) {
        swal.fire({
            title: 'Are you sure?',
            text: "Do you want to activate this user?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, activate it!'
        }).then((result) => {
            if (result.isConfirmed) {
                updateUserStatus(username, userlevel, 'activate');
            }
        });
    }

    // Function to deactivate a user
    function Inactive(username, userlevel) {
        swal.fire({
            title: 'Are you sure?',
            text: "Do you want to deactivate this user?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, deactivate it!'
        }).then((result) => {
            if (result.isConfirmed) {
                updateUserStatus(username, userlevel, 'deactivate');
            }
        });
    }

    // Function to send the status update to the server
    function updateUserStatus(username, userlevel, action) {
        $.ajax({
            url: 'update-user-status.php',
            type: 'POST',
            data: {
                username: username,
                userlevel: userlevel,
                action: action
            },
            success: function (response) {
                if (response === 'success') {
                    swal.fire({
                        title: 'Success!',
                        text: 'User status has been updated.',
                        icon: 'success'
                    }).then(() => {
                        location.reload(); // Reload the page to update the status display
                    });
                } else {
                    swal.fire('Error!', 'There was an issue updating the user status.', 'error');
                }
            }
        });
    }

    $(document).ready(function () {
        $('#addUserForm').submit(function (e) {
            e.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to add this data?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, add it!',
                cancelButtonText: 'No, cancel!',
                customClass: {
                    confirmButton: 'swal2-confirm-custom',
                    cancelButton: 'swal2-cancel-custom'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: $(this).attr('action'),
                        type: 'POST',
                        data: $(this).serialize(),
                        success: function (response) {
                            if (response == 'success') {
                                Swal.fire(
                                    'Added!',
                                    'New user has been added.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else if (response == 'exists') {
                                Swal.fire(
                                    'Error!',
                                    'Username already exists.',
                                    'error'
                                );
                            } else if (response == 'password_mismatch') {
                                Swal.fire(
                                    'Error!',
                                    'Passwords do not match.',
                                    'error'
                                );
                            } else {
                                Swal.fire(
                                    'Error!',
                                    'There was an error adding the user: ' + response, // Show the exact error response
                                    'error'
                                );
                            }
                        },
                        error: function (xhr, status, error) {
                            // Handle AJAX error
                            Swal.fire(
                                'Error!',
                                'AJAX request failed: ' + error,
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });

</script>

<script>
    function editUser(userId) {
        // Make an AJAX call to fetch the user data
        $.ajax({
            url: 'get-user-data.php',
            type: 'POST',
            data: { id: userId },
            success: function (response) {
                let user = JSON.parse(response);
                $('#editUserId').val(user.id);
                $('#editUsername').val(user.username);
                $('#editFname').val(user.fname);
                $('#editMname').val(user.mname);
                $('#editLname').val(user.lname);
                $('#editUserlevel').val(user.userlevel);
                $('#editStatus').val(user.status);
                $('#editUserModal').modal('show');
            }
        });
    }

    $(document).ready(function () {
        $('#editUserForm').submit(function (e) {
            e.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to update this user.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: $(this).attr('action'),
                        type: 'POST',
                        data: $(this).serialize(),
                        success: function (response) {
                            if (response == 'success') {
                                Swal.fire(
                                    'Updated!',
                                    'User details have been updated.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else if (response == 'exists') {
                                Swal.fire(
                                    'Error!',
                                    'Username already exists.',
                                    'error'
                                );
                            } else {
                                Swal.fire(
                                    'Error!',
                                    'There was an error updating the user.',
                                    'error'
                                );
                            }
                        }
                    });
                }
            });
        });
    });
</script>