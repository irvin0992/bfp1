<?php
// Include database connection
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data from the AJAX request
    $registrationId = $_POST['registration_id'];
    $status = $_POST['statusSelect']; // The status selected in the modal
    $remarks = $_POST['remarks'];

    // Begin a transaction to ensure both operations happen together
    $conn->begin_transaction();

    try {
        // Determine the status to be updated in tbl_registrations and inserted into tbl_inspections
        if ($status === "verified") {
            $registrationStatus = "Passed";
            $inspectionStatus = "Passed";
        } else {
            $registrationStatus = "Denied";
            $inspectionStatus = "Denied";
        }

        // Update the status in tbl_registrations based on the user's selection
        $updateRegistrationSql = "UPDATE tbl_registrations SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($updateRegistrationSql);
        $stmt->bind_param("si", $registrationStatus, $registrationId);
        $stmt->execute();

        // Insert the status and remarks into tbl_inspections
        $insertInspectionSql = "INSERT INTO tbl_inspections (registration_id, status, remarks) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insertInspectionSql);
        $stmt->bind_param("iss", $registrationId, $inspectionStatus, $remarks);
        $stmt->execute();

        // Commit the transaction
        $conn->commit();

        echo "success"; // Send success response
    } catch (Exception $e) {
        // Rollback the transaction if any query fails
        $conn->rollback();
        echo "error: " . $e->getMessage(); // Send error response
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
