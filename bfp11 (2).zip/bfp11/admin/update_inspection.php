<?php
// Include your database connection file
include '../connection.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if form is submitted and process the update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form data
    $businessName = $_POST['businessName'];
    $inspectorName = $_POST['inspectorName'];
    $inspectionDate = $_POST['inspectionDate'];
    $inspectionId = $_POST['inspectionId'];
    $dateIssued = date('Y-m-d'); // Set date_issued to today's date

    // Start a transaction
    $conn->begin_transaction();

    try {
        // First, fetch the current status of the inspection and the email from tbl_applications
        $getStatusQuery = "SELECT i.status, r.email FROM tbl_inspections i
                           INNER JOIN tbl_applications r ON i.application_id = r.application_id
                           INNER JOIN tbl_businesses b ON r.business_id = b.business_id
                           WHERE i.inspection_id = ? AND b.business_name = ?";
        $stmtGetStatus = $conn->prepare($getStatusQuery);
        $stmtGetStatus->bind_param("is", $inspectionId, $businessName);
        $stmtGetStatus->execute();
        $resultStatus = $stmtGetStatus->get_result();

        if ($resultStatus && $resultStatus->num_rows > 0) {
            $row = $resultStatus->fetch_assoc();
            $currentStatus = $row['status'];
            $applicantEmail = $row['email']; // Fetch email from tbl_applications

            if ($currentStatus === 'Reinspection') {
                $newStatus = 'Ready for Reinspection';  // Change to 'Reinspection'
            } else {
                $newStatus = 'Ready for Inspection'; // Fallback status if neither matches
            }

            // Update inspection details
            $updateInspectionQuery = "UPDATE tbl_inspections i
                                      INNER JOIN tbl_applications r ON i.application_id = r.application_id
                                      INNER JOIN tbl_businesses b ON r.business_id = b.business_id
                                      SET i.inspector_fname = ?, i.inspector_mname = ?, i.inspector_lname = ?, i.inspection_date = ?, i.status = ?, i.date_issued = ?
                                      WHERE i.inspection_id = ? AND b.business_name = ?";
          $stmt1 = $conn->prepare($updateInspectionQuery);

          // Assuming `inspectorName` is full name (fname, mname, lname), you need to split it into parts:
          $inspectorNameParts = explode(' ', $inspectorName); 
          $inspectorFname = $inspectorNameParts[0]; // First name
          $inspectorMname = isset($inspectorNameParts[1]) ? $inspectorNameParts[1] : ''; // Middle name (optional)
          $inspectorLname = isset($inspectorNameParts[2]) ? $inspectorNameParts[2] : ''; // Last name
          
          $stmt1->bind_param("ssssssis", $inspectorFname, $inspectorMname, $inspectorLname, $inspectionDate, $newStatus, $dateIssued, $inspectionId, $businessName);
          
          // Execute the statement
          $stmt1->execute();
          

            // Check if the update was successful
            if ($stmt1->affected_rows > 0) {
                // Commit the transaction
                $conn->commit();

                // Send email using PHPMailer
                $mail = new PHPMailer(true);
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'bfp.sflu@gmail.com'; // Replace with your Gmail
                    $mail->Password   = 'dxjg cfci fpvc yqjr';   // Replace with your app password
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port       = 465;

                    // Recipient
                    $mail->setFrom('bfp.sflu@gmail.com', 'Bureau of Fire Protection'); // Replace with your Gmail and name
                    $mail->addAddress($applicantEmail); // Send to the applicant's email fetched from the database

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Ready for Inspection';

                   // Update the email content to include the inspection date
            $mail->Body = '
            <div style="font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;">
                <div style="background-color: #001f3f; padding: 15px; border-radius: 5px; text-align: center;">
                    <h1 style="color: #fff; margin: 0;">Ready for Inspection</h1>
                </div>
                <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;">
                    <p style="font-size: 16px; color: #001f3f;">
                        Dear Applicant,
                    </p>
                    <p style="font-size: 16px; color: #001f3f;">
                        Your inspection status has been updated to <strong>' . $newStatus . '</strong>.
                    </p>
                    <p style="font-size: 16px; color: #001f3f;">
                        The scheduled date for your inspection is <strong>' . $inspectionDate . '</strong>.
                    </p>
                    <p style="font-size: 14px; color: #777;">
                        Regards, <br> Bfp-sflu
                    </p>
                </div>
                <div style="text-align: center; font-size: 12px; color: #999; margin-top: 20px;">
                    <p>This is an automated message. Please do not reply to this email.</p>
                </div>
            </div>';


                    // Attach the logo and set its Content-ID (optional)
                    $mail->addEmbeddedImage('../images/bfp-logo.png', 'bfp-logo');

                    // Send email
                    $mail->send();
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }

                echo "success";
            } else {
                // Rollback the transaction
                $conn->rollback();
                echo "error updating tbl_inspections: " . $stmt1->error;
            }

            // Close update statement for tbl_inspections
            $stmt1->close();
        } else {
            // Rollback the transaction
            $conn->rollback();
            echo "error fetching current status: " . $stmtGetStatus->error;
        }

        // Close the statement for fetching the status
        $stmtGetStatus->close();
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        echo "error: " . $e->getMessage();
    }
}
?>