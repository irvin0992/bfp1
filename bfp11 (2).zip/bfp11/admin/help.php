 
        <!-- screencaps -->
        <!-- For User Management Slider -->
        <div class="slider">
            <div class="slides" id="userManagementSlides"> <!-- Unique ID -->
                <div class="slide">
                    <img src="css/screenshots/usermanagementadd.png" alt="Image 1">
                    <div class="caption">Add User</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/usermanagementupd.png" alt="Image 2">
                    <div class="caption">Update User</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/usermanagementstat.png" alt="Image 3">
                    <div class="caption">Activate/Deactivate User</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'userManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'userManagementSlides')">❯</button>
        </div>

        <div class="mt-4">
            <p style="color: #666; font-weight: 900;">Adding New Users:</p>
            <ul style="color: #666;">
                <li>1. Navigate to the User Management tab.</li>
                <li>2. Click Add New User.</li>
                <li>3. Fill in user details (username, password, userlevel, firstname, lastname.).</li>
                <li>4. Click Add.</li>
            </ul>
            <p style="color: #666; font-weight: 900;">Editing/Updating User Details:</p>
            <ul style="color: #666;">
                <li>1. Under the User Management section, locate the user.</li>
                <li>2. Click Edit under Actions.</li>
                <li>3. Update the necessary fields (username, password, userlevel, firstname, lastname.).</li>
                <li>4. Save the changes by clicking Submit.</li>
            </ul>
            <p style="color: #666; font-weight: 900;">Managing User Status:</p>
            <ul style="color: #666;">
                <li>1. Click the Status Button to Activate/Deactivate.</li>
                <li>2. Confirm the Action.</li>
                <li>3. Save the changes.</li>
            </ul>
        </div>
            <hr>
        </section>

        <!-- Product Management -->
        <section id="product-management">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Product Management</h3>
            <p style="color: #666;">Product Management helps in managing product data, including adding new products, updating details, and deleting outdated products.</p>


        <!-- screencaps -->
        <!-- Product Management Slider -->
        <div class="slider">
            <div class="slides" id="productManagementSlides">
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 1">
                    <div class="caption">Add Product</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 2">
                    <div class="caption">Update Product</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 3">
                    <div class="caption">Product</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'productManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'productManagementSlides')">❯</button>
        </div>

        <div class="mt-4">
            <p style="color: #666; font-weight: 900;">Adding New Products:</p>
            <ul style="color: #666;">
                <li>1. Go to the Product Management tab.</li>
                <li>2. Click Add New Product Button.</li>
                <li>3. Enter the product category, name, stock category, and order level.</li>
                <li>4. Click Submit butotn to save the Product.</li>
            </ul>
            <hr>
        </div>
        </section>

        <!-- Purchase Requisition Management -->
        <section id="pr-management">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Purchase Requisition Management</h3>
            <p style="color: #666;">This process ensures that stock requests are carefully reviewed and approved at each level, from the bookstore clerk up to the purchasing officer, ensuring transparency, accountability, and efficiency. By following this systematic approach, the bookstore can manage its inventory effectively, avoid stockouts, and maintain seamless operations.</p>

        <!-- screencaps -->
        <!-- pr Management Slider -->
        <div class="slider">
            <div class="slides" id="prManagementSlides">
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 1">
                <div class="caption">Add Form</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 2">
                    <div class="caption">Add Stock</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 3">
                    <div class="caption">Update Stock</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'prManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'prManagementSlides')">❯</button>
        </div>

        <div class="mt-4">
            <p style="color: #666; font-weight: bold;">Submission of Requisition Form by Bookstore Clerk::</p>
            <ul style="color: #666;">
                <li>1. The process begins when the bookstore clerk identifies the need for additional stock of books or other supplies.</li>
                <li>2. The clerk submits a purchase requisition form through the system, detailing the items required, quantities, and any other relevant information.</li>
                <li>3. This form serves as an official request to initiate the purchase process.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Verification by the Treasurer::</p>
            <ul style="color: #666;">
                <li>1. Once the form is submitted, it is sent to the Treasurer for initial verification.</li>
                <li>2. The Treasurer reviews the requisition details, checking for accuracy, budget availability, and compliance with financial guidelines.</li>
                <li>3. If the request is verified and all conditions are met, the Treasurer approves the form, allowing it to proceed to the next step.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Approval by the VP of Administration:</p>
            <ul style="color: #666;">
                <li>1. After the Treasurer’s verification, the requisition form is forwarded to the Vice President of Administration (VP Admin) for further approval.</li>
                <li>2. The VP Admin assesses the request to ensure it aligns with the overall operational needs and policies of the bookstore and the institution.</li>
                <li>3. Once the VP Admin approves, the requisition is authorized to move forward in the process.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Processing by the Purchasing Officer:</p>
            <ul style="color: #666;">
                <li>1. The approved requisition form is then routed to the Purchasing Officer.</li>
                <li>2. The Purchasing Officer is responsible for executing the purchase, coordinating with suppliers, and managing the procurement of the requested stock.</li>
                <li>3. They ensure that the purchase is conducted efficiently, and all items requested are ordered in a timely manner.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Notification to Bookstore Clerk:</p>
            <ul style="color: #666;">
                <li>1. After the purchase order is processed and the stock is confirmed as ready, the system automatically generates a notification for the bookstore clerk.</li>
                <li>2. This notification informs the clerk that the requested items are now available and ready for use in the bookstore.</li>
            </ul>
        </div>
            <hr>
        </section>

        <!-- Inventory Management -->
        <section id="inventory-management">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Inventory Management</h3>
            <p style="color: #666;">The Inventory Management module is designed to help users efficiently track, manage, and update stock levels of products in the system. This module ensures that inventory quantities are accurate, helps prevent stockouts, and provides an organized way to handle all stock-related activities.</p>

        <!-- screencaps -->
        <!-- Inventory Management Slider -->
        <div class="slider">
            <div class="slides" id="inventoryManagementSlides">
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 1">
                    <div class="caption">View Inventory</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 2">
                    <div class="caption">Add Stock</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 3">
                    <div class="caption">Update Stock</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'inventoryManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'inventoryManagementSlides')">❯</button>
        </div>

        <div class="mt-4">
            <p style="color: #666; font-weight: bold;">Viewing Inventory:</p>
            <ul style="color: #666;">
                <li>Navigate to the Inventory Management section.</li>
                <li>View the list of products and their current stock levels.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Adding Stock:</p>
            <ul style="color: #666;">
                <li>Select the product that needs stock adjustment.</li>
                <li>Click Add Stock.</li>
                <li>Enter the quantity to add and confirm.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Updating Inventory:</p>
            <ul style="color: #666;">
                <li>Locate the product.</li>
                <li>Select Update Stock.</li>
                <li>Modify the stock number and click Save Changes.</li>
            </ul>
            <p style="color: #666; font-weight: bold;">Handling Low Stock Alerts:</p>
            <ul style="color: #666;">
                <li>Set up Low Stock Thresholds in Inventory Settings.</li>
                <li>The system will automatically notify when product levels drop below the set threshold.</li>
            </ul>
        </div>
            <hr>
        </section>

        <!-- Transaction Management -->
        <section id="transaction-management">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Transaction Management</h3>
            <p style="color: #666;">The Transaction Management module allows users to handle sales transactions efficiently, providing a seamless way to record purchases, manage payments, and keep track of all sales activities. This module is designed to streamline the checkout process, making it easier for bookstore clerks to process sales with multiple payment options.</p>

        <!-- screencaps -->
        <!-- Transation Management Slider -->
        <div class="slider">
            <div class="slides" id="transactionManagementSlides">
                <div class="slide">
                    <img src="css/screenshots/transactmanagementadd.png" alt="Image 1">
                    <div class="caption">Add Product</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/transactmanagementprodview.png" alt="Image 2">
                    <div class="caption">Product View - Select Product</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/transactmanagementadd.png" alt="Image 3">
                    <div class="caption">Update Stock</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'transactionManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'transactionManagementSlides')">❯</button>
        </div>

        
            <p style="color: #666; font-weight:bold;">Navigate to the Transaction Management Tab:</p>
            <ul style="color: #666;">
                <li>1. From the sidebar, click on the “Transaction Management” tab to open the transaction module.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Input Products:</p>
            <ul style="color: #666;">
                <li>1. Use the search bar or browse the product list to select the items the buyer is purchasing.</li>
                <li>2. Input the quantity for each product to automatically calculate the total amount.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Choose Payment Method:</p>
            <p>1. The system offers two payment options: Cash and Charge.</p>
            <p style="font-weight:bold;">Cash Payment:</p>
            <ul style="color: #666;">
                <li>1. Select the “Cash” option if the buyer chooses to pay with cash.</li>
                <li>2. Enter the amount received from the customer, and the system will display the change to be given.</li>
                <li>3. Complete the transaction by clicking “Pay” to finalize the sale.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Charge Payment (Salary Deduction):</p>
            <ul style="color: #666;">
                <li>1. Select the “Charge” option if the buyer is a faculty member opting for a salary deduction.</li>
                <li>2. Enter the required faculty details, such as employee ID, to validate the charge.</li>
                <li>3. Confirm the transaction, and it will be recorded as a charge against the faculty member’s account, to be deducted from their salary.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Managing Payment Methods:</p>
            <p style="font-weight:bold;">Cash Transactions:</p>
            <ul style="color: #666;">
                <li>1. Cash payments are straightforward and processed immediately at the point of sale. Ensure that the cash received matches the amount due, and issue change as necessary.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Charge Transactions for Faculty Members:</p>
            <ul style="color: #666;">
                <li>1. Charge payments are exclusive to authorized faculty members. The amount charged is recorded in the system and is reflected in the employee’s account for future salary deduction.</li>
                <li>2. Ensure that all charges are validated and documented accurately to maintain transparency in salary deductions.</li>
            </ul>
            <hr>
        </section>

        <!-- Report Generation -->
        <section id="report-generation">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Report Generation</h3>
            <p style="color: #666;">The Report Generation Management module is a vital tool for monitoring and analyzing your bookstore’s operations. This module allows users to generate comprehensive reports on transactions, sales, and charges, helping you keep track of business performance over time. With flexible date range filters and various report formats, you can easily access and print the data you need.</p>
            
        <!-- screencaps -->
        <!-- Inventory Management Slider -->
        <div class="slider">
            <div class="slides" id="reportManagementSlides">
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 1">
                    <div class="caption">View Inventory</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 2">
                    <div class="caption">Add Stock</div>
                </div>
                <div class="slide">
                    <img src="css/screenshots/productmanagementadd.png" alt="Image 3">
                    <div class="caption">Update Stock</div>
                </div>
            </div>
            <button class="button prev" onclick="changeSlide(-1, 'reportManagementSlides')">❮</button>
            <button class="button next" onclick="changeSlide(1, 'reportManagementSlides')">❯</button>
        </div>
        
            <p style="color: #666; font-weight:bold;">Navigate to the Report Management Tab:</p>
            <ul style="color: #666;">
                <li>1. From the sidebar, click on the “Report Management” tab to open the report generation module.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Customizing Reports:</p>
            <ul style="color: #666;">
                <li>1. Sales Reports: Access a summary of all sales activities, showing total revenue generated.</li>
                <li>2. Charged Reports: Review all charged transactions for faculty members, including details of each salary deduction.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Filter by Date Range:</p>
            <ul style="color: #666;">
                <li>Common date ranges include:</li>
                <li>Weekly: See data for a selected week.</li>
                <li>Monthly: Review reports by month, helping you analyze performance trends.</li>
                <li>Yearly: Access annual reports for a broader overview of operations.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Generate the Report:</p>
            <ul style="color: #666;">
                <li>1. Click the “Generate Report” button to display the filtered data. The system will show the relevant details according to your selected criteria.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Review Report Details:</p>
            <ul style="color: #666;">
                <li>1. Review the generated report, which will include all relevant information based on your selection, such as product names, quantities, sales totals, and charge details.</li>
            </ul>
            <p style="color: #666; font-weight:bold;">Printing Reports:</p>
            <p style="color: #666; font-weight:bold;    ">Click on the “Print” button to print the report. You can choose to print in various formats</p>
            <ul style="color: #666;">
                <li><strong>Daily Report:</strong> Ideal for end-of-day reviews and cash reconciliations.</li>
                <li><strong>Weekly Report:</strong> Helps identify weekly sales trends and staff performance.</li>
                <li><strong>Monthly Report:</strong> Useful for monthly evaluations, inventory planning, and management meetings.</li>
                <li><strong>Yearly Report:</strong> Provides a comprehensive overview of annual performance, useful for financial planning and strategic decisions.</li>
            </ul>
            <hr>
        </section>

        <!-- Troubleshooting -->
        <section id="troubleshooting">
            <h3 style="color: #555; font-weight:bold; font-size: 30px;">▪ Troubleshooting & FAQs</h3>
            <p style="color: #666;">Cannot add new users? Check your role’s permissions under the User Management section.</p>
            <p style="color: #666;">Inventory levels incorrect? Review transaction history and stock adjustments.</p>
            <p style="color: #666;">Reports not generating? Confirm that the date range and filters are correctly set.</p>
            <p style="color: #666;">Payment issues? Verify that the payment gateway is properly configured in the Transaction Settings.</p>
            <p style="color: #666;">For further assistance, please contact the system administrator or support team at <strong>[Support Email]</strong> or call <strong>[Support Phone Number]</strong>.</p>
            <hr>
        </section>
    </div>
</div>
</div>


<!-- JavaScript to handle search and display -->
<script>
document.getElementById('search-bar').addEventListener('input', function() {
    const query = this.value.toLowerCase();
    const sections = document.querySelectorAll('#manual-content section');
    const resultsList = document.getElementById('search-results');
    let hasResults = false;

    // Clear previous results
    resultsList.innerHTML = '';

    sections.forEach(section => {
        const text = section.innerText.toLowerCase();
        const title = section.querySelector('h3').innerText;
        if (text.includes(query)) {
            const resultItem = document.createElement('li');
            resultItem.style.cursor = 'pointer';
            resultItem.style.color = '#007bff';
            resultItem.style.padding = '5px 0';
            resultItem.innerText = title;
            resultItem.addEventListener('click', function() {
                displaySection(section.id);
            });

            resultsList.appendChild(resultItem);
            hasResults = true;
        }
    });

    document.getElementById('no-results').style.display = hasResults ? 'none' : 'block';
});

function displaySection(sectionId) {
    const sections = document.querySelectorAll('#manual-content section');
    sections.forEach(section => {
        section.style.display = 'none'; // Hide all sections
    });

    // Show the clicked section
    const selectedSection = document.getElementById(sectionId);
    selectedSection.style.display = 'block';
    selectedSection.scrollIntoView({ behavior: 'smooth' });
}

// Initially hide all sections except the first one (Introduction)
document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('#manual-content section');
    sections.forEach((section, index) => {
        if (index !== 0) {
            section.style.display = 'block'; // Hide all sections except introduction
        }
    });
});
</script>

<!-- JavaScript Function to Handle All Sliders -->
<script>
    // Object to track current slides for each slider
    const sliderState = {};

    // Function to change slides
    function changeSlide(direction, sliderId) {
        // Initialize currentSlide for each slider if not set
        if (!sliderState[sliderId]) {
            sliderState[sliderId] = 0;
        }
        
        const slides = document.getElementById(sliderId);
        const totalSlides = slides.children.length;

        // Update current slide index based on direction
        sliderState[sliderId] = (sliderState[sliderId] + direction + totalSlides) % totalSlides;

        // Apply transform to move slides
        slides.style.transform = `translateX(-${sliderState[sliderId] * 100}%)`;
    }
</script>