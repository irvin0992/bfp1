<?php
include '../connection.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $mname = mysqli_real_escape_string($conn, $_POST['mname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);

    // Check if username already exists
    $checkQuery = "SELECT * FROM tbl_users WHERE username = '$username' AND id != $id";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        echo 'exists';
    } else {
        $query = "UPDATE tbl_users SET username = '$username', fname = '$fname', mname = '$mname', lname = '$lname' WHERE id = $id";
        
        if (mysqli_query($conn, $query)) {
            echo 'success';
        } else {
            // Output the MySQL error for debugging
            echo 'error: ' . mysqli_error($conn);
        }
    }
}
?>
