<?php
include '../connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form data
    $buildingName = mysqli_real_escape_string($conn, $_POST['buildingName']);
    $buildingHeight = floatval($_POST['buildingHeight']);
    $squareMeters = floatval($_POST['squareMeters']);
    $numberOfFloors = intval($_POST['numberOfFloors']);
    $businessAddress = mysqli_real_escape_string($conn, $_POST['Districts']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay2']);
    $businessName = mysqli_real_escape_string($conn, $_POST['business_name']);
    $occupancy = mysqli_real_escape_string($conn, $_POST['Occupancy']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $contactNumber = mysqli_real_escape_string($conn, $_POST['contactNumber']);
    $businessNature = mysqli_real_escape_string($conn, $_POST['businessNature']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $FsicExpiry = mysqli_real_escape_string($conn, $_POST['FSIC_expiry']);
    
    // Handle file upload
    $targetDir = "../Requirements/";
    $fileName = basename($_FILES["requirementsFile"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    // Allow certain file formats (adjust as needed)
    $allowedTypes = array('jpg', 'png', 'jpeg', 'pdf', 'doc', 'docx');
    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["requirementsFile"]["tmp_name"], $targetFilePath)) {
            // File uploaded successfully
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'File upload failed.'
            ]);
            exit;
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid file type. Only JPG, PNG, PDF, DOC, and DOCX are allowed.'
        ]);
        exit;
    }

    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        // Insert into tbl_buildings
        $sqlBuilding = "INSERT INTO tbl_buildings (building_name, building_height, total_area, number_of_floors)
                        VALUES ('$buildingName', $buildingHeight, $squareMeters, $numberOfFloors)";
        $resultBuilding = mysqli_query($conn, $sqlBuilding);
        if (!$resultBuilding) throw new Exception(mysqli_error($conn));

        $lastInsertedBuildingId = mysqli_insert_id($conn);

        // Insert into tbl_businesses
        $sqlBusiness = "INSERT INTO tbl_businesses (business_name, district, barangay, business_nature, occupancy_type)
                        VALUES ('$businessName', '$businessAddress', '$barangay', '$businessNature', '$occupancy')";
        $resultBusiness = mysqli_query($conn, $sqlBusiness);
        if (!$resultBusiness) throw new Exception(mysqli_error($conn));

        $lastInsertedBusinessId = mysqli_insert_id($conn);

        // Insert into tbl_owners
        $sqlOwner = "INSERT INTO tbl_owners (owner_name, contact_number)
                     VALUES ('$owner', '$contactNumber')";
        $resultOwner = mysqli_query($conn, $sqlOwner);
        if (!$resultOwner) throw new Exception(mysqli_error($conn));

        $lastInsertedOwnerId = mysqli_insert_id($conn);

        // Insert into tbl_applications
        $sqlRegistration = "INSERT INTO tbl_applications (business_id, owner_id, building_id, email, FSIC_expiry, requirements_file)
                            VALUES ($lastInsertedBusinessId, $lastInsertedOwnerId, $lastInsertedBuildingId, '$email', '$FsicExpiry', '$targetFilePath')";
        $resultRegistration = mysqli_query($conn, $sqlRegistration);
        if (!$resultRegistration) throw new Exception(mysqli_error($conn));

        $lastInsertedApplicationId = mysqli_insert_id($conn);

        // Insert into tbl_inspections
        $sqlInspection = "INSERT INTO tbl_inspections (application_id) VALUES ($lastInsertedApplicationId)";
        $resultInspection = mysqli_query($conn, $sqlInspection);
        if (!$resultInspection) throw new Exception(mysqli_error($conn));
        // Commit transaction
        mysqli_commit($conn);

        // Registration successfully inserted
        $response = [
            'status' => 'success'
        ];
        echo json_encode($response);
    } catch (Exception $e) {
        // Rollback transaction on error
        mysqli_rollback($conn);

        $response = [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
        echo json_encode($response);
    }
}
?>
