<?php

include '../connection.php'; // Include connection with a semicolon

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id']) && $_POST['confirm'] === 'yes') {
    $application_id = intval($_POST['application_id']);

    // Get ny_date from tbl_cert
    $ny_date_query = "SELECT ny_date FROM tbl_cert WHERE application_id = ?";
    $stmt = $conn->prepare($ny_date_query);
    $stmt->bind_param("i", $application_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $cert_row = $result->fetch_assoc();
        $ny_date = $cert_row['ny_date'];

        // Update FSIC_expiry, status, inspector fields in tbl_application
        $update_application_query = "UPDATE tbl_applications
                             SET FSIC_expiry = ?, notification = 0
                             WHERE application_id = ?";
        $stmt = $conn->prepare($update_application_query);
        $stmt->bind_param("si", $ny_date, $application_id);
        if ($stmt->execute()) {
            
            // Now update the `tbl_inspections` to clear inspector details and set the status to 'pending'
            $update_inspections_query = "UPDATE tbl_inspections
                                         SET status = 'pending',
                                             inspector_fname = '', inspector_mname = '', inspector_lname = '',
                                             inspection_date = NULL
                                         WHERE application_id = ?";
            $stmt = $conn->prepare($update_inspections_query);
            $stmt->bind_param("i", $application_id);

            if ($stmt->execute()) {
                echo "Application and Inspection updated successfully.";
                // Redirect to a success page, e.g.:
                // header('Location: success_page.php');
            } else {
                echo "Error updating inspection: " . $conn->error;
            }
        } else {
            echo "Error updating application: " . $conn->error;
        }
    } else {
        echo "No certificate found for this application.";
    }

    $stmt->close();
}
?>