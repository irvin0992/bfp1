function saveDetails() {
        // Get form values
        const registrationId = $('#registrationId').val();
        const buildingName = $('#modalBuilding').val();
        const buildingHeight = $('#modalBuildingHeight').val();
        const totalArea = $('#modalTotalArea').val();
        const numberOfFloors = $('#modalNumberOfFloors').val();
        const businessName = $('#modalBusiness').val();
        const businessAddress = $('#modalAddress').val();
        const barangay = $('#barangay').val(); // Add as needed
        const ownerName = $('#modalOwner').val();
        const occupancyType = $('#modalOccupancy').val();
        const contactNumber = $('#modalContact').val();

        // Confirm action with SweetAlert
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to update this application?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, update it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Perform AJAX request to update data
                $.ajax({
                    url: 'update_application.php', // The PHP script path
                    type: 'POST',
                    data: {
                        registration_id: registrationId,
                        building_name: buildingName,
                        building_height: buildingHeight,
                        total_area: totalArea,
                        number_of_floors: numberOfFloors,
                        business_name: businessName,
                        address: businessAddress,
                        barangay: barangay,
                        owner_name: ownerName,
                        occupancy_type: occupancyType,
                        contact_number: contactNumber
                    },
                    success: function(response) {
                        const res = JSON.parse(response);
                        if (res.success) {
                            Swal.fire(
                                'Updated!',
                                res.message,
                                'success'
                            ).then(() => {
                                // Optional: reload the page or refresh table data
                                location.reload();
                            });
                        } else {
                            Swal.fire(
                                'Error!',
                                res.message,
                                'error'
                            );
                        }
                    },
                    error: function() {
                        Swal.fire(
                            'Error!',
                            'An error occurred while updating the application.',
                            'error'
                        );
                    }
                });
            }
        });
    }
