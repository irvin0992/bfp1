<?php
// Include your database connection
include('../connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['registration_id']) && isset($_POST['action'])) {
    $registrationId = $_POST['registration_id'];
    $action = $_POST['action'];

    // Check if the registration exists and the status is 'pending'
    $checkQuery = "SELECT status FROM tbl_registrations WHERE registration_id = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("i", $registrationId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Validate if the current status is 'pending'
        if ($row['status'] === 'pending') {
            if ($action === 'approve') {
                // Approve action: Update the status to 'verified' and insert into tbl_inspections
                $updateQuery = "UPDATE tbl_registrations SET status = 'verified' WHERE registration_id = ?";
                $stmt = $conn->prepare($updateQuery);
                $stmt->bind_param("i", $registrationId);

                if ($stmt->execute()) {
                    // Insert into tbl_inspections with status 'Ready for Inspection'
                    $insertQuery = "INSERT INTO tbl_inspections (registration_id, status) VALUES (?, 'Ready for Inspection')";
                    $stmt = $conn->prepare($insertQuery);
                    $stmt->bind_param("i", $registrationId);

                    if ($stmt->execute()) {
                        echo json_encode(['success' => true]);
                    } else {
                        echo json_encode(['success' => false, 'error' => 'Error inserting into inspections table']);
                    }
                } else {
                    echo json_encode(['success' => false, 'error' => 'Error updating registrations table']);
                }
            } elseif ($action === 'decline') {
                // Decline action: Update the status to 'denied'
                $updateQuery = "UPDATE tbl_registrations SET status = 'denied' WHERE registration_id = ?";
                $stmt = $conn->prepare($updateQuery);
                $stmt->bind_param("i", $registrationId);

                if ($stmt->execute()) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Error updating registrations table']);
                }
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid action specified']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Inspection is not in a pending state']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid registration ID']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
