<?php include('../session_validate.php'); ?>
<?php include('../header/header.php'); ?>
<!-- ============================================================== -->
<!-- end navbar -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- left sidebar -->
<!-- ============================================================== -->
<?php include('../sidebar/sidebar.php'); ?>
<!-- ============================================================== -->
<!-- end left sidebar -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- wrapper  -->
<!-- ============================================================== -->
<?php include '../connection.php' ?>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>

                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="admindashboard.php"
                                            class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Utilities</li>
                                    <li class="breadcrumb-item active" aria-current="page">Activity Log</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
        <style>
            .modal-header {
                background-color: #dc3545;
                border-bottom: none;
            }

            .modal-body {
                font-size: 1.1rem;
            }

            .modal-footer {
                border-top: none;
                justify-content: center;
            }

            .btn-outline-success,
            .btn-outline-info {
                width: 48%;
                padding: 15px;
                font-size: 1rem;
            }

            .btn-outline-success:hover,
            .btn-outline-info:hover {
                background-color: #28a745;
                color: #fff;
            }

            .btn-outline-info:hover {
                background-color: #17a2b8;
                color: #fff;
            }
        </style>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header"><i class='bx bx-dots-vertical-rounded'></i> Activity Log</h5>
                    <div class="card-body">
                        <div id="message"></div>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-striped table-bordered first">
                                <thead style="position: sticky; top: 0; background-color: #fff; z-index: 1;">
                                    <tr>
                                        <th scope="col">Date and Time</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Userlevel</th>
                                        <th scope="col">Description</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $view = mysqli_query($conn, "SELECT * from tbl_users INNER JOIN tbl_activity_log ON tbl_users.id = tbl_activity_log.id");
                                    while ($data = mysqli_fetch_assoc($view)) {
                                        // Correct the variable assignments
                                        $fname = $data['fname'];
                                        $mname = $data['mname'];
                                        $lname = $data['lname'];
                                        $ulvl = $data['userlevel'];
                                        $activity_type = $data['activity_type'];
                                        $activity_time = $data['activity_time'];
                                        $activity_desc = $data['activity_desc'];
                                        ?>
                                        <tr>

                                            <td><?php echo $activity_time; ?></td>
                                            <td><?php echo $fname . " " . $mname . " " . $lname ?></td>
                                            <td><?php echo $activity_type; ?></td>
                                            <td><?php echo $activity_desc; ?></td>
                                            <td class="align-right">
                                                <a href="javascript:void(0);" onclick="editUser(<?php echo $data['id']; ?>)"
                                                    class="text-secondary font-weight-bold text-xs" data-toggle="tooltip"
                                                    data-original-title="Edit user">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- end responsive table -->
        <!-- ============================================================== -->
    </div>

    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
    <script src="../assets/libs/js/main-js.js"></script>
    <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/vendor/datatables/js/data-table.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        function confirmAction(userId, status) {
            let action = status == 1 ? 'activate' : 'deactivate';
            Swal.fire({
                title: 'Are you sure?',
                text: `You are about to ${action} this user.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Make an AJAX call to update the status
                    $.ajax({
                        url: 'update-user-status.php',
                        type: 'POST',
                        data: { id: userId, status: status },
                        success: function (response) {
                            if (response == 'success') {
                                Swal.fire(
                                    'Updated!',
                                    'User status has been updated.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire(
                                    'Error!',
                                    'There was an error updating the status.',
                                    'error'
                                );
                            }
                        }
                    });
                }
            });
        }

        $(document).ready(function () {
            $('#addUserForm').submit(function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you want to add this data?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, add it!',
                    cancelButtonText: 'No, cancel!',
                    customClass: {
                        confirmButton: 'swal2-confirm-custom',
                        cancelButton: 'swal2-cancel-custom'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: $(this).attr('action'),
                            type: 'POST',
                            data: $(this).serialize(),
                            success: function (response) {
                                if (response == 'success') {
                                    Swal.fire(
                                        'Added!',
                                        'New user has been added.',
                                        'success'
                                    ).then(() => {
                                        location.reload();
                                    });
                                } else if (response == 'exists') {
                                    Swal.fire(
                                        'Error!',
                                        'Username already exists.',
                                        'error'
                                    );
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        'There was an error adding the user.',
                                        'error'
                                    );
                                }
                            }
                        });
                    }
                });
            });
        });
    </script>

    <script>
        function editUser(userId) {
            // Make an AJAX call to fetch the user data
            $.ajax({
                url: 'get-user-data.php',
                type: 'POST',
                data: { id: userId },
                success: function (response) {
                    let user = JSON.parse(response);
                    $('#editUserId').val(user.id);
                    $('#editUsername').val(user.username);
                    $('#editFname').val(user.fname);
                    $('#editMname').val(user.mname);
                    $('#editLname').val(user.lname);
                    $('#editUserlevel').val(user.userlevel);
                    $('#editStatus').val(user.status);
                    $('#editUserModal').modal('show');
                }
            });
        }

        $(document).ready(function () {
            $('#editUserForm').submit(function (e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You are about to update this user.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: $(this).attr('action'),
                            type: 'POST',
                            data: $(this).serialize(),
                            success: function (response) {
                                if (response == 'success') {
                                    Swal.fire(
                                        'Updated!',
                                        'User details have been updated.',
                                        'success'
                                    ).then(() => {
                                        location.reload();
                                    });
                                } else if (response == 'exists') {
                                    Swal.fire(
                                        'Error!',
                                        'Username already exists.',
                                        'error'
                                    );
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        'There was an error updating the user.',
                                        'error'
                                    );
                                }
                            }
                        });
                    }
                });
            });
        });
    </script>