$(document).ready(function() {
    $("#verificationForm").on("submit", function(e) {
        e.preventDefault(); // Prevent the default form submission

        // Show SweetAlert confirmation with a question mark icon
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'question', // Set the icon to a question mark
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, submit it!'
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user confirms, proceed with the AJAX request
                var status = $("#statusSelect").val();
                var remarks = $("#remarks").val();
                var registrationId = $("#modalRegistrationId").val();
                
                // Determine inspection status based on the selected verification status
                var inspectionStatus = status === "verified" ? "Passed" : "Denied";

                $.ajax({
                    url: "updateApplication.php", // Server-side script to handle the database update
                    type: "POST",
                    data: {
                        registration_id: registrationId,
                        statusSelect: status,
                        remarks: remarks,
                        inspection_status: inspectionStatus
                    },
                    success: function(response) {
                        if(response === "success") {
                            Swal.fire(
                                'Submitted!',
                                'The status has been updated.',
                                'success'
                            ).then(() => {
                                $("#verifyModal").modal("hide");
                                // Optionally refresh the page or update the UI
                            });
                        } else {
                            Swal.fire(
                                'Error!',
                                'There was a problem updating the status. Please try again.',
                                'error'
                            );
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle any errors that occur during the AJAX request
                        console.error("AJAX Error: " + status + error);
                        Swal.fire(
                            'Error!',
                            'Failed to update status.',
                            'error'
                        );
                    }
                });
            }
        });
    });
});