$(document).on('click', '.view-details-btn', function () {
        var inspectionId = $(this).data('inspection-id');

        // Clear previous failure reasons
        $('#failureReasonsList').empty();

        // Perform AJAX request to fetch failure reasons
        $.ajax({
            url: 'failed.php', // Adjust path as needed
            method: 'POST',
            data: { inspection_id: inspectionId },
            success: function (response) {
                // Parse response and append to the modal
                $('#failureReasonsList').html(response);
            },
            error: function () {
                $('#failureReasonsList').html('<li>Failed to retrieve data.</li>');
            }
        });
    });

