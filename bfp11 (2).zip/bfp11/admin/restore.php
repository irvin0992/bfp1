<?php
include('../session_validate.php');
include('../header/header.php');
include('../sidebar/sidebar.php');
include '../connection.php';
// Set your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "bfp_db";

// Create database connection

if (isset($_POST['restore'])) {
    $file = $_FILES['sql_file']['tmp_name'];

    // Check if file is uploaded and is a SQL file
    if ($file && pathinfo($_FILES['sql_file']['name'], PATHINFO_EXTENSION) == 'sql') {
        $sql_content = file_get_contents($file);

        // Create a new connection
        $conn = mysqli_connect($servername, $username, $password, $database);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Split SQL statements by semicolons to handle multiple statements
        $queries = explode(';', $sql_content);

        $success = true;
        $log_file = 'restore_log.txt';  // Optional: Log the restoration process

        // Execute each query one by one
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!$conn->query($query)) {
                    file_put_contents($log_file, "Error executing query: " . $conn->error . "\n", FILE_APPEND);
                    $success = false;
                } else {
                    file_put_contents($log_file, "Query executed successfully.\n", FILE_APPEND);
                }
            }
        }

        $conn->close();

        // Provide feedback to the user
        if ($success) {
            echo "<script>alert('Database restored successfully!');</script>";
        } else {
            echo "<script>alert('There were errors restoring the database. Check restore_log.txt for details.');</script>";
        }

    } else {
        echo "<script>alert('Please upload a valid SQL file.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restore Database</title>
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstrap bundle js-->
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js-->
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- chartjs js-->
    <script src="../assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
    <script src="../assets/vendor/charts/charts-bundle/chartjs.js"></script>
    <!-- main js-->
    <script src="../assets/libs/js/main-js.js"></script>
    <!-- dashboard sales js-->
    <script src="../assets/libs/js/dashboard-sales.js"></script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
        }

        .content {
            margin: 0 auto;
            max-width: 900px;
            padding: 20px;
        }

        .restore-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border: 2px solid #b90000;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .restore-container h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        label {
            font-weight: 500;
            margin-bottom: 5px;
            display: inline-block;
            color: #555;
        }

        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #565b61;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        button:hover {
            background-color: #4a5056;
        }
    </style>
</head>

<body>
<div class="dashboard-wrapper">
    <div class="container-fluid  dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>

                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="admindashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Utilities</li>
                                    <li class="breadcrumb-item active" aria-current="page">Restore</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->

  <!-- Main Content -->
  <div class="content">
        <div class="restore-container">
            <h2>Restore Database</h2>

            <!-- Form for selecting and uploading the SQL file -->
            <form action="restore_db.php" method="POST" enctype="multipart/form-data">
                <label for="sql_file">Select SQL File:</label>
                <input type="file" name="sql_file" accept=".sql" required>
                <br>
                <button type="submit" name="restore">Restore Database</button>
            </form>
        </div>
    </div>
</body>

</html>
