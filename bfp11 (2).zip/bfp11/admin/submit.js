$(document).ready(function () {
    $('#editForm').on('submit', function (event) {
        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to submit the inspection?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                // Submit the form via AJAX
                $.ajax({
                    url: $(this).attr('action'),
                    type: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function (response) {
                        if (response.trim() === 'success') {
                            Swal.fire({
                                title: 'Success',
                                text: 'Inspection details updated successfully.',
                                icon: 'success'
                            }).then(() => {
                                location.reload(); // Reload the page
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Failed to update inspection details.',
                                icon: 'error'
                            });
                        }
                    },
                    error: function () {
                        Swal.fire({
                            title: 'Error',
                            text: 'Failed to update inspection details. Please try again later.',
                            icon: 'error'
                        });
                    }
                });
            }
        });
    });
});