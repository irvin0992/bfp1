$(document).ready(function () {
    const barangays = {
        "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
        "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
        "District III": ["Catbangen", "Parian", "Madayegdeg"],
        "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
        "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
        "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
        "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
        "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
        "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
        "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
        "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
        "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
    };

    $('#Districts').change(function () {
        const district = $(this).val();
        const barangaySelect = $('#barangay2');

        barangaySelect.empty();
        barangaySelect.append('<option value="">Select Barangay</option>');

        if (district in barangays) {
            barangays[district].forEach(barangay2 => {
                barangaySelect.append(new Option(barangay2, barangay2));
            });
        }
    });

    $('#registrationForm').on('submit', function (e) {
        e.preventDefault();
        Swal.fire({
            title: 'Confirm Submission',
            text: "Are you sure you want to submit?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'businessinfo.php',
                    type: 'POST',
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: 'Success',
                                text: 'Business Information added successfully.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            // Handle the case where the response indicates failure
                            Swal.fire({
                                title: 'Error',
                                text: response.message || 'There was an error adding your application.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    
                    error: function (xhr, status, error) {
                        Swal.fire({
                            title: 'Error',
                            text: 'There was an error adding your application.',
                            html: `<pre>${xhr.responseText}</pre>`,  // Display detailed error message
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            }
        });
    });
});
