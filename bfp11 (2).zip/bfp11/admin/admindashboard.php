<?php
include('../session_validate.php');
include('../header/header.php');
include('../sidebar/sidebar.php');
include '../connection.php';

// Fetch the number of employees
$users_query = "SELECT COUNT(*) as count FROM tbl_users";
$users_result = mysqli_query($conn, $users_query);
$users_count = mysqli_fetch_assoc($users_result)['count'];

// Fetch the number of permits
$permits_query = "SELECT COUNT(*) as count FROM tbl_inspections WHERE status = 'Approved' ";
$permits_result = mysqli_query($conn, $permits_query);
$permits_count = mysqli_fetch_assoc($permits_result)['count'];

// Fetch the number of registrations
$registrations_query = "SELECT COUNT(*) as count FROM tbl_applications";
$registrations_result = mysqli_query($conn, $registrations_query);
$registrations_count = mysqli_fetch_assoc($registrations_result)['count'];

// Fetch the number of inspections
$inspections_query = "SELECT COUNT(*) as count FROM tbl_inspections WHERE status = 'Pending'";
$inspections_result = mysqli_query($conn, $inspections_query);
$inspections_count = mysqli_fetch_assoc($inspections_result)['count'];
?>

<!-- HTML and Bootstrap code -->
<div class="dashboard-wrapper">
    <div class="container-fluid dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader  -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>
                    <h2 class="pageheader-title mt-2"><i class="fa fa-fw fa-tachometer-alt"></i> Dashboard</h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Home</li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
        </div>

        <!-- ============================================================== -->
        <!-- Metrics Row  -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- Metric: Number of Employees -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                            <h5 class="text-muted">
                        <a href="displayusers.php" style="text-decoration: none; color: inherit;">
                            Employees
                        </a>
                    </h5>
                                <h2 class="mb-0"><?php echo $users_count; ?></h2>
                            </div>
                            <div class="icon-circle bg-info-light">
                                <i class="fa fa-users fa-fw text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metric: Number of Permits -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                            <h5 class="text-muted">
                            <a href="displayFSIC.php" style="text-decoration: none; color: inherit;">
                                Fire Safety Permits
                            </a>
                        </h5>
                                <h2 class="mb-0"><?php echo $permits_count; ?></h2>
                            </div>
                            <div class="icon-circle bg-warning-light">
                                <i class="fa fas fa-file-alt fa-fw text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metric: Number of Applications -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                            <h5 class="text-muted">
                            <a href="displayapplication.php" style="text-decoration: none; color: inherit;">
                                Applications
                            </a>
                        </h5>
                                <h2 class="mb-0"><?php echo $registrations_count; ?></h2>
                            </div>
                            <div class="icon-circle bg-success-light">
                                <i class="fa fas fa-folder-open fa-fw text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metric: Number of Inspections -->
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                            <h5 class="text-muted">
                            <a href="pending.php" style="text-decoration: none; color: inherit;">
                                Pending Inspections
                            </a>
                        </h5>
                                <h2 class="mb-0"><?php echo $inspections_count; ?></h2>
                            </div>
                            <div class="icon-circle bg-danger-light">
                                <i class="fa fas fa-archive fa-fw text-danger"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Metrics Row  -->
        <!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- Chart Section  -->
        <!-- ============================================================== -->
        <div class="row mt-4">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-muted text-center">Dashboard Statistics</h5>
                        <div class="d-flex justify-content-center">
                            <canvas id="inspectionChart" style="width:100%; height:400px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Chart Section  -->
        <!-- ============================================================== -->
    </div>
</div>

<!-- Optional JavaScript -->
<!-- jquery 3.3.1 js-->
<script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<!-- bootstrap bundle js-->
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<!-- slimscroll js-->
<script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<!-- chartjs js-->
<script src="../assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
<script src="../assets/vendor/charts/charts-bundle/chartjs.js"></script>
<!-- main js-->
<script src="../assets/libs/js/main-js.js"></script>

<script>
    // Chart.js script for displaying the inspections statistics
    var ctx = document.getElementById('inspectionChart').getContext('2d');
    var inspectionChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Employees', 'Permits', 'Applications', 'Inspections'],
            datasets: [{
                label: 'Count',
                data: [<?php echo $users_count; ?>, <?php echo $permits_count; ?>, <?php echo $registrations_count; ?>, <?php echo $inspections_count; ?>],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 99, 132, 0.6)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: true,
            maintainAspectRatio: false, // Allow dynamic resizing
            plugins: {
                legend: {
                    display: true,
                    position: 'top' // Optional: Move the legend inside the chart
                }
            },
            layout: {
                padding: {
                    left: 10, // Add some padding around the chart
                    right: 10,
                    top: 10,
                    bottom: 10
                }
            }
        }
    });
</script>

</body>

</html>