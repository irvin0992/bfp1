<?php
// Assuming you have database connection already established
include('../connection.php');

// Function to handle status update
function updateStatus($conn, $registration_id, $new_status)
{
    $update_query = "UPDATE tbl_applications SET status = '$new_status' WHERE application_id = $registration_id";
    if ($conn->query($update_query) === TRUE) {
        return true;
    } else {
        throw new Exception("Error updating status: " . $conn->error);
    }
}

// Query to fetch data
$permits_result = $conn->query("
    SELECT a.*, b.building_name, b.building_height, b.total_area, b.number_of_floors, 
           bu.business_name, bu.district, bu.barangay, o.owner_name, bu.occupancy_type, 
           o.contact_number, a.requirements_file, bu.business_nature
    FROM tbl_applications a
    INNER JOIN tbl_buildings b ON a.building_id = b.building_id
    INNER JOIN tbl_businesses bu ON a.business_id = bu.business_id
    INNER JOIN tbl_owners o ON a.owner_id = o.owner_id
    INNER JOIN tbl_inspections i ON a.application_id = i.application_id
    WHERE i.status = 'Approved'
");
if (!$permits_result) {
    throw new Exception("Query execution failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fire Safety Applications</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <?php include('../session_validate.php'); ?>
    <?php include('../header/header.php'); ?>
    <?php include('../sidebar/sidebar.php'); ?>


    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h5 class="mb-0 text-dark nav-user-name">
                            <i class="fa fa-user"></i>
                            <?php
                            if (isset($_SESSION['user_id'])) {
                                $user_id = intval($_SESSION['user_id']);

                                // Query to get the user details from tbl_users
                                $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $result = $stmt->get_result();

                                if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc();
                                    $fname = htmlspecialchars($row['fname']);
                                    $mname = htmlspecialchars($row['mname']);
                                    $lname = htmlspecialchars($row['lname']);
                                    echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                                } else {
                                    echo 'Welcome, User';
                                }

                                $stmt->close();
                            }
                            ?>
                        </h5>

                        <h2 class="pageheader-title" style="margin-top:10px;"><i class="fa fa-fw fa-file-word"></i> Fire
                            Safety Applications</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Fire Safety Permit</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <h5 class="card-header">Fire Safety Applications</h5>
                        <div class="card-body">
                            <div id="message"></div>
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-striped table-bordered first" id="dataTable" width="100%"
                                    cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name of Building</th>
                                            <th>Business Name</th>
                                            <th>Business Address</th>
                                            <th>Name of Owner</th>
                                            <th>Occupancy</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($permits_result->num_rows > 0) {
                                            while ($row = $permits_result->fetch_assoc()) {
                                                ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['building_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['business_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($row['owner_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['occupancy_type']); ?></td>
                                                    <td>
                                                        <!-- View Button to Trigger Modal -->
                                                        <button type="button" class="btn btn-primary"
                                                            style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#confirmPrintModal<?php echo $row['application_id']; ?>">
                                                            Edit
                                                        </button>

                                                        <!-- View Button to Trigger Modal -->
                                                        <button type="button" class="btn btn-secondary"
                                                            style="border-radius: 20px;" data-bs-toggle="modal"
                                                            data-bs-target="#viewBusinessModal<?php echo $row['application_id']; ?>">View</button>
                                                    </td>
                                                </tr>


                                                <!-- Modal for Certificate Printed Confirmation -->
                                                <div class="modal fade"
                                                    id="confirmPrintModal<?php echo $row['application_id']; ?>" tabindex="-1"
                                                    aria-labelledby="confirmPrintLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="confirmPrintLabel">Certificate
                                                                    Printed Confirmation</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                    aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Has the certificate already been printed?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <!-- Yes Button triggers form submission using Ajax -->
                                                                <form id="confirmForm<?php echo $row['application_id']; ?>"
                                                                    method="post">
                                                                    <input type="hidden" name="application_id"
                                                                        value="<?php echo $row['application_id']; ?>">
                                                                    <button type="button" class="btn btn-primary"
                                                                        onclick="confirmUpdate(<?php echo $row['application_id']; ?>)">Yes</button>
                                                                </form>

                                                                <!-- No Button just closes the modal -->
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">No</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Modal Structure (Move this inside the loop) -->
                                                <div class="modal fade"
                                                    id="viewBusinessModal<?php echo $row['application_id']; ?>" tabindex="-1"
                                                    aria-labelledby="viewBusinessLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="viewBusinessLabel">Business
                                                                    Information</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                    aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <!-- Fetch business info based on application_id -->
                                                                <?php
                                                                $application_id = $row['application_id'];
                                                                $query = " SELECT a.*, b.building_name, b.building_height, b.total_area, b.number_of_floors, 
                                                                bu.business_name, bu.district, bu.barangay, o.owner_name, bu.occupancy_type, 
                                                                o.contact_number, a.requirements_file, bu.business_nature, i.status
                                                                FROM tbl_applications a
                                                                INNER JOIN tbl_buildings b ON a.building_id = b.building_id
                                                                INNER JOIN tbl_businesses bu ON a.business_id = bu.business_id
                                                                INNER JOIN tbl_owners o ON a.owner_id = o.owner_id
                                                                INNER JOIN tbl_inspections i ON a.application_id = i.application_id"; // Adjust your query based on your table schema
                                                                $result = mysqli_query($conn, $query);
                                                                if ($result) {
                                                                    $business = mysqli_fetch_assoc($result);
                                                                    ?>
                                                                    <p><strong>Business Name:</strong>
                                                                        <?php echo htmlspecialchars($business['business_name']); ?>
                                                                    </p>
                                                                    <p><strong>Owner:</strong>
                                                                        <?php echo htmlspecialchars($business['owner_name']); ?></p>
                                                                    <p><strong>Address:</strong>
                                                                        <?php echo htmlspecialchars($business['district']); ?></p>
                                                                    <p><strong>Contact:</strong>
                                                                        <?php echo htmlspecialchars($business['contact_number']); ?>
                                                                    </p>
                                                                    <p><strong>Status:</strong>
                                                                        <?php echo htmlspecialchars($business['status']); ?></p>
                                                                    <?php
                                                                } else {
                                                                    echo "<p>Business information not available.</p>";
                                                                }
                                                                ?>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <!-- Close Button -->
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Close</button>

                                                                <!-- Print Button Inside Modal -->
                                                                <form action="../ReportGen/RepGen_Cert.php" method="post"
                                                                    target="_blank" style="display: inline-block;">
                                                                    <input type="hidden" name="application_id"
                                                                        value="<?php echo $row['application_id']; ?>">
                                                                    <button type="submit" class="btn btn-primary"
                                                                        style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;">Print</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='6'>No records found</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
    <script src="../assets/libs/js/main-js.js"></script>
    <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/vendor/datatables/js/data-table.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
        function confirmUpdate(applicationId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "This will update the certificate status.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, update it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Ajax request to update the status
                    $.ajax({
                        url: 'update_application_status.php',
                        type: 'POST',
                        data: {
                            application_id: applicationId,
                            confirm: 'yes'
                        },
                        success: function (response) {
                            // Show success message
                            Swal.fire({
                                title: 'Updated!',
                                text: 'Certificate status has been updated.',
                                icon: 'success',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                // Reload the page after confirmation
                                location.reload();
                            });
                        },
                        error: function (xhr, status, error) {
                            // Show error message
                            Swal.fire({
                                title: 'Error!',
                                text: 'Something went wrong, please try again.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    });
                }
            });
        }
    </script>
</body>

</html>

<?php
// Close the database connection
$conn->close();
?>