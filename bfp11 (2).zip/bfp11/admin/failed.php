<?php
// Include database connection
include('../connection.php');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get inspection_id from AJAX request
$inspection_id = $_POST['inspection_id'] ?? '';

// Ensure inspection_id is not empty or invalid
if (empty($inspection_id)) {
    echo "<li>Inspection ID is required.</li>";
    exit;
}

// Function to collect failure reasons
function collectFailureReasons($conn, $inspection_id) {
    $failureReasons = [];

    // Check tbl_means_of_egress
    $sql_egress = "SELECT doors_status, corridor_status, exitsdoors_status, stairs_status, horizontalexit_status, MLH_status, EED_status, ESPI_status FROM tbl_means_of_egress WHERE inspection_id = ?";
    if ($stmt_egress = $conn->prepare($sql_egress)) {
        $stmt_egress->bind_param("i", $inspection_id);
        $stmt_egress->execute();
        $result_egress = $stmt_egress->get_result();
        if ($row_egress = $result_egress->fetch_assoc()) {
            foreach ($row_egress as $key => $status) {
                if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                    $failureReasons[] = ucfirst(str_replace('_', ' ', $key));
                }
            }
        }
        $stmt_egress->close();
    }

    // Check tbl_fire_protection
    $sql_protection = "SELECT fire_extinguisher_size, minimum_number_extinguisher, seals_tags, markings, pressure FROM tbl_fire_protection WHERE inspection_id = ?";
    if ($stmt_protection = $conn->prepare($sql_protection)) {
        $stmt_protection->bind_param("i", $inspection_id);
        $stmt_protection->execute();
        $result_protection = $stmt_protection->get_result();
        if ($row_protection = $result_protection->fetch_assoc()) {
            foreach ($row_protection as $key => $status) {
                if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                    $failureReasons[] = ucfirst(str_replace('_', ' ', $key));
                }
            }
        }
        $stmt_protection->close();
    }

    // Check tbl_hazards
    $sql_hazards = "SELECT location, CC_status, GDD_status FROM tbl_hazards WHERE inspection_id = ?";
    if ($stmt_hazards = $conn->prepare($sql_hazards)) {
        $stmt_hazards->bind_param("i", $inspection_id);
        $stmt_hazards->execute();
        $result_hazards = $stmt_hazards->get_result();
        if ($row_hazards = $result_hazards->fetch_assoc()) {
            foreach ($row_hazards as $key => $status) {
                if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                    $failureReasons[] = ucfirst(str_replace('_', ' ', $key));
                }
            }
        }
        $stmt_hazards->close();
    }

    return $failureReasons;
}

// Collect failure reasons and output as HTML list items
$failureReasons = collectFailureReasons($conn, $inspection_id);
if (!empty($failureReasons)) {
    foreach ($failureReasons as $reason) {
        echo "<li>$reason</li>";
    }
} else {
    echo "<li>No failure reasons found.</li>";
}

// Close connection
$conn->close();
?>
