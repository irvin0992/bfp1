<?php
include '../connection.php';  // Include your database connection file

if (isset($_POST['business_name'])) {
    $business_name = $_POST['business_name'];
    
    // Query to check if the business name exists
    $query = "SELECT * FROM tbl_businesses WHERE business_name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $business_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<span style='color: red;'>Business already exists</span>";
    } else {
        echo "<span style='color: green;'>Business name available</span>";
    }
}
?>
