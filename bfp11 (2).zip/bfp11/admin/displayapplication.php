<?php
// Assuming you have database connection already established
include('../connection.php');

try {
    // Query to fetch data (status and remarks removed)
    $permits_result = $conn->query("
    SELECT r.*, b.building_name, b.building_height, b.total_area, b.number_of_floors, 
           bu.business_name, bu.district, bu.barangay, o.owner_name, bu.occupancy_type, 
           o.contact_number, r.requirements_file, bu.business_nature
    FROM tbl_applications r
    INNER JOIN tbl_buildings b ON r.building_id = b.building_id
    INNER JOIN tbl_businesses bu ON r.business_id = bu.business_id
    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id 
    ORDER BY r.application_id ASC;
");

    if (!$permits_result) {
        throw new Exception("Query execution failed: " . $conn->error);
    }

    // Process the results if needed
} catch (Exception $e) {
    // Handle the error
    echo "Fatal error: " . $e->getMessage();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fire Safety Applications</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../style.css">
    <style>
        /* Add this to your CSS file or within a <style> tag */
        .btn-group .btn {
            margin-right: 5px;
        }

        .btn-group .btn:last-child {
            margin-right: 0;
        }
    </style>
    <style>
        .modal-header {
            background-color: #dc3545;
            border-bottom: none;
        }

        .modal-body {
            font-size: 1.1rem;
        }

        .modal-footer {
            border-top: none;
            justify-content: center;
        }

        .btn-outline-success,
        .btn-outline-info {
            width: 48%;
            padding: 15px;
            font-size: 1rem;
        }

        .btn-outline-success:hover,
        .btn-outline-info:hover {
            background-color: #28a745;
            color: #fff;
        }

        .btn-outline-info:hover {
            background-color: #17a2b8;
            color: #fff;
        }
    </style>
</head>

<body>
    <?php include('../session_validate.php'); ?>
    <?php include('../header/header.php'); ?>
    <?php include('../sidebar/sidebar.php'); ?>

    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h5 class="mb-0 text-dark nav-user-name">
                            <i class="fa fa-user"></i>
                            <?php
                            if (isset($_SESSION['user_id'])) {
                                // Assuming you have a connection to the database in $conn
                                $user_id = intval($_SESSION['user_id']);

                                // Query to get the user details from tbl_users
                                $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $user_id); // Bind the user_id
                                $stmt->execute();
                                $result = $stmt->get_result();

                                if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc();
                                    // Sanitize the output to prevent XSS attacks
                                    $fname = htmlspecialchars($row['fname']);
                                    $mname = htmlspecialchars($row['mname']);
                                    $lname = htmlspecialchars($row['lname']);
                                    echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                                } else {
                                    echo 'Welcome, User';
                                }

                                $stmt->close();
                            }
                            ?>
                        </h5>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Fire Safety Permit</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <h5 class="card-header"><i class="fa fa-fw fa-file-word"></i> Fire
                            Safety Applications</h5>
                        <div class="card-body">
                            <div id="message"></div>
                            <div class="table-responsive">
                                <button type="button" class="btn btn-sm"
                                    style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                    data-toggle="modal" data-target="#addBusInfoModal">
                                    <i class="fa fa-fw fa-user-plus"></i> Add Business Information
                                </button><br><br>
                                <div class="container">
                                    <div class="row mb-3">
                                        <div class="col-md-3">
                                            <label for="businessAddress" class="text-dark">Business District</label>
                                            <select class="form-control" id="businessAddress" name="businessAddress"
                                                required>
                                                <option value="">Select San Fernando City</option>
                                                <option value="District I">District I</option>
                                                <option value="District II">District II</option>
                                                <option value="District III">District III</option>
                                                <option value="District IV">District IV</option>
                                                <option value="District V">District V</option>
                                                <option value="District VI">District VI</option>
                                                <option value="District VII">District VII</option>
                                                <option value="District VIII">District VIII</option>
                                                <option value="District IX">District IX</option>
                                                <option value="District X">District X</option>
                                                <option value="District XI">District XI</option>
                                                <option value="District XII">District XII</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="barangay" class="text-dark">Barangay</label>
                                            <select class="form-control" id="barangay" name="barangay" required>
                                                <option value="">Select Barangay</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="filterBtn" style="visibility: hidden;">Filter</label>
                                            <button id="filterBtn"
                                                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                class="btn btn-primary form-control">Search</button>
                                        </div>
                                    </div>

                                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                        <table class="table table-striped  table-bordered first" id="dataTable"
                                            width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>Business Name</th>
                                                    <th>Name of Owner</th>
                                                    <th>Business Address</th>
                                                    <th>Contact Number</th>
                                                    <th>Fsic Expiration</th>
                                                    <th>Requirements</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($permits_result->num_rows > 0) {
                                                    while ($row = $permits_result->fetch_assoc()) {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($row['business_name']); ?></td>
                                                            <td><?php echo htmlspecialchars($row['owner_name']); ?></td>
                                                            <td><?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>
                                                            </td>
                                                            <td><?php echo htmlspecialchars($row['contact_number']); ?></td>
                                                            <td><?php echo htmlspecialchars($row['FSIC_expiry']); ?></td>
                                                            <td>
                                                                <?php
                                                                if (!empty($row['requirements_file'])) {
                                                                    // Explode DTI photos string into an array
                                                                    $photos = explode(', ', $row['requirements_file']);
                                                                    foreach ($photos as $photo) {
                                                                        // Display each photo as a clickable link
                                                                        echo "<a href='../Requirements/$photo' target='_blank'>View Photo</a><br>";
                                                                    }
                                                                } else {
                                                                    echo "No Requirement Photos";
                                                                }
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <div class="btn-group">
                                                                    <button type="button"
                                                                        style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                        class="btn btn-primary verify-btn" data-toggle="modal"
                                                                        data-target="#editBusInfoModal"
                                                                        data-registration-id="<?php echo $row['registration_id']; ?>"
                                                                        data-building-name="<?php echo htmlspecialchars($row['building_name']); ?>"
                                                                        data-business-name="<?php echo htmlspecialchars($row['business_name']); ?>"
                                                                        data-building-height="<?php echo htmlspecialchars($row['building_height']); ?>"
                                                                        data-total-area="<?php echo htmlspecialchars($row['total_area']); ?>"
                                                                        data-number-of-floors="<?php echo htmlspecialchars($row['number_of_floors']); ?>"
                                                                        data-address1="<?php echo htmlspecialchars($row['district']); ?>"
                                                                        data-barangay="<?php echo htmlspecialchars($row['barangay']); ?>"
                                                                        data-owner="<?php echo htmlspecialchars($row['owner_name']); ?>"
                                                                        data-contact-number="<?php echo htmlspecialchars($row['contact_number']); ?>"
                                                                        data-business-nature="<?php echo htmlspecialchars($row['business_nature']); ?>"
                                                                        data-occupancy="<?php echo htmlspecialchars($row['occupancy_type']); ?>"
                                                                        data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                                        data-fsic-expiry="<?php echo htmlspecialchars($row['FSIC_expiry']); ?>">
                                                                         Edit
                                                                    </button>

                                                                    <button type="button"
                                                                        style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                        class="btn btn-info view-details-btn"
                                                                        data-toggle="modal" data-target="#viewDetailsModal"
                                                                        data-registration-id="<?php echo $row['registration_id']; ?>"
                                                                        data-business="<?php echo htmlspecialchars($row['business_name']); ?>"
                                                                        data-building="<?php echo htmlspecialchars($row['building_name']); ?>"
                                                                        data-address="<?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>"
                                                                        data-owner="<?php echo htmlspecialchars($row['owner_name']); ?>"
                                                                        data-occupancy="<?php echo htmlspecialchars($row['occupancy_type']); ?>"
                                                                        data-contact="<?php echo htmlspecialchars($row['contact_number']); ?>"
                                                                        data-buildingheight="<?php echo htmlspecialchars($row['building_height']); ?>"
                                                                        data-totalarea="<?php echo htmlspecialchars($row['total_area']); ?>"
                                                                        data-numberoffloors="<?php echo htmlspecialchars($row['number_of_floors']); ?>"
                                                                        data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                                        data-fsicexpiry="<?php echo htmlspecialchars($row['FSIC_expiry']); ?>"
                                                                        data-status="<?php echo htmlspecialchars($row['status']); ?>">
                                                                        View <!-- View icon -->
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='9'>No records found</td></tr>";
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>


                                    <!-- Modal for View Details -->
                                    <div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog"
                                        aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title" id="viewDetailsModalLabel">View Inspection
                                                        Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><strong>Business Name:</strong> <span
                                                            id="modalBusinessName"></span></p>
                                                    <p><strong>Building Name:</strong> <span
                                                            id="modalBuildingName"></span></p>
                                                    <p><strong>Business Address:</strong> <span
                                                            id="modalBusinessAddress"></span></p>
                                                    <p><strong>Owner Name:</strong> <span id="modalOwnerName"></span>
                                                    </p>
                                                    <p><strong>Occupancy Type:</strong> <span
                                                            id="modalOccupancyType"></span></p>
                                                    <p><strong>Contact Number:</strong> <span
                                                            id="modalContactNumber"></span></p>
                                                    <p><strong>Building Height:</strong> <span
                                                            id="modalBuildingHeight"></span></p>
                                                    <p><strong>Total Area:</strong> <span id="modalTotalArea"></span>
                                                    </p>
                                                    <p><strong>Number of Floors:</strong> <span
                                                            id="modalNumberOfFloors"></span></p>
                                                    <p><strong>Email:</strong> <span id="modalEmail"></span></p>
                                                    <p><strong>Fsic Expiration:</strong> <span
                                                            id="modalFsicexpiry"></span></p>

                                                    <!-- Dynamic Buttons for Approve and Decline -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Modal for Edit Details -->
                                    <div class="modal fade" id="editBusInfoModal" tabindex="-1" role="dialog"
                                        aria-labelledby="editBusInfoModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title" id="editBusInfoModalLabel">Edit Business
                                                        Information</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="custom-container">
                                                        <form id="editForm" method="post" enctype="multipart/form-data"
                                                            action="update_application.php">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <input type="hidden" id="editRegistrationId"
                                                                        name="registration_id">
                                                                    <!-- Existing Fields Pre-Filled -->
                                                                    <div class="form-group">
                                                                        <label for="editBuildingName"
                                                                            class="text-dark">Name of Building</label>
                                                                        <input type="text" class="form-control"
                                                                            id="editBuildingName" name="buildingName"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editBuildingHeight"
                                                                            class="text-dark">Building Height
                                                                            (meters)</label>
                                                                        <input type="number" step="1"
                                                                            class="form-control" id="editBuildingHeight"
                                                                            name="buildingHeight" required min="0">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editTotalArea"
                                                                            class="text-dark">Total Area (square
                                                                            meters)</label>
                                                                        <input type="number" step="1"
                                                                            class="form-control" id="editTotalArea"
                                                                            name="totalArea" required min="0"
                                                                            maxlength="11">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editNumberOfFloors"
                                                                            class="text-dark">Number of Floors</label>
                                                                        <input type="number" class="form-control"
                                                                            id="editNumberOfFloors"
                                                                            name="numberOfFloors" required min="0">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editAddress"
                                                                            class="text-dark">Districts</label>
                                                                        <select class="form-control" id="editAddress"
                                                                            name="address1" required>
                                                                            <option value="">Select San Fernando City
                                                                            </option>
                                                                            <option value="District I">District I
                                                                            </option>
                                                                            <option value="District II">District II
                                                                            </option>
                                                                            <option value="District III">District III
                                                                            </option>
                                                                            <option value="District IV">District IV
                                                                            </option>
                                                                            <option value="District V">District V
                                                                            </option>
                                                                            <option value="District VI">District VI
                                                                            </option>
                                                                            <option value="District VII">District VII
                                                                            </option>
                                                                            <option value="District VIII">District VIII
                                                                            </option>
                                                                            <option value="District IX">District IX
                                                                            </option>
                                                                            <option value="District X">District X
                                                                            </option>
                                                                            <option value="District XI">District XI
                                                                            </option>
                                                                            <option value="District XII">District XII
                                                                            </option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editBarangay"
                                                                            class="text-dark">Barangay</label>
                                                                        <select class="form-control" id="editBarangay"
                                                                            name="barangay" required>
                                                                            <option value="">Select Barangay</option>
                                                                        </select>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="editOwner" class="text-dark">Name of
                                                                            Owner</label>
                                                                        <input type="text" class="form-control"
                                                                            id="editOwner" name="owner" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editContactNumber"
                                                                            class="text-dark">Contact Number</label>
                                                                        <input type="text" class="form-control"
                                                                            id="editContactNumber" name="contactNumber"
                                                                            required maxlength="11">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editBusinessNature"
                                                                            class="text-dark">Nature of Business</label>
                                                                        <input type="text" class="form-control"
                                                                            id="editBusinessNature"
                                                                            name="businessNature" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editBusinessName"
                                                                            class="text-dark">Business Name</label>
                                                                        <input type="text" class="form-control"
                                                                            id="editBusinessName" name="businessName"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editOccupancy"
                                                                            class="text-dark">Type of
                                                                            Occupancy</label>
                                                                        <select class="form-control" id="editOccupancy"
                                                                            name="occupancy" required>
                                                                            <option value="">Select Occupancy</option>
                                                                            <option value="Mercantile">Mercantile
                                                                            </option>
                                                                            <option value="Business">Business</option>
                                                                            <option value="Places of Assembly">Places of
                                                                                Assembly</option>
                                                                            <option value="Healthcare">Healthcare
                                                                            </option>
                                                                            <option value="Educational">Educational
                                                                            </option>
                                                                            <option value="Residential">Residential
                                                                            </option>
                                                                            <option value="Industrial">Industrial
                                                                            </option>
                                                                            <option value="Storage">Storage</option>

                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editEmail" class="text-dark">Email
                                                                            Address</label>
                                                                        <input type="email" class="form-control"
                                                                            id="editEmail" name="email" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="editFSICExpiry"
                                                                            class="text-dark">Expiry
                                                                            Date</label>
                                                                        <input type="date" class="form-control"
                                                                            id="editFSICExpiry" name="FSIC_expiry"
                                                                            required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" form="editForm"
                                                            class="btn btn-primary">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- add modal -->

                                    <div class="modal fade" id="addBusInfoModal" tabindex="-1" role="dialog"
                                        aria-labelledby="addBusInfoModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title" id="addBusInfoModalLabel">Add Business
                                                        Information</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="custom-container">
                                                        <form id="registrationForm" method="post"
                                                            enctype="multipart/form-data"
                                                            onsubmit="return validateForm();">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <!-- Existing Fields -->
                                                                    <div class="form-group">
                                                                        <label for="buildingName" class="text-dark">Name
                                                                            of Building</label>
                                                                        <input type="text" class="form-control"
                                                                            id="buildingName" name="buildingName"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="buildingHeight"
                                                                            class="text-dark">Building
                                                                            Height(meters)</label>
                                                                        <input type="number" step="1"
                                                                            class="form-control" id="buildingHeight"
                                                                            name="buildingHeight" required min="0">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="squareMeters"
                                                                            class="text-dark">Total
                                                                            Area(square
                                                                            meters)</label>
                                                                        <input type="number" step="1"
                                                                            class="form-control" id="squareMeters"
                                                                            name="squareMeters" required min="0">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="numberOfFloors"
                                                                            class="text-dark">Number
                                                                            of Floors</label>
                                                                        <input type="number" class="form-control"
                                                                            id="numberOfFloors" name="numberOfFloors"
                                                                            required min="0">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="Districts"
                                                                            class="text-dark">Districts</label>
                                                                        <select class="form-control" id="Districts"
                                                                            name="Districts" required>
                                                                            <option value="">Select San Fernando City
                                                                            </option>
                                                                            <option value="District I">District I
                                                                            </option>
                                                                            <option value="District II">District II
                                                                            </option>
                                                                            <option value="District III">District III
                                                                            </option>
                                                                            <option value="District IV">District IV
                                                                            </option>
                                                                            <option value="District V">District V
                                                                            </option>
                                                                            <option value="District VI">District VI
                                                                            </option>
                                                                            <option value="District VII">District VII
                                                                            </option>
                                                                            <option value="District VIII">District VIII
                                                                            </option>
                                                                            <option value="District IX">District IX
                                                                            </option>
                                                                            <option value="District X">District X
                                                                            </option>
                                                                            <option value="District XI">District XI
                                                                            </option>
                                                                            <option value="District XII">District XII
                                                                            </option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="barangay2"
                                                                            class="text-dark">Barangay</label>
                                                                        <select class="form-control" id="barangay2"
                                                                            name="barangay2" required>
                                                                            <option value="">Select Barangay</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="Requirements"
                                                                            class="text-dark">Requirements
                                                                            Photos</label>
                                                                        <input type="file" class="form-control"
                                                                            id="requirementsFile"
                                                                            name="requirementsFile" accept="image/*"
                                                                            multiple required>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6">

                                                                    <div class="form-group">
                                                                        <label for="owner" class="text-dark">Name of
                                                                            Owner</label>
                                                                        <input type="text" class="form-control"
                                                                            id="owner" name="owner" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="contactNumber"
                                                                            class="text-dark">Contact
                                                                            Number</label>
                                                                        <input type="text" class="form-control"
                                                                            id="contactNumber" name="contactNumber"
                                                                            required maxlength="11">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="businessNature"
                                                                            class="text-dark">Nature
                                                                            of Business</label>
                                                                        <input type="text" class="form-control"
                                                                            id="businessNature" name="businessNature"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="modalBusiness">Business Name</label>
                                                                        <input type="text" class="form-control"
                                                                            id="business_name" name="business_name"
                                                                            oninput="checkBusinessName()" required>
                                                                        <span id="check_business_name"
                                                                            for="business_name"></span>
                                                                    </div>
                                                                    <script>
                                                                        function checkBusinessName() {
                                                                            var businessName = $("#business_name").val();
                                                                            var isBusinessValid = false;  // Initialize as false

                                                                            // AJAX call to check business name
                                                                            jQuery.ajax({
                                                                                url: "businessVerif.php",  // PHP file to verify business name
                                                                                data: { business_name: businessName },
                                                                                type: "POST",
                                                                                async: false,  // Synchronous request to ensure the result is returned before proceeding
                                                                                success: function (data) {
                                                                                    $("#check_business_name").html(data);  // Display result in span

                                                                                    // Check if the result contains a specific message indicating business exists
                                                                                    if (data.includes("Business already exists")) {
                                                                                        isBusinessValid = false;  // Business name is invalid
                                                                                    } else {
                                                                                        isBusinessValid = true;  // Business name is valid
                                                                                    }
                                                                                },
                                                                                error: function () {
                                                                                    isBusinessValid = false;
                                                                                }
                                                                            });

                                                                            return isBusinessValid;  // Return the result of the validation
                                                                        }

                                                                        function validateForm() {
                                                                            // Call the checkBusinessName function before form submission
                                                                            if (!checkBusinessName()) {
                                                                                alert("Business name already exists. Please choose a different name.");
                                                                                return false;  // Prevent form submission
                                                                            }
                                                                            return true;  // Allow form submission if business name is valid
                                                                        }
                                                                    </script>

                                                                    <div class="form-group">
                                                                        <label for="Occupancy" class="text-dark">Type of
                                                                            Occupancy</label>
                                                                        <select class="form-control" id="Occupancy"
                                                                            name="Occupancy" required>
                                                                            <option value="">Select Occupancy</option>
                                                                            <option value="Mercantile">Mercantile
                                                                            </option>
                                                                            <option value="Business">Business</option>
                                                                            <option value="Places of Assembly">Places of
                                                                                Assembly</option>
                                                                            <option value="Healthcare">Healthcare
                                                                            </option>
                                                                            <option value="Educational">Educational
                                                                            </option>
                                                                            <option value="Residential">Residential
                                                                            </option>
                                                                            <option value="Industrial">Industrial
                                                                            </option>
                                                                            <option value="Storage">Storage</option>
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="email" class="text-dark">Email
                                                                            Address</label>
                                                                        <input type="email" class="form-control"
                                                                            id="email" name="email" required>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="FSIC_expiry"
                                                                            class="text-dark">Expiry
                                                                            Date</label>
                                                                        <input type="date" class="form-control"
                                                                            id="FSIC_expiry" name="FSIC_expiry"
                                                                            required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" form="registrationForm"
                                                            class="btn btn-primary">Submit</button>
                                                    </div>

                                                    <!-- Bootstrap JS -->
                                                    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
                                                    <script
                                                        src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
                                                    <script
                                                        src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
                                                    <script src="../assets/libs/js/main-js.js"></script>
                                                    <script
                                                        src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
                                                    <script
                                                        src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
                                                    <script
                                                        src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
                                                    <script src="../assets/vendor/datatables/js/data-table.js"></script>
                                                    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
                                                    <script src="businessinfo.js"></script>
                                                    <script src="updateApplication.js"></script>
                                                    <script src="update.js"></script>
                                                    <script src="view.js"></script>
                                                    <script>
                                                        $(document).ready(function () {

                                                            // When the #viewDetailsModal is shown, populate modal with data
                                                            $('#viewDetailsModal').on('show.bs.modal', function (event) {
                                                                var button = $(event.relatedTarget);
                                                                var status = button.data('status');
                                                                var registrationId = button.data('registration-id');

                                                                // Populate modal fields with data
                                                                $('#modalBusinessName').text(button.data('business'));
                                                                $('#modalBuildingName').text(button.data('building'));
                                                                $('#modalBusinessAddress').text(button.data('address'));
                                                                $('#modalOwnerName').text(button.data('owner'));
                                                                $('#modalOccupancyType').text(button.data('occupancy'));
                                                                $('#modalContactNumber').text(button.data('contact'));
                                                                $('#modalBuildingHeight').text(button.data('buildingheight'));
                                                                $('#modalTotalArea').text(button.data('totalarea'));
                                                                $('#modalNumberOfFloors').text(button.data('numberoffloors'));
                                                                $('#modalEmail').text(button.data('email'));
                                                                $('#modalFsicexpiry').text(button.data('fsicexpiry'));
                                                            });

                                                            // When the #editModal is shown, populate modal with form data
                                                            $('#editBusInfoModal').on('show.bs.modal', function (event) {
                                                                var button = $(event.relatedTarget);
                                                                console.log(button.data());
                                                                var registrationId = button.data('registration-id');
                                                                var buildingName = button.data('building-name');
                                                                var buildingHeight = button.data('building-height');
                                                                var totalArea = button.data('total-area');
                                                                var numberOfFloors = button.data('number-of-floors');
                                                                var address = button.data('address1');
                                                                var barangay = button.data('barangay');
                                                                var owner = button.data('owner');
                                                                var contactNumber = button.data('contact-number');
                                                                var businessNature = button.data('business-nature');
                                                                var businessName = button.data('business-name');
                                                                var occupancy = button.data('occupancy');
                                                                var email = button.data('email');
                                                                var fsicExpiry = button.data('fsic-expiry');

                                                                // Update the modal's fields with the data from the button
                                                                var modal = $(this);
                                                                modal.find('#editRegistrationId').val(registrationId);
                                                                modal.find('#editBuildingName').val(buildingName);
                                                                modal.find('#editBuildingHeight').val(buildingHeight);
                                                                modal.find('#editTotalArea').val(totalArea);
                                                                modal.find('#editNumberOfFloors').val(numberOfFloors);
                                                                modal.find('#editAddress').val(address);
                                                                modal.find('#editBarangay').val(barangay);
                                                                modal.find('#editOwner').val(owner);
                                                                modal.find('#editContactNumber').val(contactNumber);
                                                                modal.find('#editBusinessNature').val(businessNature);
                                                                modal.find('#editBusinessName').val(businessName);
                                                                modal.find('#editOccupancy').val(occupancy);
                                                                modal.find('#editEmail').val(email);
                                                                modal.find('#editFSICExpiry').val(fsicExpiry);
                                                            });


                                                            // Barangay population based on district selection
                                                            const barangays = {
                                                                "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
                                                                "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
                                                                "District III": ["Catbangen", "Parian", "Madayegdeg"],
                                                                "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
                                                                "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
                                                                "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
                                                                "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
                                                                "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
                                                                "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
                                                                "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
                                                                "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
                                                                "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
                                                            };

                                                            // Populate barangays based on selected district
                                                            $('#businessAddress').change(function () {
                                                                const district = $(this).val();
                                                                const barangaySelect = $('#barangay');

                                                                barangaySelect.empty();
                                                                barangaySelect.append('<option value="">Select Barangay</option>');

                                                                if (district in barangays) {
                                                                    barangays[district].forEach(barangay => {
                                                                        barangaySelect.append(new Option(barangay, barangay));
                                                                    });
                                                                }
                                                            });

                                                            // Filter functionality for district and barangay
                                                            $('#filterBtn').click(function () {
                                                                const selectedDistrict = $('#businessAddress').val();
                                                                const selectedBarangay = $('#barangay').val();

                                                                // If no filters are applied, show all rows
                                                                if (selectedDistrict === "" && selectedBarangay === "") {
                                                                    $('#dataTable tbody tr').show();
                                                                    return;
                                                                }

                                                                // Check if both district and barangay are selected
                                                                if (selectedDistrict !== "" && selectedBarangay !== "") {
                                                                    $('#dataTable tbody tr').each(function () {
                                                                        const rowAddress = $(this).find('td').eq(2).text().trim(); // Business Address (District and Barangay)

                                                                        // Extract the district and barangay from the business address column
                                                                        const [rowDistrict, rowBarangay] = rowAddress.split(',').map(item => item.trim());

                                                                        // Show or hide rows based on selected district and barangay
                                                                        if (rowDistrict === selectedDistrict && rowBarangay === selectedBarangay) {
                                                                            $(this).show();  // Show row if it matches the filter
                                                                        } else {
                                                                            $(this).hide();  // Hide row if it doesn't match
                                                                        }
                                                                    });
                                                                } else {
                                                                    alert('Please select both Business District and Barangay');
                                                                }
                                                            });
                                                        });
                                                    </script>

                                                    <script>
                                                        // District to Barangay mapping
                                                        const barangays = {
                                                            "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
                                                            "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
                                                            "District III": ["Catbangen", "Parian", "Madayegdeg"],
                                                            "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
                                                            "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
                                                            "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
                                                            "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
                                                            "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
                                                            "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
                                                            "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
                                                            "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
                                                            "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
                                                        };

                                                        // Event listener for District select
                                                        document.getElementById('editAddress').addEventListener('change', function () {
                                                            const address1 = this.value;
                                                            const barangaySelect = document.getElementById('editBarangay');

                                                            // Clear previous options
                                                            barangaySelect.innerHTML = '<option value="">Select Barangay</option>';

                                                            // Populate Barangay based on selected District
                                                            if (barangays[address1]) {
                                                                barangays[address1].forEach(function (barangay) {
                                                                    const option = document.createElement('option');
                                                                    option.value = barangay;
                                                                    option.textContent = barangay;
                                                                    barangaySelect.appendChild(option);
                                                                });
                                                            }
                                                        });
                                                    </script>