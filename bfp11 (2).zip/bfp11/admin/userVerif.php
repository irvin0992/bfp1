<?php
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize the username from the POST request
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Check if the username exists in the database
    $query = "SELECT * FROM tbl_users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo '<span style="color: red;">Username already taken</span>';
    } else {
        echo '<span style="color: green;">Username available</span>';
    }
} else {
    echo 'Invalid request';
}

mysqli_close($conn);
?>
