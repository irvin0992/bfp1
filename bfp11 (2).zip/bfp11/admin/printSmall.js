// When the modal is shown
$('#viewDetailsModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var inspectionId = button.data('inspection-id'); // Extract inspection_id from data-* attribute

    // Assign the inspection_id to the print button's data attribute
    $('#printButton').data('inspection-id', inspectionId);
});

// Click event for the print button
$('#printButton').off('click').on('click', function () {
    // Retrieve the inspection ID from the print button's data attribute
    var inspectionId = $(this).data('inspection-id');

    // Validation to ensure inspection ID is present
    if (inspectionId) {
        // Construct the URL for printing with the inspection ID
        var printUrl = `../ReportGen/RepGen_Small.php?inspection_id=${inspectionId}`;
        
        // Redirect to the URL to generate the PDF
        window.location.href = printUrl;
    } else {
        // Show an error if the inspection ID is missing
        alert("Inspection ID is missing. Please try again.");
    }
});
