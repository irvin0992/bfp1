<?php
include('../connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Update status in tbl_inspections
        $update_query = "UPDATE tbl_inspections SET status = 'For Approval' WHERE inspection_id = ?";
        $update_stmt = $conn->prepare($update_query);

        if ($update_stmt) {
            // Bind parameter and execute the statement
            $update_stmt->bind_param("i", $id);
            if ($update_stmt->execute()) {
                // Commit transaction
                $conn->commit();
                echo json_encode(['success' => true]);
            } else {
                throw new Exception('Execute error (update): ' . $update_stmt->error);
            }

            // Close update statement
            $update_stmt->close();
        } else {
            throw new Exception('Prepare error (update): ' . $conn->error);
        }
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        error_log($e->getMessage()); // Log the error
    }

    // Close connection
    $conn->close();
}
?>
