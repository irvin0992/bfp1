<?php
include '../connection.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the request
    $username = $_POST['username'];
    $userlevel = $_POST['userlevel'];
    $action = $_POST['action'];

    // Determine the new status based on the action
    $new_status = ($action === 'activate') ? 0 : 1;

    // Start the transaction
    $conn->begin_transaction();

    try {
        // If activating, deactivate all other users with the same userlevel first (for Admin or Fire Marshall)
        if ($action === 'activate' && ($userlevel === 'Administrator' || $userlevel === 'Fire Marshall')) {
            $sql_deactivate_others = "UPDATE tbl_users SET status = 1 WHERE userlevel = ? AND username != ?";
            $stmt_deactivate = $conn->prepare($sql_deactivate_others);
            $stmt_deactivate->bind_param("ss", $userlevel, $username);
            $stmt_deactivate->execute();
            $stmt_deactivate->close();
        }

        // Prepare the SQL query to update the current user status
        $sql = "UPDATE tbl_users SET status = ? WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $new_status, $username);

        // Execute the query to update the status
        if ($stmt->execute()) {
            // Commit the transaction
            $conn->commit();
            echo 'success'; // Return success response
        } else {
            throw new Exception('Update failed');
        }

        $stmt->close();
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        echo 'error'; // Return error if the transaction fails
    }

    $conn->close(); // Close the database connection
} else {
    echo 'invalid'; // Invalid request method
}
?>
