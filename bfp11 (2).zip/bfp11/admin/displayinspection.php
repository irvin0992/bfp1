<?php
include('../connection.php');

// Fetch inspectors data
$inspectors = [];
$inspectors_result = $conn->query("SELECT id, fname, mname, lname FROM tbl_users WHERE userlevel = 'Inspector'");

if ($inspectors_result && $inspectors_result->num_rows > 0) {
    while ($row = $inspectors_result->fetch_assoc()) {
        $inspectors[] = $row;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fire Safety Applications</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../style.css">
    

    <style>
                .custom-btn {
                    background-color: #b92828;
                    color: white;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    padding: 10px;
                    border: none;
                    border-radius: 5px;
                }
.custom-btn i {
    color: white;
}

.status-pending {
    color: #b92828;
}

.status-ready {
    color: #1b5e20;
}

.status-reinspect {
    color: #ffa500;
}

.status-passed {
    color: #808080;
}

.status-for-approval {
    color: #808080;
}

.status-ready-reinspection {
    color: #b92828; /* Tomato or any color you want for "Ready for Reinspection" */
}


                .approve-btn {
                    background-color: #d9534f;
                    color: white;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    padding: 10px;
                    border: none;
                    border-radius: 5px;
                }

                .approve-btn i {
                    color: white;
                }

                .approve-btn.disabled {
                    background-color: #d3d3d3;
                    border-radius: 20px;
                    cursor: not-allowed;
                }
            </style>
                <style>
        .modal-header {
            background-color: #dc3545;
            border-bottom: none;
        }

        .modal-body {
            font-size: 1.1rem;
        }

        .modal-footer {
            border-top: none;
            justify-content: center;
        }

        .btn-outline-success,
        .btn-outline-info {
            width: 48%;
            padding: 15px;
            font-size: 1rem;
        }

        .btn-outline-success:hover,
        .btn-outline-info:hover {
            background-color: #28a745;
            color: #fff;
        }

        .btn-outline-info:hover {
            background-color: #17a2b8;
            color: #fff;
        }
    </style>
</head>

<body>
    <?php include('../session_validate.php'); ?>
    <?php include('../header/header.php'); ?>
    <?php include('../sidebar/sidebar.php'); ?>

    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
    <i class="fa fa-user"></i>
    <?php
    if (isset($_SESSION['user_id'])) {
        // Assuming you have a connection to the database in $conn
        $user_id = intval($_SESSION['user_id']);
        
        // Query to get the user details from tbl_users
        $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id); // Bind the user_id
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Sanitize the output to prevent XSS attacks
            $fname = htmlspecialchars($row['fname']);
            $mname = htmlspecialchars($row['mname']);
            $lname = htmlspecialchars($row['lname']);
            echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
        } else {
            echo 'Welcome, User';
        }
        
        $stmt->close();
    }
    ?>
</h5>

                        <h2 class="pageheader-title" style="margin-top:10px;">
                            <i class="fa fa-fw fa-file-word"></i> Inspection
                        </h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Inspection Checklist</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div> 

            <script>
    var inspectors = <?php echo json_encode($inspectors); ?>;
</script>
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <h5 class="card-header">Inspection</h5>
                        <div class="card-body">
                            <div id="message"></div>
                            <div class="table-responsive">
                                <table id="inspectionTable" class="table table-striped table-bordered first">
                                    <thead>
                                        <tr>
                                            <th>Business Name</th>
                                            <th>Inspector Name</th>
                                            <th>Inspection Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Fetching inspections data including business name and remarks
                                        $inspection_result = $conn->query("
                                    SELECT i.*, b.business_name, r.FSIC_expiry, o.owner_name, bld.building_name, b.district, b.barangay, 
                                    bld.building_height, bld.total_area, bld.number_of_floors, b.occupancy_type, o.contact_number,r.email
                                    FROM tbl_inspections i
                                    INNER JOIN tbl_applications r ON i.application_id = r.application_id
                                    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
                                    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
                                    INNER JOIN tbl_buildings bld ON r.building_id = bld.building_id
                                    AND i.status NOT IN ('Reinspection', 'Ready for Inspection', 'Ready for Reinspection', 'Passed', 'For Approval', 'Approved' )
                                    
                                    ");
                                    
                                    if ($inspection_result && $inspection_result->num_rows > 0) {
                                        while ($row = $inspection_result->fetch_assoc()) {
                                            $status = 'Pending'; // Default status
                                        
                                            // Check if inspection is approved
                                            if (!empty($row['inspector_fname']) && !empty($row['inspector_lname']) && !empty($row['inspection_date'])) {
                                                $status = 'Ready for Inspection';
                                                // Concatenate first, middle, and last names
                                                $inspector_fullname = $row['inspector_fname'] . ' ' . (!empty($row['inspector_mname']) ? $row['inspector_mname'] . ' ' : '') . $row['inspector_lname'];
                                                
                                                // Do something with the inspector full name
                                                // echo $inspector_fullname;
                                            }                                            
                                    
                                            // Check if inspection is reinspect
                                            if ($row['status'] == 'Reinspection') {
                                                $status = 'Reinspection';
                                            }
                                    
                                            // Check if inspection is passed
                                            if ($row['status'] == 'Passed') {
                                                $status = 'Passed';
                                            }
                                            if ($row['status'] == 'Ready for Reinspection') {
                                                $status = 'Ready for Reinspection';
                                            }
                                    
                                            // Check if inspection is for approval
                                            if ($row['status'] == 'For Approval') {
                                                $status = 'For Approval';
                                            }
                                            if ($row['status'] == 'Approved') {
                                                $status = 'Approved';
                                            }
                                    
                                            // Display table row with status and action buttons
                                            ?>
                                                <tr>
    <td><?php echo htmlspecialchars($row['business_name']); ?></td>
    <td> <?php  echo htmlspecialchars($row['inspector_fname'] . ' ' . (!empty($row['inspector_mname']) ? $row['inspector_mname'] . ' ' : '') . $row['inspector_lname']); ?>
</td>

    <td><?php echo htmlspecialchars($row['inspection_date']); ?></td>
    <td
        class="<?php echo ($status == 'Pending') ? 'status-pending' : (($status == 'Ready for Inspection') ? 'status-ready' : (($status == 'Ready for Reinspection') ? 'status-reinspect' : (($status == 'Passed') ? 'status-passed' : 'status-for-approval'))); ?>">
        <?php echo htmlspecialchars($status); ?>
    </td>
    <td>
        <div class="d-flex justify-content-center">

            <!-- Edit Button (Calendar Button) -->
            <?php if ($status !== 'Passed' && $status !== 'For Approval' && $status !== 'Approved') { ?>
                <button
                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                    class="btn custom-btn edit-btn mx-1"
                    data-business="<?php echo htmlspecialchars($row['business_name']); ?>"
                    data-inspector-name="<?php echo htmlspecialchars($row['inspector_fname'] . ' ' . (!empty($row['inspector_mname']) ? $row['inspector_mname'] . ' ' : '') . $row['inspector_lname']); ?>"
                    data-inspection-date="<?php echo htmlspecialchars($row['inspection_date']); ?>"
                    data-remarks="<?php echo htmlspecialchars($row['remarks']); ?>"
                    data-status="<?php echo htmlspecialchars($status); ?>"
                    data-id="<?php echo $row['inspection_id']; ?>"
                    data-toggle="modal" data-target="#editModal"
                    <?php echo ($status == 'Ready for Inspection' || $status == 'Ready for Reinspection') ? 'disabled' : ''; ?>>
                     Set Date
                </button>
            <?php } ?>

            <!-- Approval Button -->
            <?php if ($status == 'For Approval') { ?>
                <button class="btn btn-secondary mx-1" style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;" disabled>
                    For Approval
                </button>
            <?php } elseif ($status == 'Passed') { ?>
                <button class="btn btn-success mx-1 approve-btn"  style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                    data-id="<?php echo $row['inspection_id']; ?>">
                    Approve
                </button>
            <?php } elseif ($status == 'Approved') { ?>
                <button class="btn btn-secondary mx-1" style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;" disabled>
                    Approved
                </button>
            <?php } ?>

            <!-- View Details Button -->
            <button type="button"
                                                                        style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                        class="btn btn-info view-details-btn"
                                                                        data-toggle="modal" data-target="#viewDetailsModal"
                                                                        data-registration-id="<?php echo $row['application_id']; ?>"
                                                                        data-business="<?php echo htmlspecialchars($row['business_name']); ?>"
                                                                        data-building="<?php echo htmlspecialchars($row['building_name']); ?>"
                                                                        data-address="<?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>"
                                                                        data-owner="<?php echo htmlspecialchars($row['owner_name']); ?>"
                                                                        data-occupancy="<?php echo htmlspecialchars($row['occupancy_type']); ?>"
                                                                        data-contact="<?php echo htmlspecialchars($row['contact_number']); ?>"
                                                                        data-buildingheight="<?php echo htmlspecialchars($row['building_height']); ?>"
                                                                        data-totalarea="<?php echo htmlspecialchars($row['total_area']); ?>"
                                                                        data-numberoffloors="<?php echo htmlspecialchars($row['number_of_floors']); ?>"
                                                                        data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                                        data-fsicexpiry="<?php echo htmlspecialchars($row['FSIC_expiry']); ?>"
                                                                        data-status="<?php echo htmlspecialchars($row['status']); ?>">
                                                                        View
                                                                    </button>
        </div>
    </td>
</tr>


                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='5'>No records found</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

            
                    <!-- Modal for View Details -->
                            <div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog"
                                        aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header text-white">
                                                    <h5 class="modal-title" id="viewDetailsModalLabel">View Inspection
                                                        Details</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><strong>Business Name:</strong> <span
                                                            id="modalBusinessName"></span></p>
                                                    <p><strong>Building Name:</strong> <span
                                                            id="modalBuildingName"></span></p>
                                                    <p><strong>Business Address:</strong> <span
                                                            id="modalBusinessAddress"></span></p>
                                                    <p><strong>Owner Name:</strong> <span id="modalOwnerName"></span>
                                                    </p>
                                                    <p><strong>Occupancy Type:</strong> <span
                                                            id="modalOccupancyType"></span></p>
                                                    <p><strong>Contact Number:</strong> <span
                                                            id="modalContactNumber"></span></p>
                                                    <p><strong>Building Height:</strong> <span
                                                            id="modalBuildingHeight"></span></p>
                                                    <p><strong>Total Area:</strong> <span id="modalTotalArea"></span>
                                                    </p>
                                                    <p><strong>Number of Floors:</strong> <span
                                                            id="modalNumberOfFloors"></span></p>
                                                    <p><strong>Email:</strong> <span
                                                            id="modalEmail"></span></p>
                                                    <p><strong>Fsic Expiration:</strong> <span
                                                            id="modalFsicexpiry"></span></p>

                                                    <!-- Dynamic Buttons for Approve and Decline -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>


        <!-- Modal -->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header text-white">
                        <h5 class="modal-title" id="editModalLabel">Edit Inspection Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="editForm" action="update_inspection.php" method="POST">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="businessName">Business Name</label>
                                <input type="text" class="form-control" id="businessName" name="businessName" readonly>
                            </div>
                            <div class="form-group">
                                <label for="inspectorName">Inspector Name</label>
                                <select class="form-control" id="inspectorName" name="inspectorName" required>
                                    <!-- Options will be populated by JavaScript -->
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="inspectionDate">Inspection Date</label>
                                <input type="date" class="form-control" id="inspectionDate" name="inspectionDate"
                                    required min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <!-- <div class="form-group">
                                <label for="dateIssued">Date Issued</label>
                                <input type="date" class="form-control" id="dateIssued" name="dateIssued"
                                    value="<?php echo date('Y-m-d'); ?>" readonly>
                            </div> -->
                            <div class="form-group">
                                <label for="remarks">Remarks</label>
                                <textarea class="form-control" id="remarks" name="remarks" rows="3" readonly></textarea>
                            </div>
                            <input type="hidden" id="inspectionId" name="inspectionId">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
        <script src="../assets/libs/js/main-js.js"></script>
        <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
        <script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
        <script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
        <script src="../assets/vendor/datatables/js/data-table.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <script src="submit.js"></script>
        <script src="viewInspection.js"></script>
        <script src="filter.js"></script>

        <script>
            // Populate inspectors dropdown
            document.addEventListener('DOMContentLoaded', function () {
    var inspectorNameSelect = document.getElementById('inspectorName');
    
    // Clear current options before adding
    inspectorNameSelect.innerHTML = '';

    inspectors.forEach(function (inspector) {
        var inspectorFullName = inspector.fname + ' ' + 
            (inspector.mname ? inspector.mname + ' ' : '') + 
            inspector.lname;

        var option = document.createElement('option');
        option.value = inspectorFullName;  // Use the full name as value
        option.text = inspectorFullName;   // Display the full name in dropdown

        inspectorNameSelect.appendChild(option);
    });

                $(document).on('click', '.edit-btn', function () {
                    var businessName = $(this).data('business');
                    var inspectorName = $(this).data('inspector-name');
                    var inspectionDate = $(this).data('inspection-date');
                    var inspectionId = $(this).data('id');
                    var remarks = $(this).data('remarks');
                    var status = $(this).data('status'); // Get the status

                    $('#businessName').val(businessName);
                    $('#inspectorName').val(inspectorName);
                    $('#inspectionDate').val(inspectionDate);
                    $('#inspectionId').val(inspectionId);

                    // Show remarks only if the status is 'Reinspect'
                    if (status === '') {
                        $('#remarks').val(remarks).closest('.form-group').show();
                    } else {
                        $('#remarks').val('').closest('.form-group').hide();
                    }


                });

                // Handle approve button click with SweetAlert confirmation
                $(document).on('click', '.approve-btn', function () {
                    var inspectionId = $(this).data('id');
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You are about to approve this inspection.",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Approve'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Perform AJAX request to insert approved inspection
                            $.ajax({
                                url: 'approve_inspection.php',
                                method: 'POST',
                                data: { id: inspectionId },
                                success: function (response) {
                                    var res = JSON.parse(response);
                                    if (res.success) {
                                        Swal.fire(
                                            'Approved!',
                                            'The inspection has been approved.',
                                            'success'
                                        ).then(() => {
                                            // Optionally, you can reload the table or the page here
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire(
                                            'Error!',
                                            'There was an error approving the inspection.',
                                            'error'
                                        );
                                    }
                                },
                                error: function () {
                                    Swal.fire(
                                        'Error!',
                                        'There was an error processing your request.',
                                        'error'
                                    );
                                }
                            });
                        }
                    });
                });

                // Filter and generate report functionality
                $('#filterBtn').click(function () {
                    var fromDate = $('#fromDate').val();
                    var toDate = $('#toDate').val();
                    // Add your filter logic here
                });

                $('#generateReportBtn').click(function () {
                    var fromDate = $('#fromDate').val();
                    var toDate = $('#toDate').val();
                    $('#startDate').val(fromDate);
                    $('#endDate').val(toDate);
                    $('#reportForm').submit();
                });
            });
        </script>

<script>
                                                        $(document).ready(function () {

                                                            // When the #viewDetailsModal is shown, populate modal with data
                                                            $('#viewDetailsModal').on('show.bs.modal', function (event) {
                                                                var button = $(event.relatedTarget);
                                                                var status = button.data('status');
                                                                var registrationId = button.data('registration-id');

                                                                // Populate modal fields with data
                                                                $('#modalBusinessName').text(button.data('business'));
                                                                $('#modalBuildingName').text(button.data('building'));
                                                                $('#modalBusinessAddress').text(button.data('address'));
                                                                $('#modalOwnerName').text(button.data('owner'));
                                                                $('#modalOccupancyType').text(button.data('occupancy'));
                                                                $('#modalContactNumber').text(button.data('contact'));
                                                                $('#modalBuildingHeight').text(button.data('buildingheight'));
                                                                $('#modalTotalArea').text(button.data('totalarea'));
                                                                $('#modalNumberOfFloors').text(button.data('numberoffloors'));
                                                                $('#modalEmail').text(button.data('email'));
                                                                $('#modalFsicexpiry').text(button.data('fsicexpiry'));
                                                            });

                                                            // When the #editModal is shown, populate modal with form data
                                                            $('#editBusInfoModal').on('show.bs.modal', function (event) {
                                                                var button = $(event.relatedTarget);
                                                                console.log(button.data());
                                                                var registrationId = button.data('registration-id');
                                                                var buildingName = button.data('building-name');
                                                                var buildingHeight = button.data('building-height');
                                                                var totalArea = button.data('total-area');
                                                                var numberOfFloors = button.data('number-of-floors');
                                                                var address = button.data('address1');
                                                                var barangay = button.data('barangay');
                                                                var owner = button.data('owner');
                                                                var contactNumber = button.data('contact-number');
                                                                var businessNature = button.data('business-nature');
                                                                var businessName = button.data('business-name');
                                                                var occupancy = button.data('occupancy');
                                                                var email = button.data('email');
                                                                var fsicExpiry = button.data('fsic-expiry');

                                                                // Update the modal's fields with the data from the button
                                                                var modal = $(this);
                                                                modal.find('#editRegistrationId').val(registrationId);
                                                                modal.find('#editBuildingName').val(buildingName);
                                                                modal.find('#editBuildingHeight').val(buildingHeight);
                                                                modal.find('#editTotalArea').val(totalArea);
                                                                modal.find('#editNumberOfFloors').val(numberOfFloors);
                                                                modal.find('#editAddress').val(address);
                                                                modal.find('#editBarangay').val(barangay);
                                                                modal.find('#editOwner').val(owner);
                                                                modal.find('#editContactNumber').val(contactNumber);
                                                                modal.find('#editBusinessNature').val(businessNature);
                                                                modal.find('#editBusinessName').val(businessName);
                                                                modal.find('#editOccupancy').val(occupancy);
                                                                modal.find('#editEmail').val(email);
                                                                modal.find('#editFSICExpiry').val(fsicExpiry);
                                                            });


                                                            // Barangay population based on district selection
                                                            const barangays = {
                                                                "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
                                                                "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
                                                                "District III": ["Catbangen", "Parian", "Madayegdeg"],
                                                                "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
                                                                "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
                                                                "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
                                                                "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
                                                                "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
                                                                "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
                                                                "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
                                                                "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
                                                                "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
                                                            };

                                                            // Populate barangays based on selected district
                                                            $('#businessAddress').change(function () {
                                                                const district = $(this).val();
                                                                const barangaySelect = $('#barangay');

                                                                barangaySelect.empty();
                                                                barangaySelect.append('<option value="">Select Barangay</option>');

                                                                if (district in barangays) {
                                                                    barangays[district].forEach(barangay => {
                                                                        barangaySelect.append(new Option(barangay, barangay));
                                                                    });
                                                                }
                                                            });

                                                            // Filter functionality for district and barangay
                                                            $('#filterBtn').click(function () {
                                                                const selectedDistrict = $('#businessAddress').val();
                                                                const selectedBarangay = $('#barangay').val();

                                                                // If no filters are applied, show all rows
                                                                if (selectedDistrict === "" && selectedBarangay === "") {
                                                                    $('#dataTable tbody tr').show();
                                                                    return;
                                                                }

                                                                // Check if both district and barangay are selected
                                                                if (selectedDistrict !== "" && selectedBarangay !== "") {
                                                                    $('#dataTable tbody tr').each(function () {
                                                                        const rowAddress = $(this).find('td').eq(2).text().trim(); // Business Address (District and Barangay)

                                                                        // Extract the district and barangay from the business address column
                                                                        const [rowDistrict, rowBarangay] = rowAddress.split(',').map(item => item.trim());

                                                                        // Show or hide rows based on selected district and barangay
                                                                        if (rowDistrict === selectedDistrict && rowBarangay === selectedBarangay) {
                                                                            $(this).show();  // Show row if it matches the filter
                                                                        } else {
                                                                            $(this).hide();  // Hide row if it doesn't match
                                                                        }
                                                                    });
                                                                } else {
                                                                    alert('Please select both Business District and Barangay');
                                                                }
                                                            });
                                                        });
                                                    </script>
</body>

</html>