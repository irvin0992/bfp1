<?php
// Include the database connection
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);  // First name
    $mname = mysqli_real_escape_string($conn, $_POST['mname']);  // Middle name
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);  // Last name
    $pword = $_POST['password'];
    $cpword = $_POST['confirmpassword'];
    $userlevel = mysqli_real_escape_string($conn, $_POST['userlevel']);
    $status = 1;  // Default status for new users (inactive)

    // Validate if passwords match
    if ($pword !== $cpword) {
        echo 'password_mismatch';
        exit;
    }

    // Hash the password
    $hashed_pword = password_hash($pword, PASSWORD_DEFAULT);

    // Check if the username already exists
    $check_query = "SELECT * FROM tbl_users WHERE username = '$username'";
    $result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($result) > 0) {
        // Username already exists
        echo 'exists';
        exit;
    }

    // Handle single active Administrator or City Fire Marshall logic
    if ($userlevel === 'Administrator' || $userlevel === 'Fire Marshall') {
        // Deactivate any currently active user with the same user level
        $deactivate_query = "UPDATE tbl_users SET status = 1 WHERE userlevel = '$userlevel' AND status = 0";
        mysqli_query($conn, $deactivate_query);
        // Set the status for the new Administrator or City Fire Marshall to active (0)
        $status = 0;
    }
    
    // Insert the new user into the database with the correct status
    $insert_query = "INSERT INTO tbl_users (username, fname, mname, lname, pword, userlevel, status) 
                     VALUES ('$username', '$fname', '$mname', '$lname', '$hashed_pword', '$userlevel', '$status')";

    if (mysqli_query($conn, $insert_query)) {
        // Get the ID of the newly inserted user
        $user_id = mysqli_insert_id($conn);
        $activity_type = 'insert';
        $activity_desc = 'User registered: ' . $username;

        // Log the activity (insert action)
        $log_query = "INSERT INTO tbl_activity_log (id, activity_type, activity_time, activity_desc)
                      VALUES ('$user_id', '$activity_type', NOW(), '$activity_desc')";

        if (!mysqli_query($conn, $log_query)) {
            // Log the error if logging fails
            error_log('Logging failed: ' . mysqli_error($conn));  // Log error to server log
        }

        echo 'success';  // Return success response
    } else {
        // Handle the error during user insertion
        echo 'error';
    }
} else {
    // Handle invalid requests that are not POST
    echo 'invalid_request';
}

// Close the database connection
mysqli_close($conn);

?>
