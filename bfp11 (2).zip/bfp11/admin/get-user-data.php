<?php
include '../connection.php'; // include your database connection file

if (isset($_POST['id'])) {
    $userId = $_POST['id'];

    // Query to fetch user details by ID
    $query = "SELECT * FROM tbl_users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Return user details as JSON
    echo json_encode($user);
}
?>
