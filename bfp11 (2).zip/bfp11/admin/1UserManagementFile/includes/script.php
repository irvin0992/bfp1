<!-- Bootstrap core JavaScript-->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="../vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="../js/demo/chart-area-demo.js"></script>
<script src="../js/demo/chart-pie-demo.js"></script>

<!-- sweetalert2 -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.all.min.js"></script>


<!-- SWAL FOR ADDING -->
<script>
    $(document).ready(function() {
        $('#insertForm').on('submit', function(e) {
            e.preventDefault();

            // Capture form data
            var formData = $(this).serialize();

            // Show SweetAlert confirmation
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to add this data?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, add it!',
                cancelButtonText: 'No, cancel!',
                customClass: {
                    confirmButton: 'swal2-confirm-custom',
                    cancelButton: 'swal2-cancel-custom'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Send AJAX request
                    $.ajax({
                        type: 'POST',
                        url: '1UserManagementFile/addUser.php',
                        data: formData,
                        success: function(response) {
                            let res = JSON.parse(response);
                            if (res.success) {
                                Swal.fire(
                                    'Added!',
                                    res.message,
                                    'success'
                                ).then(() => {
                                    // Redirect to the desired URL
                                    window.location.href = '1userManagement.php';
                                });
                            } else {
                                Swal.fire(
                                    'Error!',
                                    res.message,
                                    'error'
                                );
                            }
                        },
                        error: function() {
                            Swal.fire(
                                'Error!',
                                'There was an issue adding your data.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });
</script>

<style>
    .swal2-confirm-custom {
        background-color: #DCFFB7 !important; /* Custom background color */
        color: black !important; /* Custom text color */
    }

    .swal2-cancel-custom {
        background-color: #D6EFD8 !important; /* Custom background color */
        color: black !important; /* Custom text color */
    }
</style>




<!-- swal for update -->
<script>
    $('#updateForm').on('submit', function(e) {
        e.preventDefault();

        var formData = $(this).serialize();

        // Show SweetAlert confirmation
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to update this data?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, update it!',
            cancelButtonText: 'No, cancel!',
            customClass: {
                confirmButton: 'swal2-confirm-custom',
                cancelButton: 'swal2-cancel-custom'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Send AJAX request
                $.ajax({
                    type: 'POST',
                    url: 'update.php',
                    data: formData,
                    success: function(response) {
                        let res = JSON.parse(response);
                        if (res.success) {
                            Swal.fire(
                                'Updated!',
                                res.message,
                                'success'
                            ).then(() => {
                                // Redirect to the desired URL
                                window.location.href = '../1userManagement.php';
                            });
                        } else {
                            Swal.fire(
                                'Error!',
                                res.message,
                                'error'
                            );
                        }
                    },
                    error: function() {
                        Swal.fire(
                            'Error!',
                            'There was an issue updating your data.',
                            'error'
                        );
                    }
                });
            }
        });
    });
</script>

<!-- swal for log out -->
<script>
    $(document).ready(function() {
        $('#logout-link').on('click', function(e) {
            e.preventDefault();
            Swal.fire({
                title: "Are you sure?",
                text: "You will be logged out.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, log out",
                cancelButtonText: "No, stay logged in"
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: 'POST',
                        url: '../../../logout.php', // your logout URL
                        data: {},
                        success: function(data) {
                            Swal.fire({
                                title: "Logged out successfully!",
                                text: "You have been logged out.",
                                icon: "success",
                                showConfirmButton: false,
                                timer: 1000
                            }).then((result) => {
                                window.location.href = '../../../index.php'; // redirect to homepage or any other page
                            });
                        },
                        error: function(xhr, status, error) {
                            Swal.fire({
                                title: "Error",
                                text: "Failed to logout. Please try again.",
                                icon: "error",
                                showConfirmButton: false,
                                timer: 1000
                            });
                        }
                    });
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $.ajax({
            type: 'GET',
            url: '../7announcementManagementFile/get_announcement.php',
            dataType: 'json',
            success: function(data) {
                var dropdownList = $('.dropdown-list');
                dropdownList.html(''); // clear the dropdown list

                $.each(data, function(index, announcement) {
                    var notificationHTML = `
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3 bg">
                                <div class="icon-circle bg-success">
                                    <i class="fas fa-bell text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">${announcement.date}</div>
                                <span class="font-weight-bold">${announcement.title}</span>
                                <div class="small text-gray-500">${announcement.message}</div>
                            </div>
                        </a>
                    `;
                    dropdownList.append(notificationHTML);
                });

                // Update the badge counter
                var badgeCounter = $('.badge-counter');
                badgeCounter.text(data.length);
            }
        });
    });
</script>