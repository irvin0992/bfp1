<?php
include('../../../conn.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uname = $_POST['username'];
    $fname = $_POST['firstname'];
    $mname = $_POST['middlename'];
    $lname = $_POST['lastname'];

    $sql = "UPDATE tbl_user SET fname=?, mname=?, lname=? WHERE uname=?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssss", $fname, $mname, $lname, $uname);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Data Updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'An error occurred while updating the data.']);
    }
}
