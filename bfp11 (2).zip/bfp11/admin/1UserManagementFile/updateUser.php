<?php include('includes/header.php'); ?>
<?php include('includes/navbar.php'); ?>
<?php include('../../../conn.php'); ?>

<?php

if (isset($_GET['id'])) {
    $username = $_GET['id'];
    $stmt = $con->prepare("SELECT * FROM tbl_user WHERE uname= ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $userData = $result->fetch_assoc();
        $username = $userData['uname'];
        $firstName = $userData['fname'];
        $middleName = $userData['mname'];
        $lastName = $userData['lname'];
    } else {
        echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'No results found!',
            footer: ''
        })
      </script>";
    }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class=" mb-0 text-gray-800 fw-bolder">Update User Data</h1>
    </div>

    <!-- divider -->
    <div class="card shadow mb-4">
        <div class="card-header py-3" style="background-color: #0D7C66;">
        </div>


        <form id="updateForm" method="POST">
            <div class="modal-body">
                <div class="form-group">

                    <input type="hidden" name="username" id="uname" class="form-control" placeholder="Enter Username" value="<?php echo $username ?>" required readonly>
                </div>
                <div class="form-group">
                    <label>Firstname</label>
                    <input type="text" name="firstname" id="fname" class="form-control"
                        placeholder="Enter Firstname" value="<?php echo htmlspecialchars($firstName); ?>"
                        required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                        oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                </div>
                <div class="form-group">
                    <label>Middlename</label>
                    <input type="text" name="middlename" id="mname" class="form-control"
                        placeholder="Enter Middlename" value="<?php echo htmlspecialchars($middleName); ?>"
                        required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                        oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                </div>
                <div class="form-group">
                    <label>Lastname</label>
                    <input type="text" name="lastname" id="lname" class="form-control"
                        placeholder="Enter Lastname" value="<?php echo htmlspecialchars($lastName); ?>"
                        required pattern="[A-Za-z\s]+" title="Only letters and spaces are allowed"
                        oninput="this.value = this.value.replace(/[^A-Za-z\s]/g, '')">
                </div>

                <button type="submit" id="save" name="updatebtn" class="btn" style="background-color: #DCFFB7; color: black;">Update</button>
                <a href="../1userManagement.php" class="btn" style="background-color: #D6EFD8; color: black;">Close</a>
            </div>
        </form>

    </div>
</div>
<?php
include('includes/script.php');
include('includes/footer.php');
?>