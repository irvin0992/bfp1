
<?php
include('../../../conn.php');

if (!empty($_POST["username"])) {
    $stmt = $con->prepare("SELECT * FROM tbl_user WHERE uname = ?");
    $stmt->bind_param("s", $_POST["username"]);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->num_rows;
    if ($count > 0) {
        echo "<span style='color:red'>Username Already Exists.</span>";
        echo "<script>$('#save').prop('disabled',true);";
    } else {
        echo "<span style='color:green'>Username Available.</span>";
        echo "<script>$('#save').prop('disabled',false);";
    }
}



?>