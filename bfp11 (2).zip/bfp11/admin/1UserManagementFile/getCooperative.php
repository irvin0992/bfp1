<?php
// getCooperatives.php
$cooperatives = array(
    "Cooperative 1",
    "Cooperative 2",
    "Cooperative 3",
    // ...
);

echo "<option selected>Select Cooperative</option>";
foreach ($cooperatives as $cooperative) {
    echo "<option value='$cooperative'>$cooperative</option>";
}
