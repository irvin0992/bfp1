<?php
include('../../../conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uname = $_POST['username'];
    $pword = $_POST['password'];
    $confirm_password = $_POST['confirmpassword'];
    $fname = $_POST['firstname'];
    $mname = $_POST['middlename'];
    $lname = $_POST['lastname'];
    $userlevel = $_POST['userlevel'];
    $coop_no = $_POST['coop_no'] ?? ''; // assuming this is the coop_no value
    $contact_no = $_POST['contact_no'];

    // Check if passwords match
    if ($pword !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'Passwords do not match.']);
        exit;
    }

    // Check if password is at least 8 characters long
    if (strlen($pword) < 8) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters long.']);
        exit;
    }

    // Check if username already exists
    $check_sql = "SELECT * FROM tbl_user WHERE uname =?";
    $check_stmt = $con->prepare($check_sql);
    $check_stmt->bind_param("s", $uname);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Username already exists.']);
        exit;
    }

    // Check if full name already exists
    $check_fullname_sql = "SELECT * FROM tbl_user WHERE fname =? AND mname =? AND lname =?";
    $check_fullname_stmt = $con->prepare($check_fullname_sql);
    $check_fullname_stmt->bind_param("sss", $fname, $mname, $lname);
    $check_fullname_stmt->execute();
    $fullname_result = $check_fullname_stmt->get_result();

    if ($fullname_result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'No duplicate Entry for Full Name.']);
        exit;
    }

    // Check if contact number already exists (for Keyperson)
    if ($userlevel == 'Keyperson') {
        $check_contact_sql = "SELECT * FROM tbl_keyperson WHERE contact_no = ?";
        $check_contact_stmt = $con->prepare($check_contact_sql);
        $check_contact_stmt->bind_param("s", $contact_no);
        $check_contact_stmt->execute();
        $contact_result = $check_contact_stmt->get_result();

        if ($contact_result->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Contact number already exists.']);
            exit;
        }
    }

    // Hash the password
    $hashed_password = password_hash($pword, PASSWORD_DEFAULT);

    // Insert data into tbl_user
    $sql = "INSERT INTO tbl_user (uname, pword, fname, mname, lname, userlvl, status) VALUES (?,?,?,?,?,?,0)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssssss", $uname, $hashed_password, $fname, $mname, $lname, $userlevel);

    if ($stmt->execute()) {
        if ($userlevel == 'Admin') {
            // Update previous active admin(s) to inactive (status = 1) but exclude the newly added admin
            $update_sql = "UPDATE tbl_user SET status = 1 WHERE userlvl = 'Admin' AND uname != ?";
            $update_stmt = $con->prepare($update_sql);
            $update_stmt->bind_param("s", $uname);
            $update_stmt->execute();
        } elseif ($userlevel == 'Keyperson') {
            // Insert into tbl_keyperson
            $keyperson_sql = "INSERT INTO tbl_keyperson (uname, coop_no, contact_no) VALUES (?,?,?)";
            $keyperson_stmt = $con->prepare($keyperson_sql);
            $keyperson_stmt->bind_param("sss", $uname, $coop_no, $contact_no);
            $keyperson_stmt->execute();
        }
        echo json_encode(['success' => true, 'message' => 'Data added successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'An error occurred while adding the data: ' . $stmt->error]);
    }
}
