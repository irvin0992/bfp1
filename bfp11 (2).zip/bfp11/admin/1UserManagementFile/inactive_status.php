<?php
include '../../../conn.php';

$uname = $_POST['uname'];    // The username to update
$data = array();  // Array to hold the response data
$status1 = "1";   // New status to set for other users of the same level

function updateMAOStatus($con, $userlvl, $uname, $status1) {
        // Update the specific user to have status '0'
    $stmt2 = mysqli_prepare($con, "UPDATE tbl_user SET status=? WHERE uname=? AND userlvl=?");
    mysqli_stmt_bind_param($stmt2, "sss", $status1, $uname, $userlvl);
    mysqli_stmt_execute($stmt2);

    // Check if both updates were successful
    return mysqli_stmt_affected_rows($stmt2) > 0;
}

function updateKeypersonStatus($con, $userlvl, $uname, $status1) {

    // Update the specific user to have status '0'
    $stmt2 = mysqli_prepare($con, "UPDATE tbl_user SET status=? WHERE uname=? AND userlvl=?");
    mysqli_stmt_bind_param($stmt2, "sss", $status1, $uname, $userlvl);
    mysqli_stmt_execute($stmt2);

    return mysqli_stmt_affected_rows($stmt2) > 0;
}

// Fetch the user level from the database based on the username
$stmt = mysqli_prepare($con, "SELECT userlvl FROM tbl_user WHERE uname=?");
mysqli_stmt_bind_param($stmt, "s", $uname);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $userlvl);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

// Check if user level is retrieved and valid
if ($userlvl) {
    // Valid user level check
    if ($userlvl === 'MAO Employee' || $userlvl === 'Keyperson') {
        if (updateKeypersonStatus($con, $userlvl, $uname, $status1, $status1)) {
            $data['response'] = 'success';
        } else {
            $data['response'] = 'error';
        }
    }
} else {
    // If user level could not be retrieved
    $data['response'] = 'user_not_found';
}

// Output the response as JSON
echo json_encode($data);

// Close the database connection
mysqli_close($con);
?>
