// When the submit button is clicked
$('#inspectionForm').on('submit', function (e) {
    e.preventDefault(); // Prevent form from submitting normally

    // SweetAlert confirmation
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to submit this inspection checklist?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, submit it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // If confirmed, make an AJAX call to submit data
            $.ajax({
                type: 'POST',
                url: 'submit_inspection.php',
                data: $('#inspectionForm').serialize(), // Send all form data
                success: function (response) {
                    if (response === "success") {
                        Swal.fire({
                            title: 'Submitted!',
                            text: 'Inspection submitted successfully.',
                            icon: 'success'
                        }).then(() => {
                            // Redirect to inspector dashboard
                            window.location.href = 'inspectordashboard.php';
                        });
                    } else {
                        Swal.fire({
                            title: 'Success',
                            text: 'Inspection submitted successfully..',
                            icon: 'success'
                        }).then(() => {
                            // Redirect to inspector dashboard
                            window.location.href = 'inspectordashboard.php';
                        });
                    }
                },
                error: function () {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Failed to connect to the server. Please try again later.',
                        icon: 'error'
                    });
                }
            });
        }
    });
});