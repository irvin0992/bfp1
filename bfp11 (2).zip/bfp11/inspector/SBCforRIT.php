<?php
// Include session validation, header, sidebar, and connection files
include('../session_validate.php');
include('../header/header2.php');
include('../sidebar/sidebarinspector.php');
include('../connection.php');

// Retrieve inspection_id from URL parameter
$inspectionId = isset($_GET['inspection_id']) ? intval($_GET['inspection_id']) : 0;

if ($inspectionId === 0) {
    die('Inspection ID is required.');
}

$query = "
    SELECT 
        bd.building_name,
        b.district,
        b.barangay,
        b.business_name,
        b.occupancy_type,
        o.owner_name,
        o.contact_number,
        b.business_nature,
        i.status,
        a.order_no,          -- Inspection Order No from tbl_reference
        a.date_issued,       -- Date Issued from tbl_reference
        a.date_inspected, 
        a.inspection_type,
        a.others,
        c.policy_number,
        c.pol_date_issued,
        c.fsic_number,
        c.fsic_date_issued,
        c.fsec_number,
        c.fsec_date_issued,
        c.building_permit,
        c.rp_date_issued,
        c.bpermit_number,
        c.bp_date_issued,
        d.construction_type,
        d.floor_area,
        d.occupant_load,
        d.building_height,
        d.Stories_num,
        d.Portion_Occupied,
        d.mezzanine_type,
        d.Handrails_type,
        e.doors_dim,
        e.doors_status,
        e.corridor_dim,
        e.corridor_status,
        e.exitsdoors_dim,
        e.exitsdoors_status,
        e.stairs_dim,
        e.stairs_status,
        e.horizontalexit_dim,
        e.horizontalexit_status,
        e.MLH_status,
        e.EED_status,
        e.ESPI_status,
        e.remarks,
        f.hazard_classification,
        f.storage_clearance,
        f.FS_clearance,
        f.fsdate_issued,
        f.control_num,
        f.hazard_content,
        f.total_volume,
        f.location,
        f.CC_status,
        f.GDD_status,
        f.LPG,
        f.ins_clearance,
        f.isndate_issued,
        f.inscontrol_num,
        f.ssmc,
        f.NSS,
        f.remarks,
        g.fire_extinguisher_size,
        g.minimum_number_extinguisher,
        g.location_status,
        g.seals_tags,
        g.markings,
        g.condition_status,
        g.pressure,
        g.remarks,
        g.type,
        g.quantity,
        g.capacity,
        g.ELS_provided,
        g.ELS_functional,
        g.ELS_Locations,
        g.ELS_others,
        g.FDA_provided,
        g.FDA_functional,
        g.UPF,
        g.FDA_adequate,
        g.LCP
    FROM tbl_inspections i
    INNER JOIN tbl_applications r ON i.application_id = r.application_id
    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
    INNER JOIN tbl_buildings bd ON r.building_id = bd.building_id
    INNER JOIN tbl_reference a ON i.inspection_id = a.inspection_id -- Joining with tbl_reference
    INNER JOIN tbl_business_details c ON i.inspection_id = c.inspection_id
    INNER JOIN tbl_building_details d ON i.inspection_id = d.inspection_id
    INNER JOIN tbl_means_of_egress e ON i.inspection_id = e.inspection_id
    INNER JOIN tbl_hazards f ON i.inspection_id = f.inspection_id
    INNER JOIN tbl_fire_protection g ON i.inspection_id = g.inspection_id
    WHERE i.inspection_id = ? AND i.status = 'Ready For Reinspection'
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("i", $inspectionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('No data found for inspection ID: ' . $inspectionId);
}

$row = $result->fetch_assoc();

// Assign retrieved values to variables
$buildingName = $row['building_name'];
$businessAddress = $row['district'] . ', ' . $row['barangay'];
$businessName = $row['business_name'];
$occupancyType = $row['occupancy_type'];
$ownerName = $row['owner_name'];
$contactNumber = $row['contact_number'];
$businessNature = $row['business_nature'];
$status = $row['status']; // Fetch the status

// Generate FSIC number and FSEC number


$orderNo = $row['order_no'];
$dateIssued = $row['date_issued'];
$dateInspected = $row['date_inspected'];
$inspectionTypes = explode(',', $row['inspection_type']);

$policyNumber = $row['policy_number'];
$polDateIssued = $row['pol_date_issued'];
$fsicNumber = $row['fsic_number'];
$fsicDateIssued = $row['fsic_date_issued'];
$fsecNumber = $row['fsec_number'];
$fsecDateIssued = $row['fsec_date_issued'];
$buildingPermit = $row['building_permit'];
$rpDateIssued = $row['rp_date_issued'];
$bPermitNumber = $row['bpermit_number'];
$bPDateIssued = $row['bp_date_issued'];
$constructionTypes = explode(',', $row['construction_type']);
$floorArea = $row['floor_area'];
$occupantLoad = $row['occupant_load'];
$buildingHeight = $row['building_height'];
$storiesNum = $row['Stories_num'];
$portionOccupied = $row['Portion_Occupied'];
$mezzanineType = explode(',', $row['mezzanine_type']);
$handrailsType = explode(',', $row['Handrails_type']);

$doorsDim = $row['doors_dim'];
$doorsStatus = $row['doors_status'];
$corridorDim = $row['corridor_dim'];
$corridorStatus = $row['corridor_status'];
$exitsdoorsDim = $row['exitsdoors_dim'];
$exitsdoorsStatus = $row['exitsdoors_status'];
$stairsDim = $row['stairs_dim'];
$stairsStatus = $row['stairs_status'];
$horizontalexitDim = $row['horizontalexit_dim'];
$horizontalexitStatus = $row['horizontalexit_status'];
$MLHStatus = $row['MLH_status'];
$EEDStatus = $row['EED_status'];
$ESPIStatus = $row['ESPI_status'];
$remarks = $row['remarks'];

$hazardClassification = explode(',', $row['hazard_classification']);
$storageClearance = explode(',', $row['storage_clearance']);
$FSClearance = explode(',', $row['FS_clearance']);
$FSDateIssued = $row['fsdate_issued'];
$controlNum = $row['control_num'];
$hazardContent = $row['hazard_content'];
$totalVolume = $row['total_volume'];
$location = $row['location'];
$CCStatus = explode(',', $row['CC_status']);
$GDDStatus = explode(',', $row['GDD_status']);
$LPG = explode(',', $row['LPG']);
$insClearance = explode(',', $row['ins_clearance']);
$insDateIssued = $row['isndate_issued'];
$insControlNum = $row['inscontrol_num'];
$SSMC = explode(',', $row['ssmc']);
$NSS = explode(',', $row['NSS']);
$remarks = $row['remarks'];

$fireExtinguisherSize = explode(',', $row['fire_extinguisher_size']);
$minimumNumberExtinguisher = explode(',', $row['minimum_number_extinguisher']);
$locationStatus = explode(',', $row['location_status']);
$sealsTags = explode(',', $row['seals_tags']);
$markings = explode(',', $row['markings']);
$conditionStatus = explode(',', $row['condition_status']);
$pressure = explode(',', $row['pressure']);
$remarks = $row['remarks'];
$type = $row['type'];
$quantity = $row['quantity'];
$capacity = $row['capacity'];
$ELSProvided = explode(',', $row['ELS_provided']);
$ELSFunctional = explode(',', $row['ELS_functional']);
$ELSLocations = explode(',', $row['ELS_Locations']);
$ELSOthers = $row['ELS_others'];
$FDAProvided = explode(',', $row['FDA_provided']);
$FDAFunctional = explode(',', $row['FDA_functional']);
$UPF = $row['UPF'];
$FDAAdequate = explode(',', $row['FDA_adequate']);
$LCP = $row['LCP'];



$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Small Business Inspection Checklist</title>
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <style>
        input[type="radio"] {
            display: inline-block;
            margin: 0;
        }
    </style>

</head>

<body>
    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <h5 class="card-header">Small Business Inspection Checklist</h5>
                        <div class="card-body">
                            <form id="inspectionForm" method="POST">
                                <input type="hidden" name="inspection_id" value="<?php echo $inspectionId; ?>">
                                <input type="hidden" id="inspectionStatus"
                                    value="<?php echo htmlspecialchars($status); ?>">
                                <!-- General Information Section -->

                                <div id="section1">
                                    <!-- I. REFERENCE -->
                                    <div class="section">
                                        <h2>I. REFERENCE</h2><br>
                                        <!-- Pre-fill the fetched values from tbl_reference -->
                                        <label for="order_no">Inspection Order No:</label>
                                        <input type="text" style="margin-right: 110px;" id="order_no" name="order_no"
                                            value="<?php echo htmlspecialchars($orderNo); ?>" readonly><br>

                                        <label for="date_issued">Date Issued:</label>
                                        <input type="date" style="margin-right: 110px;" id="date_issued"
                                            name="date_issued" value="<?php echo htmlspecialchars($dateIssued); ?>"
                                            readonly><br>

                                        <label for="date_inspected">Date Inspected:</label>
                                        <input type="date" style="margin-right: 110px;" id="date_inspected"
                                            name="date_inspected"
                                            value="<?php echo htmlspecialchars($dateInspected); ?>" readonly><br>
                                    </div>
                                    <!-- II. NATURE OF INSPECTION CONDUCTED -->
                                    <div class="section">
                                        <h2>II. NATURE OF INSPECTION CONDUCTED</h2><br>

                                        <!-- Pre-select inspection types based on fetched data -->
                                        <input type="radio" name="inspection_type[]" value="construction"
                                            id="construction" class="single-checkbox" <?php echo in_array('construction', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="construction">Inspection during construction</label>

                                        <input type="radio" style="margin-left: 120px;" name="inspection_type[]"
                                            value="PEZA" id="PEZA" class="single-checkbox" <?php echo in_array('PEZA', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="PEZA">FSIC for Certificate of Annual Inspection (PEZA)</label><br>

                                        <input type="radio" name="inspection_type[]" value="fsic_occupancy" <?php echo in_array('fsic_occupancy', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="fsic_occupancy" id="fsic_occupancy" class="single-checkbox">FSIC for
                                            Certificate for Occupancy</label>

                                        <input type="radio" style="margin-left: 110px;" name="inspection_type[]"
                                            value="verification" id="verification" class="single-checkbox" <?php echo in_array('verification', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="verification">Verification Inspection for Compliance</label><br>

                                        <input type="radio" name="inspection_type[]" value="fsic_new" id="fsic_new"
                                            class="single-checkbox" <?php echo in_array('fsic_new', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="fsic_new">FSIC for Business Permit (New)</label>

                                        <input type="radio" style="margin-left: 120px;" name="inspection_type[]"
                                            value="ntc" id="ntc" class="single-checkbox" <?php echo in_array('ntc', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="ntc">NTC</label>

                                        <input type="radio" name="inspection_type[]" value="ntcv" id="ntcv"
                                            class="single-checkbox" <?php echo in_array('ntcv', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="ntcv">NTCV</label>

                                        <input type="radio" name="inspection_type[]" value="abatement" id="abatement"
                                            class="single-checkbox" <?php echo in_array('abatement', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="abatement">Abatement</label>

                                        <input type="radio" name="inspection_type[]" value="closure" id="closure"
                                            class="single-checkbox" <?php echo in_array('closure', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="closure">Closure</label><br>

                                        <input type="radio" name="inspection_type[]" value="fsic_renewal" <?php echo in_array('fsic_renewal', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="fsic_renewal" id="fsic_renewal" class="single-checkbox">FSIC for
                                            Business Permit (Renewal)</label>

                                        <input type="radio" style="margin-left: 105px;" name="inspection_type[]"
                                            value="disapproval" id="disapproval" class="single-checkbox" <?php echo in_array('disapproval', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="disapproval">Notice of Disapproval, if Certificate of
                                            Occupancy</label><br>

                                        <input type="radio" style="margin-left: 350px;" name="inspection_type[]"
                                            value="others" <?php echo in_array('others', $inspectionTypes) ? 'checked' : ''; ?> disabled>
                                        Others (Specify):
                                        <input type="text" name="others"
                                            value="<?php echo in_array('others', $inspectionTypes) ? htmlspecialchars($row['others_value']) : ''; ?>"
                                            disabled><br><br>
                                    </div>
                                    <button type="button" onclick="nextSection(2)" class="btn btn-primary">Next</button>
                                </div>

                                <div id="section2" style="display:none;">
                                    <div class="section">
                                        <h2>III. GENERAL INFORMATION</h2>
                                        <br>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="business_name">Business Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_name"
                                                    value="<?php echo htmlspecialchars($businessName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="building_name">Building Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="building_name"
                                                    value="<?php echo htmlspecialchars($buildingName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="district">Business Address:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_address"
                                                    value="<?php echo htmlspecialchars($businessAddress); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="owner_name">Owner Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="owner_name"
                                                    value="<?php echo htmlspecialchars($ownerName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="contact_number">Contact Number:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="contact_number"
                                                    value="<?php echo htmlspecialchars($contactNumber); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="business_nature">Business Nature:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_nature"
                                                    value="<?php echo htmlspecialchars($businessNature); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="policy_number">Fire Insurance Policy No:</label>
                                                <input type="text" class="form-control" id="policy_number"
                                                    name="policy_number"
                                                    value="<?php echo htmlspecialchars($policyNumber); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="pol_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="pol_date_issued"
                                                    name="pol_date_issued"
                                                    value="<?php echo htmlspecialchars($polDateIssued); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="fsic_number">FSIC No:</label>
                                                <input type="text" class="form-control" id="fsic_number"
                                                    name="fsic_number"
                                                    value="<?php echo htmlspecialchars($fsicNumber); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="fsic_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="fsic_date_issued"
                                                    name="fsic_date_issued"
                                                    value="<?php echo htmlspecialchars($fsicDateIssued); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="fsec_number">FSEC No:</label>
                                                <input type="text" class="form-control" id="fsec_number"
                                                    name="fsec_number"
                                                    value="<?php echo htmlspecialchars($fsecNumber); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="fsec_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="fsec_date_issued"
                                                    name="fsec_date_issued"
                                                    value="<?php echo htmlspecialchars($fsecDateIssued); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="building_permit">Building/Renovation Permit:</label>
                                                <input type="text" class="form-control" id="building_permit"
                                                    name="building_permit"
                                                    value="<?php echo htmlspecialchars($buildingPermit); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="rp_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="rp_date_issued"
                                                    name="rp_date_issued"
                                                    value="<?php echo htmlspecialchars($rpDateIssued); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="bpermit_number">Business Permit No:</label>
                                                <input type="text" class="form-control" id="bpermit_number"
                                                    name="bpermit_number"
                                                    value="<?php echo htmlspecialchars($bPermitNumber); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="bp_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="bp_date_issued"
                                                    name="bp_date_issued"
                                                    value="<?php echo htmlspecialchars($bPDateIssued); ?>" readonly>
                                            </div>
                                        </div>

                                        <button type="button" onclick="nextSection(1)"
                                            class="btn btn-secondary">Previous</button>
                                        <button type="button" onclick="nextSection(3)"
                                            class="btn btn-primary">Next</button>
                                    </div>
                                </div>


                                <div id="section3" style="display:none;">
                                    <div class="section">
                                        <h2>IV. OTHER INFORMATION</h2>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="occupancy_type">Occupancy Type:</label>
                                            </div>
                                            <div class=>
                                                <input type="text" class="form-control" name="occupancy_type"
                                                    value="<?php echo htmlspecialchars($occupancyType); ?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="section">
                                        <label for="construction_type" style="margin-right: 80px;">Construction
                                            Type:</label>
                                        <input type="radio" name="construction_type[]" value="timber" id="timber"
                                            class="single-checkbox" <?php echo in_array('timber', $constructionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="timber" style="margin-right: 100px;">Timber Framed and
                                            Walls</label>
                                        <input type="radio" name="construction_type[]" value="reinforced_concrete"
                                            id="reinforced_concrete" class="single-checkbox" <?php echo in_array('reinforced_concrete', $constructionTypes) ? 'checked' : ''; ?>
                                            disabled>Reinforced Concrete Framed with Masonry Walls
                                        <br>
                                        <input type="radio" style="margin-left: 205px;" name="construction_type[]"
                                            value="steel" id="steel" class="single-checkbox" <?php echo in_array('steel', $constructionTypes) ? 'checked' : ''; ?> disabled>
                                        <label for="steel" style="margin-right: 110px;">Steel
                                            Framed
                                            and Walls</label>
                                        <input type="radio" name="construction_type[]" value="mixed_construction"
                                            id="mixed_construction" class="single-checkbox" <?php echo in_array('mixed_constructions', $constructionTypes) ? 'checked' : ''; ?>
                                            disabled>
                                        Mixed Construction<br><br>
                                    </div>


                                    <div class="section">
                                        <label for="floor_area">Total Floor Area:</label>
                                        <input type="text" id="floor_area" name="floor_area"
                                            value="<?php echo htmlspecialchars($floorArea); ?>" readonly> m²

                                        <label for="occupant_load" style="margin-left: 110px;">Occupant Load:</label>
                                        <input type="number" id="occupant_load" name="occupant_load"
                                            value="<?php echo htmlspecialchars($occupantLoad); ?>" readonly><br>

                                        <label for="building_height">Building Height:</label>
                                        <input type="number" id="building_height" name="building_height"
                                            value="<?php echo htmlspecialchars($buildingHeight); ?>" readonly>
                                        m

                                        <label for="Stories_num" style="margin-left: 110px; ">No of Stories:</label>
                                        <input type="number" id="Stories_num" name="Stories_num"
                                            value="<?php echo htmlspecialchars($storiesNum); ?>" readonly><br><br>

                                        <label for="Portion_Occupied">Portion Occupied:</label>
                                        <input type="number" id="Portion_Occupied:" name="Portion_Occupied"
                                            value="<?php echo htmlspecialchars($portionOccupied); ?>" readonly>
                                        m

                                        <label for="mezzanine" style="margin-left: 110px; ">With Mezzanine:</label>
                                        <input type="radio" name="mezzanine_type[]" value="yes" id="yes"
                                            class="single-checkbox" <?php echo in_array('yes', $mezzanineType) ? 'checked' : ''; ?> disabled> Yes /
                                        <input type="radio" name="mezzanine_type[]" value="no" id="no"
                                            class="single-checkbox" <?php echo in_array('no', $mezzanineType) ? 'checked' : ''; ?> disabled> No

                                        <label for="Handrails" style="margin-left: 110px; ">Handrails/Raillings
                                            Provided:</label>
                                        <input type="radio" name="Handrails_type[]" value="yes" id="yes"
                                            class="single-checkbox" <?php echo in_array('yes', $handrailsType) ? 'checked' : ''; ?> disabled> Yes /
                                        <input type="radio" name="Handrails_type[]" value="no" id="no"
                                            class="single-checkbox" <?php echo in_array('no', $handrailsType) ? 'checked' : ''; ?> disabled> No<br><br>

                                        <button type="button" onclick="nextSection(2)"
                                            class="btn btn-secondary">Previous</button>
                                        <button type="button" onclick="nextSection(4)"
                                            class="btn btn-primary">Next</button>
                                    </div>
                                </div>

                                <!-- Means of Egress Section -->
                                <div id="section4" style="display:none;">
                                    <h2>V. Means of Egress Section </h2>
                                    <th colspan="4">A. EXIT ACCESS</th>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Horizontal components</th>
                                            <th>Actual Dim.</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>

                                        <tr>
                                            <td>Doors</td>
                                            <td><input type="text" class="form-control" name="doorsDim" id="doorsDim"
                                                    value="<?php echo htmlspecialchars($doorsDim); ?>" readonly></td>
                                            <td><input type="radio" name="doors" value="passed" <?php echo ($doorsStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="doors" value="failed" <?php echo ($doorsStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($doorsStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Corridors/ Hallways</td>
                                            <td><input type="text" class="form-control" name="corridorDim"
                                                    id="corridorDim"
                                                    value="<?php echo htmlspecialchars($corridorDim); ?>" readonly></td>
                                            <td><input type="radio" name="corri_hall" value="passed" <?php echo ($corridorStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="corri_hall" value="failed" <?php echo ($corridorStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($corridorStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>
                                    </table>

                                    <!-- B. EXITS -->
                                    <th colspan="4">B. EXITS</th>

                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Horizontal components</th>
                                            <th>Actual Dim.</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>

                                        <tr>
                                            <td>Exits Doors</td>
                                            <td><input type="text" class="form-control" name="exitsdoorsDim"
                                                    id="exitsdoorsDim"
                                                    value="<?php echo htmlspecialchars($exitsdoorsDim); ?>" readonly>
                                            </td>
                                            <td><input type="radio" name="exitsdoors" value="passed" <?php echo ($exitsdoorsStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="exitsdoors" value="failed" <?php echo ($exitsdoorsStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($exitsdoorsStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Stairs</td>
                                            <td><input type="text" class="form-control" name="stairsDim" id="stairsDim"
                                                    value="<?php echo htmlspecialchars($stairsDim); ?>" readonly></td>
                                            <td><input type="radio" name="stairs" value="passed" <?php echo ($stairsStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="stairs" value="failed" <?php echo ($stairsStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($stairsStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Horizontal Exits</td>
                                            <td><input type="text" class="form-control" name="horizontalexitDim"
                                                    id="horizontalexitDim"
                                                    value="<?php echo htmlspecialchars($horizontalexitDim); ?>"
                                                    readonly></td>
                                            <td><input type="radio" name="horizontalexit" value="passed" <?php echo ($horizontalexitStatus === 'passed') ? 'checked disabled' : ''; ?>>
                                            </td>
                                            <td><input type="radio" name="horizontalexit" value="failed" <?php echo ($horizontalexitStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($horizontalexitStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>
                                    </table>

                                    <!-- VI. SIGNS, LIGHTING, AND EXITS SIGNAGE -->
                                    <h2>VI. SIGNS, LIGHTING, AND EXITS SIGNAGE</h2>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Components</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>

                                        <tr>
                                            <td>Mininum letter height, 150mm; Width of Stroke, 19mm</td>
                                            <td><input type="radio" name="MLH" value="passed" <?php echo ($MLHStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="MLH" value="failed" <?php echo ($MLHStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($MLHStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>EXIT signs are posted along Exit access, Exits, and Exit discharge</td>
                                            <td><input type="radio" name="EED" value="passed" <?php echo ($EEDStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="EED" value="failed" <?php echo ($EEDStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($EEDStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>EXIT signs are properly illuminated.</td>
                                            <td><input type="radio" name="ESPI" value="passed" <?php echo ($ESPIStatus === 'passed') ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="ESPI" value="failed" <?php echo ($ESPIStatus === 'failed') ? 'checked' : ''; ?> <?php echo ($ESPIStatus === 'passed') ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr class="remarksSection" style="display: none;">
                                            <td>Remarks:</td>
                                            <td colspan="3"><textarea class="form-control" name="remarks" rows="3"
                                                    readonly><?php echo htmlspecialchars($remarks); ?></textarea></td>
                                        </tr>
                                    </table>

                                    <button type="button" onclick="nextSection(3)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(5)" class="btn btn-primary">Next</button>
                                </div>


                                <div id="section5" style="display:none;">


                                    <div class="section">
                                        <h2>VII. HAZARD</h2>
                                        <label for="hazard_classification">Hazard Classification:</label>
                                        <input type="radio" name="hazard_classification" value="low" <?php echo in_array('low', $hazardClassification) ? 'checked' : ''; ?> disabled> Low
                                        <input type="radio" name="hazard_classification" value="ordinary" <?php echo in_array('ordinary', $hazardClassification) ? 'checked' : ''; ?> disabled>
                                        Ordinary
                                        <input type="radio" name="hazard_classification" value="high" <?php echo in_array('high', $hazardClassification) ? 'checked' : ''; ?> disabled> High

                                        <label for="storage_clearance">Storage Clearance Required:</label>
                                        <input type="radio" name="storage_clearance" value="yes" <?php echo in_array('yes', $storageClearance) ? 'checked' : ''; ?>disabled> Yes
                                        <input type="radio" name="storage_clearance" value="no" <?php echo in_array('no', $storageClearance) ? 'checked' : ''; ?>disabled> No<br><br>

                                        <label for="FS_clearance">Fire Safety Clearance For Storage:</label>
                                        <input type="radio" name="FS_clearance" value="yes" <?php echo in_array('yes', $FSClearance) ? 'checked' : ''; ?> disabled> Yes
                                        <input type="radio" name="FS_clearance" value="no" <?php echo in_array('no', $FSClearance) ? 'checked' : ''; ?> disabled> No

                                        <label for="fsdate_issued">Date Issued:</label>
                                        <input type="date" id="fsdate_issued" name="fsdate_issued"
                                            value="<?php echo htmlspecialchars($FSDateIssued); ?>" readonly>

                                        <label for="control_num">Control No.</label>
                                        <input type="text" id="control_num" name="control_num"
                                            value=" <?php echo htmlspecialchars($controlNum); ?>" readonly><br><br>

                                        <label for="hazard_content">Hazard Content:</label>
                                        <input type="text" id="hazard_content" name="hazard_content"
                                            value=" <?php echo htmlspecialchars($hazardContent); ?>" readonly>

                                        <label for="total_volume">Total Volume:</label>
                                        <input type="text" id="total_volume" name="total_volume"
                                            value=" <?php echo htmlspecialchars($totalVolume); ?>" readonly><br><br>

                                        <label for="location">Location :</label>
                                        <input type="text" id="location" name="location"
                                            value="<?php echo htmlspecialchars($location); ?> " readonly><br><br>

                                        <th colspan="4">A. First Aid Fire Protection (Fire Extinguishers)</th>
                                        <br><br>

                                        <table class="table table-bordered">

                                            <tr>
                                                <th>Components</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                            </tr>
                                            <tr>

                                                <td>Clearance of stocks from the Ceiling
                                                </td>
                                                <td><input type="radio" name="CC" value="passed" <?php echo in_array('passed', $CCStatus) ? 'checked disabled' : ''; ?>>
                                                </td>
                                                <td><input type="radio" name="CC" value="failed" <?php echo in_array('failed', $CCStatus) ? 'checked' : ''; ?> <?php echo in_array('passed', $CCStatus) ? 'disabled' : ''; ?>></td>
                                            </tr>

                                            <tr>
                                                <td>Gas Detector and Shut Off Device for LPG</td>
                                                <td><input type="radio" name="GDD" value="passed" <?php echo in_array('passed', $GDDStatus) ? 'checked disabled' : ''; ?>>
                                                </td>
                                                <td><input type="radio" name="GDD" value="failed" <?php echo in_array('failed', $GDDStatus) ? 'checked' : ''; ?> <?php echo in_array('passed', $GDDStatus) ? 'disabled' : ''; ?>></td>
                                            </tr>
                                        </table>

                                        <label for="LPG">LPG Systems provided with Approved Plans, (if 300
                                            kgs.300GWC)</label>
                                        <input type="radio" name="LPG" value="yes" <?php echo in_array('yes', $LPG) ? 'checked' : ''; ?> disabled> Yes /
                                        <input type="radio" name="LPG" value="no" <?php echo in_array('no', $LPG) ? 'checked' : ''; ?> disabled> No<br><br>

                                        <label for="ins_clearance">Installation Clearance </label>
                                        <input type="radio" name="ins_clearance" value="yes" <?php echo in_array('yes', $insClearance) ? 'checked' : ''; ?> disabled> Yes
                                        <input type="radio" name="ins_clearance" value="no" <?php echo in_array('no', $insClearance) ? 'checked' : ''; ?> disabled> No

                                        <label for="isndate_issued">Date Issued:</label>
                                        <input type="date" id="isndate_issued" name="isndate_issued"
                                            value="<?php echo htmlspecialchars($insDateIssued); ?>" readonly>

                                        <label for="inscontrol_num">Control No.</label>
                                        <input type="text" id="inscontrol_num" name="inscontrol_num"
                                            value="<?php echo htmlspecialchars($insControlNum); ?>" readonly><br><br>

                                        <label for="ssmc">Stored in sealed metal Container</label>
                                        <input type="radio" name="ssmc" value="yes" <?php echo in_array('yes', $SSMC) ? 'checked' : ''; ?> disabled> Yes
                                        <input type="radio" name="ssmc" value="no" <?php echo in_array('no', $SSMC) ? 'checked' : ''; ?> disabled> No

                                        <label for="NSS">Provided with "NO SMOKING" sign? </label>
                                        <input type="radio" name="NSS" value="yes" <?php echo in_array('yes', $NSS) ? 'checked' : ''; ?> disabled> Yes
                                        <input type="radio" name="NSS" value="no" <?php echo in_array('no', $NSS) ? 'checked' : ''; ?> disabled> No

                                    </div>
                                    <button type="button" onclick="nextSection(4)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(6)" class="btn btn-primary">Next</button>
                                </div>

                                <div id="section6" style="display:none;">
                                    <h2>VIII. FIRE PROTECTION</h2>
                                    <th colspan="4">A. First Aid Fire Protection (Fire Extinguishers)</th>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Item to Inspect</th>
                                            <th>Identification</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                        <tr>
                                            <td>Fire Extinguisher Size</td>
                                            <td>Minimal sizes of fire extinguishers for the listed grades of hazards
                                                shall be provided on the basis of table 7 & 8 of RIRR of RA 9514.</td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="passed" <?php echo in_array('passed', $fireExtinguisherSize) ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="failed" <?php echo in_array('failed', $fireExtinguisherSize) ? 'checked' : ''; ?>
                                                    <?php echo in_array('passed', $fireExtinguisherSize) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Minimum number of Extinguisher</td>
                                            <td>The minimum number of extinguishers shall be sufficient to meet the
                                                requirements of table 7 & 8 of RIRR of RA 9514.</td>
                                            <td><input type="radio" name="minimum_number_extinguisher" value="passed"
                                                    <?php echo in_array('passed', $minimumNumberExtinguisher) ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="minimum_number_extinguisher" value="failed"
                                                    <?php echo in_array('failed', $minimumNumberExtinguisher) ? 'checked' : ''; ?> <?php echo in_array('passed', $minimumNumberExtinguisher) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Location</td>
                                            <td>All extinguishers are in their proper location.</td>
                                            <td><input type="radio" name="location_status" value="passed" <?php echo in_array('passed', $locationStatus) ? 'checked disabled' : ''; ?>>
                                            </td>
                                            <td><input type="radio" name="location_status" value="failed" <?php echo in_array('failed', $locationStatus) ? 'checked' : ''; ?> <?php echo in_array('passed', $locationStatus) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Seals & Tags</td>
                                            <td>Extinguisher seals and tags are intact and extinguisher was serviced in
                                                the last 12 months.</td>
                                            <td><input type="radio" name="seals_tags" value="passed" <?php echo in_array('passed', $sealsTags) ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="seals_tags" value="failed" <?php echo in_array('failed', $sealsTags) ? 'checked' : ''; ?> <?php echo in_array('passed', $sealsTags) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Markings</td>
                                            <td>Proper marking on extinguisher to indicate the type of fire the
                                                extinguisher can be used on.</td>
                                            <td><input type="radio" name="markings" value="passed" <?php echo in_array('passed', $markings) ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="markings" value="failed" <?php echo in_array('failed', $markings) ? 'checked' : ''; ?> <?php echo in_array('passed', $markings) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Condition</td>
                                            <td>No leaks, corrosion or other defects noticed.</td>
                                            <td><input type="radio" name="condition_status" value="passed" <?php echo in_array('passed', $conditionStatus) ? 'checked disabled' : ''; ?>>
                                            </td>
                                            <td><input type="radio" name="condition_status" value="failed" <?php echo in_array('failed', $conditionStatus) ? 'checked' : ''; ?> <?php echo in_array('passed', $conditionStatus) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr>
                                            <td>Pressure</td>
                                            <td>Pressure gauge arrow pointing in the “green” area indicating the
                                                extinguisher is fully charged.</td>
                                            <td><input type="radio" name="pressure" value="passed" <?php echo in_array('passed', $pressure) ? 'checked disabled' : ''; ?>></td>
                                            <td><input type="radio" name="pressure" value="failed" <?php echo in_array('failed', $pressure) ? 'checked' : ''; ?> <?php echo in_array('passed', $pressure) ? 'disabled' : ''; ?>></td>
                                        </tr>

                                        <tr id="remarksSection" style="display: none;">
                                            <td>Remarks:</td>
                                            <td colspan="3">
                                                <textarea class="form-control" name="remarks"
                                                    rows="3"><?php echo htmlspecialchars($remarks); ?></textarea>
                                            </td>
                                        </tr>

                                    </table>



                                    <label for="type">Type: </label>
                                    <input type="text" style="margin-right: 125px;" id="type" name="type"
                                        value="<?php echo htmlspecialchars($type); ?> " readonly>

                                    <label for="Quantity">Quantity: </label>
                                    <input type="text" style="margin-right: 125px;" id="Quantity" name="Quantity"
                                        value="<?php echo htmlspecialchars($quantity); ?> " readonly>

                                    <label for="Capacity">Capacity: </label>
                                    <input type="text" style="margin-right: 125px;" id="Capacity" name="Capacity"
                                        value="<?php echo htmlspecialchars($capacity); ?> " readonly><br>


                                    <th colspan="4">B. Emergency Light Systems</th>

                                    <label for="ELS_provided">Provided: </label>
                                    <input type="radio" name="ELS_provided" value="yes" <?php echo in_array('yes', $ELSProvided) ? 'checked' : ''; ?> disabled> Yes
                                    <input type="radio" name="ELS_provided" value="no" <?php echo in_array('no', $ELSProvided) ? 'checked' : ''; ?> disabled> No

                                    <label for="ELS_functional">Functional: </label>
                                    <input type="radio" name="ELS_functional" value="yes" <?php echo in_array('yes', $ELSFunctional) ? 'checked' : ''; ?> disabled> Yes
                                    <input type="radio" name="ELS_functional" value="no" <?php echo in_array('no', $ELSFunctional) ? 'checked' : ''; ?> disabled> No <br>

                                    <label for="ELS_Locations">Locations: </label>
                                    <input type="radio" name="ELS_Locations" value="low" <?php echo in_array('low', $ELSLocations) ? 'checked' : ''; ?> disabled> Hallways
                                    <input type="radio" name="ELS_Locations" value="ordinary" <?php echo in_array('ordinary', $ELSFunctional) ? 'checked' : ''; ?> disabled> Exits Doors
                                    <input type="radio" name="ELS_Locations" value="high" <?php echo in_array('high', $ELSFunctional) ? 'checked' : ''; ?> disabled> Stairways Landings
                                    <input type="text" name="ELS_others" placeholder="ELS_others (Specify)"
                                        value="<?php echo htmlspecialchars($ELSOthers); ?> " disabled>
                                    Others
                                    Specify <br>

                                    <th colspan="4">C. Fire detection and alarm</th>

                                    <label for="FDA_provided">Provided: </label>
                                    <input type="radio" name="FDA_provided" value="yes" <?php echo in_array('yes', $FDAProvided) ? 'checked' : ''; ?> disabled> Yes /
                                    <input type="radio" name="FDA_provided" value="no" <?php echo in_array('no', $FDAProvided) ? 'checked' : ''; ?> disabled> No
                                    <input type="radio" name="FDA_provided" value="smoke" <?php echo in_array('smoke', $FDAProvided) ? 'checked' : ''; ?> disabled> Smoke
                                    <input type="radio" name="FDA_provided" value="heat" <?php echo in_array('heat', $FDAProvided) ? 'checked' : ''; ?> disabled> Heat
                                    <input type="radio" name="FDA_provided" value="manual" <?php echo in_array('manual', $FDAProvided) ? 'checked' : ''; ?> disabled> Manual /
                                    <input type="radio" name="FDA_provided" value="automatic" <?php echo in_array('automatic', $FDAProvided) ? 'checked' : ''; ?> disabled> Automatic<br>


                                    <label for="FDA_functional">Functional: </label>
                                    <input type="radio" name="FDA_functional" value="yes" <?php echo in_array('yes', $FDAFunctional) ? 'checked' : ''; ?> disabled> Yes
                                    <input type="radio" name="FDA_functional" value="no" <?php echo in_array('no', $FDAFunctional) ? 'checked' : ''; ?> disabled> No

                                    <label for="UPF">Unit per floor:</label>
                                    <input type="text" id="UPF" name="UPF"
                                        value="<?php echo htmlspecialchars($UPF); ?> " disabled>

                                    <label for="FDA_adequate">Adequate: </label>
                                    <input type="radio" name="FDA_adequate" value="yes" <?php echo in_array('yes', $FDAAdequate) ? 'checked' : ''; ?> disabled> Yes /
                                    <input type="radio" name="FDA_adequate" value="no" <?php echo in_array('no', $FDAAdequate) ? 'checked' : ''; ?> disabled> No <br>

                                    <label for="LCP">Location of Control Panel( is Applicable):</label>
                                    <input type="text" id="LCP" name="LCP"
                                        value="<?php echo htmlspecialchars($LCP); ?> " readonly><br><br>


                                    <button type="button" onclick="nextSection(5)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                <br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Optional JavaScript -->
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="submitSmall.js"></script>

        <script>
            // Handle checkbox change event
            $('input.failed').change(function () {
                var isAnyFailedChecked = $('input.failed:checked').length > 0;
                $('#remarksSection').toggle(isAnyFailedChecked);
            });

            // Handle the section navigation logic
            $(document).ready(function () {
                window.nextSection = function (section) {
                    // Hide all sections
                    $('[id^=section]').hide();
                    // Show the selected section
                    $('#section' + section).show();
                };

                // Get all tables and attach event listeners to "failed" radio buttons
                const tables = document.querySelectorAll('table');

                tables.forEach(table => {
                    const failedRadios = table.querySelectorAll('input[type="radio"][value="failed"]');

                    // Add event listeners to each "failed" radio button
                    failedRadios.forEach(radio => {
                        radio.addEventListener('change', () => {
                            // Check if any "failed" radio is checked within this table
                            const isFailed = Array.from(failedRadios).some(r => r.checked);

                            // Show or hide the remarks section based on the result
                            table.querySelector('.remarksSection').style.display = isFailed ? "table-row" : "none";
                        });
                    });
                });
            });
        </script>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
</body>

</html>