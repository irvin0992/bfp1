$('#inspectionForm').on('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission

    Swal.fire({
        title: 'Confirm Submission',
        text: "Are you sure you want to submit this inspection?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, submit it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Proceed with the AJAX submission if confirmed
            $.ajax({
                url: 'submit-inspection.php', // Your PHP handler URL
                type: 'POST',
                data: new FormData(this),
                processData: false,
                contentType: false,
                dataType: 'json', // Expect a JSON response from the server
                success: function (response) {
                    if (response.status === "success") {
                        Swal.fire({
                            title: 'Success',
                            text: 'Inspection submitted successfully.',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            window.location.reload(); // Reload the page after success
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message || 'There was an error submitting the inspection.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function (xhr, status, error) {
                    Swal.fire({
                        title: 'Success',
                        text: 'Inspection submitted successfully.',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'Inspectordashboard.php';// Reload the page after success
                    });
                    console.error(xhr.responseText); // Log the detailed error message to the console
                }
            });
        }
    });
});
