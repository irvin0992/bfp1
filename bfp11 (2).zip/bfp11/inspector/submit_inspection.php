<?php
// Include session validation and connection files
include('../session_validate.php');
include('../connection.php');

require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to sanitize input data
function sanitize($input)
{
    return htmlspecialchars(trim($input));
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize data from POST array
    $inspectionId = sanitize($_POST['inspection_id']);

    // Validate if the inspection_id exists in the database
    $checkInspectionQuery = "SELECT inspection_id, application_id FROM tbl_inspections WHERE inspection_id = ?";
    $checkInspectionStmt = $conn->prepare($checkInspectionQuery);
    if (!$checkInspectionStmt) {
        echo json_encode(['status' => 'error', 'message' => 'SQL Error: ' . $conn->error]);
        exit;
    }
    $checkInspectionStmt->bind_param("i", $inspectionId);
    $checkInspectionStmt->execute();
    $result = $checkInspectionStmt->get_result();

    if ($result->num_rows == 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid inspection ID']);
        exit;
    }
}
    $row = $result->fetch_assoc();
    $application_id = $row['application_id'];  // Assuming tbl_inspections has application_id

    // Fetch the applicant email from tbl_applications using the application_id
    $sql_email = "SELECT email FROM tbl_applications WHERE application_id = ?";
    $stmt_email = $conn->prepare($sql_email);
    $stmt_email->bind_param("i", $application_id);
    $stmt_email->execute();
    $result_email = $stmt_email->get_result();

    if ($result_email->num_rows > 0) {
        $row_email = $result_email->fetch_assoc();
        $applicantEmail = $row_email['email'];  // Fetch the applicant's email
        $inspection_failed = false;
        $insert_success = true; // Assume success until proven otherwise
    
  // Collect and insert into tbl_binspection_references
$orderNo = sanitize($_POST['order_no']);
$dateIssued = sanitize($_POST['date_issued']);
$dateInspected = sanitize($_POST['date_inspected']);
$inspectionType = isset($_POST['inspection_type']) ? sanitize(implode(", ", $_POST['inspection_type'])) : "";
$otherInspectionType = sanitize($_POST['others']);
$occufsic = isset($_POST['occufsic']) && $_POST['occufsic'] == 'occufsic' ? 1 : 0;
$fsscr = isset($_POST['FSCCR']) && $_POST['FSCCR'] == 'yes' ? 1 : 0;
$fsscrApplicable = isset($_POST['FSCCR']) && $_POST['FSCCR'] == 'yes' ? 1 : 0;
$nraOfsec = isset($_POST['NRAOfsec']) && $_POST['NRAOfsec'] == 'NRAOfsec' ? 1 : 0;
$fsmr = isset($_POST['FSMR']) && $_POST['FSMR'] == 'yes' ? 1 : 0;
$fsmrApplicable = isset($_POST['FSMR']) && $_POST['FSMR'] == 'yes' ? 1 : 0;

// Prepare the SQL query
$sql = "INSERT INTO tbl_binspection_references (
            inspection_id, order_no, date_issued, date_inspected, inspection_type, other_inspection_type,
            occufsic, fsscr, fsscr_applicable, nra_ofsec, fsmr, fsmr_applicable
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            order_no = VALUES(order_no),
            date_issued = VALUES(date_issued),
            date_inspected = VALUES(date_inspected),
            inspection_type = VALUES(inspection_type),
            other_inspection_type = VALUES(other_inspection_type),
            occufsic = VALUES(occufsic),
            fsscr = VALUES(fsscr),
            fsscr_applicable = VALUES(fsscr_applicable),
            nra_ofsec = VALUES(nra_ofsec),
            fsmr = VALUES(fsmr),
            fsmr_applicable = VALUES(fsmr_applicable)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

    // Bind parameters to the SQL query
    $stmt->bind_param(
        "isssssiiiiii",
        $inspectionId ,
        $orderNo,
        $dateIssued,
        $dateInspected,
        $inspectionType,
        $otherInspectionType,
        $occufsic,
        $fsscr,
        $fsscrApplicable,
        $nraOfsec,
        $fsmr,
        $fsmrApplicable
    );

    if (!$stmt->execute()) {
        echo "Error inserting into tbl_binspection_references: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }

$stmt->close();

  // Retrieve and sanitize POST data from Section 2
$businessName = sanitize($_POST['business_name']);
$buildingName = sanitize($_POST['building_name']);
$businessAddress = sanitize($_POST['business_address']);
$occupancyType = sanitize($_POST['occupancy_type']);
$ownerName = sanitize($_POST['owner_name']);
$contactNumber = sanitize($_POST['contact_number']);
$businessNature = sanitize($_POST['business_nature']);
$GIoccufsic = isset($_POST['GIoccufsic']) ? sanitize($_POST['GIoccufsic']) : '';
$fsecNumber = sanitize($_POST['fsec_number']);
$fsecDateIssued = sanitize($_POST['fsec_date_issued']);
$buildingPermitNumber = sanitize($_POST['bpermit_number']);
$bpDateIssued = sanitize($_POST['bp_date_issued']);
$GINRAOfsec = isset($_POST['GINRAOfsec']) ? sanitize($_POST['GINRAOfsec']) : '';
$fsicNumber = sanitize($_POST['fsic_number']);
$fsicDateIssued = sanitize($_POST['fsic_date_issued']);
$certificateFireDrill = sanitize($_POST['CFD']);
$CFDDateIssued = sanitize($_POST['CFD_date_issued']);
$buildingRenovationPermit = sanitize($_POST['building_permit']);
$rpDateIssued = sanitize($_POST['rp_date_issued']);
$fireInsurancePolicyNumber = sanitize($_POST['policy_number']);
$policyDateIssued = sanitize($_POST['pol_date_issued']);

// Prepare the SQL query for general information
$sql = "INSERT INTO tbl_bgeneral_information (
           inspection_id, business_name, building_name, business_address, occupancy_type, owner_name, 
           contact_number, business_nature, GIoccufsic, fsec_number, fsec_date_issued, building_permit_number, 
           bp_date_issued, GINRAOfsec, fsic_number, fsic_date_issued, certificate_fire_drill, CFD_date_issued, 
           building_renovation_permit, rp_date_issued, fire_insurance_policy_number, policy_date_issued
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE 
           business_name = VALUES(business_name),
           building_name = VALUES(building_name),
           business_address = VALUES(business_address),
           occupancy_type = VALUES(occupancy_type),
           owner_name = VALUES(owner_name),
           contact_number = VALUES(contact_number),
           business_nature = VALUES(business_nature),
           GIoccufsic = VALUES(GIoccufsic),
           fsec_number = VALUES(fsec_number),
           fsec_date_issued = VALUES(fsec_date_issued),
           building_permit_number = VALUES(building_permit_number),
           bp_date_issued = VALUES(bp_date_issued),
           GINRAOfsec = VALUES(GINRAOfsec),
           fsic_number = VALUES(fsic_number),
           fsic_date_issued = VALUES(fsic_date_issued),
           certificate_fire_drill = VALUES(certificate_fire_drill),
           CFD_date_issued = VALUES(CFD_date_issued),
           building_renovation_permit = VALUES(building_renovation_permit),
           rp_date_issued = VALUES(rp_date_issued),
           fire_insurance_policy_number = VALUES(fire_insurance_policy_number),
           policy_date_issued = VALUES(policy_date_issued)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "isssssssssssssssssssss",
    $inspectionId, $businessName, $buildingName, $businessAddress, $occupancyType, $ownerName, 
    $contactNumber, $businessNature, $GIoccufsic, $fsecNumber, $fsecDateIssued, $buildingPermitNumber, 
    $bpDateIssued, $GINRAOfsec, $fsicNumber, $fsicDateIssued, $certificateFireDrill, $CFDDateIssued, 
    $buildingRenovationPermit, $rpDateIssued, $fireInsurancePolicyNumber, $policyDateIssued
);

if (!$stmt->execute()) {
    echo "Error inserting into tbl_bgeneral_information: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();
// Sanitize and retrieve form values for the new table
$construction_type = isset($_POST['construction_type']) ? sanitize($_POST['construction_type'][0]) : '';
$wall_type = isset($_POST['Wall_type']) ? sanitize($_POST['Wall_type'][0]) : '';
$floor_type = isset($_POST['Floor_type']) ? sanitize($_POST['Floor_type'][0]) : '';
$basement_usage = sanitize($_POST['Basement']);
$ground_floor_usage = sanitize($_POST['Ground_Floor']);
$second_floor_usage = sanitize($_POST['Second_Floor']);
$third_floor_usage = sanitize($_POST['Third_Floor']);
$nth_floor_usage = sanitize($_POST['Nth_Floor']);
$occupant_load = (int) $_POST['occupant_load'];
$stories_num = (int) $_POST['Stories_num'];
$building_height = (float) $_POST['building_height'];
$mezzanine_type = isset($_POST['mezzanine_type']) ? sanitize($_POST['mezzanine_type'][0]) : '';

// Prepare the SQL query for building details
$sql = "INSERT INTO tbl_bbuilding_details (
            inspection_id, construction_type, wall_type, floor_type, basement_usage, 
            ground_floor_usage, second_floor_usage, third_floor_usage, nth_floor_usage, 
            occupant_load, stories_num, building_height, mezzanine_type
        ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            construction_type = VALUES(construction_type),
            wall_type = VALUES(wall_type),
            floor_type = VALUES(floor_type),
            basement_usage = VALUES(basement_usage),
            ground_floor_usage = VALUES(ground_floor_usage),
            second_floor_usage = VALUES(second_floor_usage),
            third_floor_usage = VALUES(third_floor_usage),
            nth_floor_usage = VALUES(nth_floor_usage),
            occupant_load = VALUES(occupant_load),
            stories_num = VALUES(stories_num),
            building_height = VALUES(building_height),
            mezzanine_type = VALUES(mezzanine_type)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "issssssssssds",
    $inspectionId,
    $construction_type,
    $wall_type,
    $floor_type,
    $basement_usage,
    $ground_floor_usage,
    $second_floor_usage,
    $third_floor_usage,
    $nth_floor_usage,
    $occupant_load,
    $stories_num,
    $building_height,
    $mezzanine_type
);

if (!$stmt->execute()) {
    echo "Error inserting into tbl_bbuilding_details: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();

// Sanitize and retrieve POST data for the Horizontal Components Section
$GOC_type = isset($_POST['GOC_type']) ? sanitize($_POST['GOC_type'][0]) : '';

$doorsDimensions = sanitize($_POST['Doorsdimensions'][0]);
$doorsStatus = sanitize($_POST['Doors']);
$doorsRemarks = sanitize($_POST['Doorsremarks'][0]);

$corridorsDimensions = sanitize($_POST['CHdimensions'][0]);
$corridorsStatus = sanitize($_POST['CH']);
$corridorsRemarks = sanitize($_POST['CHremarks'][0]);

$passagewaysDimensions = sanitize($_POST['Passagewaysdimensions'][0]);
$passagewaysStatus = sanitize($_POST['Passageways']);
$passagewaysRemarks = sanitize($_POST['Passagewaysremarks'][0]);

$lobbyDimensions = sanitize($_POST['LAdimensions'][0]);
$lobbyStatus = sanitize($_POST['LA']);
$lobbyRemarks = sanitize($_POST['LAremarks'][0]);

$rampsDimensions = sanitize($_POST['Rampsdimensions'][0]);
$rampsStatus = sanitize($_POST['Ramps']);
$rampsRemarks = sanitize($_POST['Rampsremarks'][0]);

$commonPathDimensions = sanitize($_POST['CPTdimensions'][0]);
$commonPathStatus = sanitize($_POST['CPT']);
$commonPathRemarks = sanitize($_POST['CPTremarks'][0]);

$deadEndDimensions = sanitize($_POST['Deadenddimensions'][0]);
$deadEndStatus = sanitize($_POST['Deadend']);
$deadEndRemarks = sanitize($_POST['Deadendremarks'][0]);

$travelDistanceDimensions = sanitize($_POST['TDdimensions'][0]);
$travelDistanceStatus = sanitize($_POST['TD']);
$travelDistanceRemarks = sanitize($_POST['TDremarks'][0]);

// SQL query for inserting or updating horizontal components data
$sql = "INSERT INTO tbl_bhorizontal_components_summary (
            inspection_id, GOC_type,
            doors_dimensions, doors_status, doors_remarks,
            corridors_dimensions, corridors_status, corridors_remarks,
            passageways_dimensions, passageways_status, passageways_remarks,
            lobby_dimensions, lobby_status, lobby_remarks,
            ramps_dimensions, ramps_status, ramps_remarks,
            common_path_dimensions, common_path_status, common_path_remarks,
            dead_end_dimensions, dead_end_status, dead_end_remarks,
            travel_distance_dimensions, travel_distance_status, travel_distance_remarks
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            GOC_type = VALUES(GOC_type),
            doors_dimensions = VALUES(doors_dimensions),
            doors_status = VALUES(doors_status),
            doors_remarks = VALUES(doors_remarks),
            corridors_dimensions = VALUES(corridors_dimensions),
            corridors_status = VALUES(corridors_status),
            corridors_remarks = VALUES(corridors_remarks),
            passageways_dimensions = VALUES(passageways_dimensions),
            passageways_status = VALUES(passageways_status),
            passageways_remarks = VALUES(passageways_remarks),
            lobby_dimensions = VALUES(lobby_dimensions),
            lobby_status = VALUES(lobby_status),
            lobby_remarks = VALUES(lobby_remarks),
            ramps_dimensions = VALUES(ramps_dimensions),
            ramps_status = VALUES(ramps_status),
            ramps_remarks = VALUES(ramps_remarks),
            common_path_dimensions = VALUES(common_path_dimensions),
            common_path_status = VALUES(common_path_status),
            common_path_remarks = VALUES(common_path_remarks),
            dead_end_dimensions = VALUES(dead_end_dimensions),
            dead_end_status = VALUES(dead_end_status),
            dead_end_remarks = VALUES(dead_end_remarks),
            travel_distance_dimensions = VALUES(travel_distance_dimensions),
            travel_distance_status = VALUES(travel_distance_status),
            travel_distance_remarks = VALUES(travel_distance_remarks)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "isssssssssssssssssssssssss",
    $inspectionId,
    $GOC_type,
    $doorsDimensions,
    $doorsStatus,
    $doorsRemarks,
    $corridorsDimensions,
    $corridorsStatus,
    $corridorsRemarks,
    $passagewaysDimensions,
    $passagewaysStatus,
    $passagewaysRemarks,
    $lobbyDimensions,
    $lobbyStatus,
    $lobbyRemarks,
    $rampsDimensions,
    $rampsStatus,
    $rampsRemarks,
    $commonPathDimensions,
    $commonPathStatus,
    $commonPathRemarks,
    $deadEndDimensions,
    $deadEndStatus,
    $deadEndRemarks,
    $travelDistanceDimensions,
    $travelDistanceStatus,
    $travelDistanceRemarks
);

// Execute the statement
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bhorizontal_components_summary: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();



// Sanitize and retrieve POST data for the Exit Access Section
$EA1dimensions = sanitize($_POST['EA1dimensions'][0]);
$EA1status = isset($_POST['EA1']) ? sanitize($_POST['EA1']) : '';

$EA2dimensions = sanitize($_POST['EA2dimensions'][0]);
$EA2status = isset($_POST['EA2']) ? sanitize($_POST['EA2']) : '';

$EA3dimensions = sanitize($_POST['EA3dimensions'][0]);
$EA3status = isset($_POST['EA3']) ? sanitize($_POST['EA3']) : '';

$EA4dimensions = sanitize($_POST['EA4dimensions'][0]);
$EA4status = isset($_POST['EA4']) ? sanitize($_POST['EA4']) : '';

$EA5status = isset($_POST['EA5']) ? sanitize($_POST['EA5']) : '';
$EA6status = isset($_POST['EA6']) ? sanitize($_POST['EA6']) : '';
$EA7status = isset($_POST['EA7']) ? sanitize($_POST['EA7']) : '';
$EA8status = isset($_POST['EA8']) ? sanitize($_POST['EA8']) : '';

// SQL query for inserting or updating exit access requirements data
$sql = "INSERT INTO tbl_bexit_access_requirements (
            inspection_id,
            EA1_dimensions, EA1_status,
            EA2_dimensions, EA2_status,
            EA3_dimensions, EA3_status,
            EA4_dimensions, EA4_status,
            EA5_status,
            EA6_status,
            EA7_status,
            EA8_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            EA1_dimensions = VALUES(EA1_dimensions),
            EA1_status = VALUES(EA1_status),
            EA2_dimensions = VALUES(EA2_dimensions),
            EA2_status = VALUES(EA2_status),
            EA3_dimensions = VALUES(EA3_dimensions),
            EA3_status = VALUES(EA3_status),
            EA4_dimensions = VALUES(EA4_dimensions),
            EA4_status = VALUES(EA4_status),
            EA5_status = VALUES(EA5_status),
            EA6_status = VALUES(EA6_status),
            EA7_status = VALUES(EA7_status),
            EA8_status = VALUES(EA8_status)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "issssssssssss",
    $inspectionId,
    $EA1dimensions,
    $EA1status,
    $EA2dimensions,
    $EA2status,
    $EA3dimensions,
    $EA3status,
    $EA4dimensions,
    $EA4status,
    $EA5status,
    $EA6status,
    $EA7status,
    $EA8status
);

// Execute the statement
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bexit_access_requirements: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();




  // Retrieve and sanitize POST data for the Exits Section
$stairsType = isset($_POST['exits']) ? sanitize($_POST['exits'][0]) : '';
$stairsType1 = isset($_POST['exits1']) ? sanitize($_POST['exits1'][0]) : '';
$stairsType2 = isset($_POST['exits2']) ? sanitize($_POST['exits2'][0]) : '';
$stairsType3 = isset($_POST['exits3']) ? sanitize($_POST['exits3'][0]) : '';

$EDclearWidth = sanitize($_POST['EDclear_width'][0]);
$EDstatus = isset($_POST['ED']) ? sanitize($_POST['ED']) : '';

$NSclearWidth = sanitize($_POST['NSclear_width'][0]);
$NSstatus = isset($_POST['NS']) ? sanitize($_POST['NS']) : '';

$CSclearWidth = sanitize($_POST['CSclear_width'][0]);
$CSstatus = isset($_POST['CS']) ? sanitize($_POST['CS']) : '';

$WSclearWidth = sanitize($_POST['WSclear_width'][0]);
$WSstatus = isset($_POST['WS']) ? sanitize($_POST['WS']) : '';

$HEclearWidth = sanitize($_POST['HEclear_width'][0]);
$HEstatus = isset($_POST['HE']) ? sanitize($_POST['HE']) : '';

$OSclearWidth = sanitize($_POST['OSclear_width'][0]);
$OSstatus = isset($_POST['OS']) ? sanitize($_POST['OS']) : '';

$EPclearWidth = sanitize($_POST['EPclear_width'][0]);
$EPstatus = isset($_POST['EP']) ? sanitize($_POST['EP']) : '';

$FESclearWidth = sanitize($_POST['FESclear_width'][0]);
$FESstatus = isset($_POST['FES']) ? sanitize($_POST['FES']) : '';

$FELclearWidth = sanitize($_POST['FELclear_width'][0]);
$FELstatus = isset($_POST['FEL']) ? sanitize($_POST['FEL']) : '';

$SEclearWidth = sanitize($_POST['SEclear_width'][0]);
$SEstatus = isset($_POST['SE']) ? sanitize($_POST['SE']) : '';

// SQL query for inserting or updating exit components data
$sql = "INSERT INTO tbl_bexit_components (
            inspection_id,
            stairs_type, stairs_type1, stairs_type2, stairs_type3,
            ED_clear_width, ED_status,
            NS_clear_width, NS_status,
            CS_clear_width, CS_status,
            WS_clear_width, WS_status,
            HE_clear_width, HE_status,
            OS_clear_width, OS_status,
            EP_clear_width, EP_status,
            FES_clear_width, FES_status,
            FEL_clear_width, FEL_status,
            SE_clear_width, SE_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            stairs_type = VALUES(stairs_type),
            stairs_type1 = VALUES(stairs_type1),
            stairs_type2 = VALUES(stairs_type2),
            stairs_type3 = VALUES(stairs_type3),
            ED_clear_width = VALUES(ED_clear_width),
            ED_status = VALUES(ED_status),
            NS_clear_width = VALUES(NS_clear_width),
            NS_status = VALUES(NS_status),
            CS_clear_width = VALUES(CS_clear_width),
            CS_status = VALUES(CS_status),
            WS_clear_width = VALUES(WS_clear_width),
            WS_status = VALUES(WS_status),
            HE_clear_width = VALUES(HE_clear_width),
            HE_status = VALUES(HE_status),
            OS_clear_width = VALUES(OS_clear_width),
            OS_status = VALUES(OS_status),
            EP_clear_width = VALUES(EP_clear_width),
            EP_status = VALUES(EP_status),
            FES_clear_width = VALUES(FES_clear_width),
            FES_status = VALUES(FES_status),
            FEL_clear_width = VALUES(FEL_clear_width),
            FEL_status = VALUES(FEL_status),
            SE_clear_width = VALUES(SE_clear_width),
            SE_status = VALUES(SE_status)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "issssssssssssssssssssssss",
    $inspectionId,
    $stairsType,
    $stairsType1,
    $stairsType2,
    $stairsType3,
    $EDclearWidth,
    $EDstatus,
    $NSclearWidth,
    $NSstatus,
    $CSclearWidth,
    $CSstatus,
    $WSclearWidth,
    $WSstatus,
    $HEclearWidth,
    $HEstatus,
    $OSclearWidth,
    $OSstatus,
    $EPclearWidth,
    $EPstatus,
    $FESclearWidth,
    $FESstatus,
    $FELclearWidth,
    $FELstatus,
    $SEclearWidth,
    $SEstatus
);

// Execute the statement
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bexit_components: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();


// Retrieve and sanitize POST data for the Exit Doors Section
$ED1dimensions = sanitize($_POST['ED1dimensions'][0]);
$ED1status = isset($_POST['ED1']) ? sanitize($_POST['ED1']) : ''; 
$ED2dimensions = sanitize($_POST['ED2dimensions'][0]);
$ED2status = isset($_POST['ED2']) ? sanitize($_POST['ED2']) : '';
$ED3dimensions = sanitize($_POST['ED3dimensions'][0]);
$ED3status = isset($_POST['ED3']) ? sanitize($_POST['ED3']) : '';
$ED4dimensions = sanitize($_POST['ED4dimensions'][0]);
$ED4status = isset($_POST['ED4']) ? sanitize($_POST['ED4']) : '';
$ED5dimensions = sanitize($_POST['ED5dimensions'][0]);
$ED5status = isset($_POST['ED5']) ? sanitize($_POST['ED5']) : '';
$ED6dimensions = sanitize($_POST['ED6dimensions'][0]);
$ED6status = isset($_POST['ED6']) ? sanitize($_POST['ED6']) : '';
$ED7dimensions = sanitize($_POST['ED7dimensions'][0]);
$ED7status = isset($_POST['ED7']) ? sanitize($_POST['ED7']) : '';
$ED8dimensions = sanitize($_POST['ED8dimensions'][0]);
$ED8status = isset($_POST['ED8']) ? sanitize($_POST['ED8']) : '';
$ED9dimensions = sanitize($_POST['ED9dimensions'][0]);
$ED9status = isset($_POST['ED9']) ? sanitize($_POST['ED9']) : '';
$ED10dimensions = sanitize($_POST['ED10dimensions'][0]);
$ED10status = isset($_POST['ED10']) ? sanitize($_POST['ED10']) : '';
$ED11status = isset($_POST['ED11']) ? sanitize($_POST['ED11']) : '';
$ED12status = isset($_POST['ED12']) ? sanitize($_POST['ED12']) : '';
$ED13status = isset($_POST['ED13']) ? sanitize($_POST['ED13']) : '';
$ED14status = isset($_POST['ED14']) ? sanitize($_POST['ED14']) : '';
$ED15status = isset($_POST['ED15']) ? sanitize($_POST['ED15']) : '';

// SQL query for inserting or updating exit doors requirements
$sql = "INSERT INTO tbl_bexit_doors_requirements (
            inspection_id,
            ED1_dimensions, ED1_status,
            ED2_dimensions, ED2_status,
            ED3_dimensions, ED3_status,
            ED4_dimensions, ED4_status,
            ED5_dimensions, ED5_status,
            ED6_dimensions, ED6_status,
            ED7_dimensions, ED7_status,
            ED8_dimensions, ED8_status,
            ED9_dimensions, ED9_status,
            ED10_dimensions, ED10_status,
            ED11_status,
            ED12_status,
            ED13_status,
            ED14_status,
            ED15_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            ED1_dimensions = VALUES(ED1_dimensions),
            ED1_status = VALUES(ED1_status),
            ED2_dimensions = VALUES(ED2_dimensions),
            ED2_status = VALUES(ED2_status),
            ED3_dimensions = VALUES(ED3_dimensions),
            ED3_status = VALUES(ED3_status),
            ED4_dimensions = VALUES(ED4_dimensions),
            ED4_status = VALUES(ED4_status),
            ED5_dimensions = VALUES(ED5_dimensions),
            ED5_status = VALUES(ED5_status),
            ED6_dimensions = VALUES(ED6_dimensions),
            ED6_status = VALUES(ED6_status),
            ED7_dimensions = VALUES(ED7_dimensions),
            ED7_status = VALUES(ED7_status),
            ED8_dimensions = VALUES(ED8_dimensions),
            ED8_status = VALUES(ED8_status),
            ED9_dimensions = VALUES(ED9_dimensions),
            ED9_status = VALUES(ED9_status),
            ED10_dimensions = VALUES(ED10_dimensions),
            ED10_status = VALUES(ED10_status),
            ED11_status = VALUES(ED11_status),
            ED12_status = VALUES(ED12_status),
            ED13_status = VALUES(ED13_status),
            ED14_status = VALUES(ED14_status),
            ED15_status = VALUES(ED15_status)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "isssssssssssssssssssssssss",
    $inspectionId,
    $ED1dimensions,
    $ED1status,
    $ED2dimensions,
    $ED2status,
    $ED3dimensions,
    $ED3status,
    $ED4dimensions,
    $ED4status,
    $ED5dimensions,
    $ED5status,
    $ED6dimensions,
    $ED6status,
    $ED7dimensions,
    $ED7status,
    $ED8dimensions,
    $ED8status,
    $ED9dimensions,
    $ED9status,
    $ED10dimensions,
    $ED10status,
    $ED11status,
    $ED12status,
    $ED13status,
    $ED14status,
    $ED15status
);

// Execute the statement and handle potential inspection failure
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bexit_doors_requirements: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();


  // Retrieve and sanitize POST data for the Exit Discharge Section
$C1dimensions = sanitize($_POST['C1dimensions'][0]); // Remoteness not less than 1/2
$C1status = isset($_POST['C1']) ? sanitize($_POST['C1']) : '';
$C2dimensions = sanitize($_POST['C2dimensions'][0]); // Remoteness not less than 1/3
$C2status = isset($_POST['C2']) ? sanitize($_POST['C2']) : '';
$C3status = isset($_POST['C3']) ? sanitize($_POST['C3']) : ''; // Exterior grounds clear
$C4status = isset($_POST['C4']) ? sanitize($_POST['C4']) : ''; // Terminate directly at public way

// SQL query for inserting or updating exit discharge requirements
$sql = "INSERT INTO tbl_bexit_discharge_requirements (
            inspection_id,
            C1_dimensions, C1_status,
            C2_dimensions, C2_status,
            C3_status,
            C4_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            C1_dimensions = VALUES(C1_dimensions),
            C1_status = VALUES(C1_status),
            C2_dimensions = VALUES(C2_dimensions),
            C2_status = VALUES(C2_status),
            C3_status = VALUES(C3_status),
            C4_status = VALUES(C4_status)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind parameters to the SQL query
$stmt->bind_param(
    "issssss",
    $inspectionId,
    $C1dimensions,
    $C1status,
    $C2dimensions,
    $C2status,
    $C3status,
    $C4status
);

// Execute the statement and handle potential inspection failure
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bexit_discharge_requirements: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();



// Sanitize and prepare POST data for each section

// A. MARKINGS OF MEANS OF EGRESS (Exit)
$actual_dim1 = sanitize($_POST['actual_dim'][0]); // First dimension for egress marking
$actual_dim2 = sanitize($_POST['actual_dim'][1]); // Second dimension for egress marking
$actual_dim3 = sanitize($_POST['actual_dim'][2]); // Third dimension for egress marking
$status_A_1 = isset($_POST['status_A_0']) ? sanitize($_POST['status_A_0']) : '';
$status_A_2 = isset($_POST['status_A_1']) ? sanitize($_POST['status_A_1']) : '';
$status_A_3 = isset($_POST['status_A_2']) ? sanitize($_POST['status_A_2']) : '';

// B. MARKINGS OF MEANS OF EGRESS (Emergency Evacuation Plan)
$location_status = isset($_POST['location_status']) ? sanitize($_POST['location_status']) : '';
$location_status1 = isset($_POST['location_status1']) ? sanitize($_POST['location_status1']) : '';

// C. DIMENSIONS OF EMERGENCY EVACUATION PLAN
$actual_dim1_plan = sanitize($_POST['actual_dim1']);
$actual_dim2_plan = sanitize($_POST['actual_dim2']);
$actual_dim3_plan = sanitize($_POST['actual_dim3']);
$status1_plan = isset($_POST['status1']) ? sanitize($_POST['status1']) : '';
$status2_plan = isset($_POST['status2']) ? sanitize($_POST['status2']) : '';
$status3_plan = isset($_POST['status3']) ? sanitize($_POST['status3']) : '';

// D. ILLUMINATION OF MEANS OF EGRESS
$lux_time_1 = sanitize($_POST['lux_time_1']);
$lux_time_2 = sanitize($_POST['lux_time_2']);
$measurement_stairs = sanitize($_POST['measurement_stairs']);
$measurement_lighting = sanitize($_POST['measurement_lighting']);
$measurement_system = sanitize($_POST['measurement_system']);
$measurement_testing = sanitize($_POST['measurement_testing']);
$result_1 = isset($_POST['result_1']) ? sanitize($_POST['result_1']) : '';
$result_2 = isset($_POST['result_2']) ? sanitize($_POST['result_2']) : '';
$result_stairs = isset($_POST['result_stairs']) ? sanitize($_POST['result_stairs']) : '';
$result_lighting = isset($_POST['result_lighting']) ? sanitize($_POST['result_lighting']) : '';
$result_system = isset($_POST['result_system']) ? sanitize($_POST['result_system']) : '';
$result_testing = isset($_POST['result_testing']) ? sanitize($_POST['result_testing']) : '';

// E. EMERGENCY LIGHTING OPTIONS
$emergency_option_215_9mm = isset($_POST['215.9mm']) ? sanitize($_POST['215.9mm']) : '';
$emergency_option_457_2mm = isset($_POST['457.2mm']) ? sanitize($_POST['457.2mm']) : '';
$emergency_option_914_4mm = isset($_POST['914.4mm']) ? sanitize($_POST['914.4mm']) : '';
$emergency_option_10_8lux = isset($_POST['10.8lux']) ? sanitize($_POST['10.8lux']) : '';
$emergency_option_1_5_hour = isset($_POST['1.5-hour']) ? sanitize($_POST['1.5-hour']) : '';
$emergency_option_written_record = isset($_POST['Writtenrecord']) ? sanitize($_POST['Writtenrecord']) : '';

// Prepare SQL query to insert data into `tbl_bsigns_lighting_exits`
$sql = "INSERT INTO tbl_bsigns_lighting_exits (
    inspection_id, actual_dim_1, status_A_0, actual_dim_2, status_A_1, actual_dim_3, status_A_2,
    location_status, location_status1, actual_dim1, status1, actual_dim2, status2, actual_dim3, status3,
    lux_time_1, result_1, lux_time_2, result_2, measurement_stairs, result_stairs,
    measurement_lighting, result_lighting, measurement_system, result_system, measurement_testing, result_testing,
    emergency_option_215_9mm, emergency_option_457_2mm, emergency_option_914_4mm, emergency_option_10_8lux,
    emergency_option_1_5_hour, emergency_option_written_record
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE 
    actual_dim_1 = VALUES(actual_dim_1),
    status_A_0 = VALUES(status_A_0),
    actual_dim_2 = VALUES(actual_dim_2),
    status_A_1 = VALUES(status_A_1),
    actual_dim_3 = VALUES(actual_dim_3),
    status_A_2 = VALUES(status_A_2),
    location_status = VALUES(location_status),
    location_status1 = VALUES(location_status1),
    actual_dim1 = VALUES(actual_dim1),
    status1 = VALUES(status1),
    actual_dim2 = VALUES(actual_dim2),
    status2 = VALUES(status2),
    actual_dim3 = VALUES(actual_dim3),
    status3 = VALUES(status3),
    lux_time_1 = VALUES(lux_time_1),
    result_1 = VALUES(result_1),
    lux_time_2 = VALUES(lux_time_2),
    result_2 = VALUES(result_2),
    measurement_stairs = VALUES(measurement_stairs),
    result_stairs = VALUES(result_stairs),
    measurement_lighting = VALUES(measurement_lighting),
    result_lighting = VALUES(result_lighting),
    measurement_system = VALUES(measurement_system),
    result_system = VALUES(result_system),
    measurement_testing = VALUES(measurement_testing),
    result_testing = VALUES(result_testing),
    emergency_option_215_9mm = VALUES(emergency_option_215_9mm),
    emergency_option_457_2mm = VALUES(emergency_option_457_2mm),
    emergency_option_914_4mm = VALUES(emergency_option_914_4mm),
    emergency_option_10_8lux = VALUES(emergency_option_10_8lux),
    emergency_option_1_5_hour = VALUES(emergency_option_1_5_hour),
    emergency_option_written_record = VALUES(emergency_option_written_record)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind the parameters
$stmt->bind_param(
    "issssssssssssssssssssssssssssssss", // Adjusted type string with 32 placeholders
    $inspectionId, $actual_dim1, $status_A_1, $actual_dim2, $status_A_2, $actual_dim3, $status_A_3,
    $location_status, $location_status1, $actual_dim1_plan, $status1_plan, $actual_dim2_plan, $status2_plan, $actual_dim3_plan, $status3_plan,
    $lux_time_1, $result_1, $lux_time_2, $result_2, $measurement_stairs, $result_stairs,
    $measurement_lighting, $result_lighting, $measurement_system, $result_system, $measurement_testing, $result_testing,
    $emergency_option_215_9mm, $emergency_option_457_2mm, $emergency_option_914_4mm, $emergency_option_10_8lux,
    $emergency_option_1_5_hour, $emergency_option_written_record
);

// Execute the statement and check for errors
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bsigns_lighting_exits: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();


// Retrieve and sanitize POST data for Hazard Section
$hazard_contents = sanitize($_POST['hazard_contents']);
$quantity = sanitize($_POST['quantity']);
$hazard_pla = sanitize($_POST['hazard_pla']);
$maq = isset($_POST['maq']) ? sanitize($_POST['maq']) : '';
$hazard_no = sanitize($_POST['hazard_no']);
$hazard_classification = sanitize($_POST['hazard_classification']);
$class = sanitize($_POST['Class']);
$flash_point = sanitize($_POST['flash_point']);
$sealed_containers = isset($_POST['sealed_containers']) ? sanitize($_POST['sealed_containers']) : '';
$properly_dispensed = isset($_POST['properly_dispensed']) ? sanitize($_POST['properly_dispensed']) : '';
$no_smoking_sign = isset($_POST['no_smoking_sign']) ? sanitize($_POST['no_smoking_sign']) : '';
$no_smoking_area = isset($_POST['no_smoking_area']) ? sanitize($_POST['no_smoking_area']) : '';
$gasoline_storage = isset($_POST['result_3']) ? sanitize($_POST['result_3']) : '';
$HMSWresult_1 = isset($_POST['HMSWresult_1']) ? sanitize($_POST['HMSWresult_1']) : '';
$HMSWresult_2 = isset($_POST['HMSWresult_2']) ? sanitize($_POST['HMSWresult_2']) : '';
$HMSWresult_3 = isset($_POST['HMSWresult_3']) ? sanitize($_POST['HMSWresult_3']) : '';

// Prepare SQL query to insert into the hazards table
$sql = "INSERT INTO tbl_bhazards (
    inspection_id, hazard_contents, quantity, hazard_pla, maq,
    hazard_no, hazard_classification, class, flash_point,
    sealed_containers, properly_dispensed, no_smoking_sign,
    no_smoking_area, gasoline_storage,
    HMSWresult_1, HMSWresult_2, HMSWresult_3
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE 
            hazard_contents = VALUES(hazard_contents),
            quantity = VALUES(quantity),
            hazard_pla = VALUES(hazard_pla),
            maq = VALUES(maq),
            hazard_no = VALUES(hazard_no),
            hazard_classification = VALUES(hazard_classification),
            class = VALUES(class),
            flash_point = VALUES(flash_point),
            sealed_containers = VALUES(sealed_containers),
            properly_dispensed = VALUES(properly_dispensed),
            no_smoking_sign = VALUES(no_smoking_sign),
            no_smoking_area = VALUES(no_smoking_area),
            gasoline_storage = VALUES(gasoline_storage),
            HMSWresult_1 = VALUES(HMSWresult_1),
            HMSWresult_2 = VALUES(HMSWresult_2),
            HMSWresult_3 = VALUES(HMSWresult_3)";

// Prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}

// Bind the parameters
$stmt->bind_param(
    "issssssssssssssss",
    $inspectionId, $hazard_contents, $quantity, $hazard_pla, $maq,
    $hazard_no, $hazard_classification, $class, $flash_point,
    $sealed_containers, $properly_dispensed, $no_smoking_sign,
    $no_smoking_area, $gasoline_storage,
    $HMSWresult_1, $HMSWresult_2, $HMSWresult_3
);

// Execute the statement and check for errors
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bhazards: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();



// Retrieve and sanitize POST data
$sprinkler_pumps = sanitize($_POST['sprinkler_pumps']);
$sprinkler_valves = sanitize($_POST['sprinkler_valves']);
$sprinkler_alarm = sanitize($_POST['sprinkler_alarm']);
$cabinet_door = sanitize($_POST['cabinet_door']);
$hose_condition = sanitize($_POST['hose_condition']);
$nozzle = sanitize($_POST['nozzle']);
$hose_hung = sanitize($_POST['hose_hung']);
$valves_handles = sanitize($_POST['valves_handles']);
$pump_system = sanitize($_POST['pump_system']);
$pippings = sanitize($_POST['pippings']);
$motor = sanitize($_POST['motor']);
$electrical_system = sanitize($_POST['electrical_system']);
$valves_in_place = sanitize($_POST['valves_in_place']);
$fire_detection = sanitize($_POST['fire_detection']);
$location_signs = sanitize($_POST['location_signs']);
$alarm_panels = sanitize($_POST['alarm_panels']);
$lifts_home = sanitize($_POST['lifts_home']);
$lift_fans = sanitize($_POST['lift_fans']);
$fireman_lift = sanitize($_POST['fireman_lift']);

// Prepare SQL query with placeholders
$sql = "INSERT INTO tbl_bfire_protection_inspection (inspection_id,
            sprinkler_pumps, sprinkler_valves, sprinkler_alarm,
            cabinet_door, hose_condition, nozzle, hose_hung, 
            valves_handles, pump_system, pippings, motor,
            electrical_system, valves_in_place, fire_detection,
            location_signs, alarm_panels, lifts_home, lift_fans, 
            fireman_lift
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            sprinkler_pumps = VALUES(sprinkler_pumps),
            sprinkler_valves = VALUES(sprinkler_valves),
            sprinkler_alarm = VALUES(sprinkler_alarm),
            cabinet_door = VALUES(cabinet_door),
            hose_condition = VALUES(hose_condition),
            nozzle = VALUES(nozzle),
            hose_hung = VALUES(hose_hung),
            valves_handles = VALUES(valves_handles),
            pump_system = VALUES(pump_system),
            pippings = VALUES(pippings),
            motor = VALUES(motor),
            electrical_system = VALUES(electrical_system),
            valves_in_place = VALUES(valves_in_place),
            fire_detection = VALUES(fire_detection),
            location_signs = VALUES(location_signs),
            alarm_panels = VALUES(alarm_panels),
            lifts_home = VALUES(lifts_home),
            lift_fans = VALUES(lift_fans),
            fireman_lift = VALUES(fireman_lift)";

// Initialize and prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

// Bind parameters
$stmt->bind_param(
    "isssssssssssssssssss",
    $inspectionId, $sprinkler_pumps, $sprinkler_valves, $sprinkler_alarm,
    $cabinet_door, $hose_condition, $nozzle, $hose_hung,
    $valves_handles, $pump_system, $pippings, $motor,
    $electrical_system, $valves_in_place, $fire_detection,
    $location_signs, $alarm_panels, $lifts_home, $lift_fans, 
    $fireman_lift
);
// Execute the statement and check for errors
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bfire_protection_inspection: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();

// Sanitize and retrieve POST data
$fire_extinguisher_size = isset($_POST['fire_extinguisher_size']) ? sanitize($_POST['fire_extinguisher_size']) : '';
$num_extinguishers = isset($_POST['num_extinguishers']) ? sanitize($_POST['num_extinguishers']) : '';
$extinguisher_location = isset($_POST['extinguisher_location']) ? sanitize($_POST['extinguisher_location']) : '';
$seals_tags = isset($_POST['seals_tags']) ? sanitize($_POST['seals_tags']) : '';
$markings = isset($_POST['markings']) ? sanitize($_POST['markings']) : '';
$condition = isset($_POST['condition']) ? sanitize($_POST['condition']) : '';
$pressure_gauge = isset($_POST['pressure_gauge']) ? sanitize($_POST['pressure_gauge']) : '';
$battery_lights = isset($_POST['battery_lights']) ? sanitize($_POST['battery_lights']) : '';
$hoods_vents = isset($_POST['hoods_vents']) ? sanitize($_POST['hoods_vents']) : '';
$hoods_filter = isset($_POST['hoods_filter']) ? sanitize($_POST['hoods_filter']) : '';
$utilities_cooking = isset($_POST['utilities_cooking']) ? sanitize($_POST['utilities_cooking']) : '';
$hvac = isset($_POST['hvac']) ? sanitize($_POST['hvac']) : '';
$smoke_control_systems = isset($_POST['smoke_control_systems']) ? sanitize($_POST['smoke_control_systems']) : '';
$AHR = isset($_POST['AHR']) ? sanitize($_POST['AHR']) : '';
$PSRA = isset($_POST['PSRA']) ? sanitize($_POST['PSRA']) : '';
$EACM = isset($_POST['EACM']) ? sanitize($_POST['EACM']) : '';
$USWF = isset($_POST['USWF']) ? sanitize($_POST['USWF']) : '';
$AMH = isset($_POST['AMH']) ? sanitize($_POST['AMH']) : '';
$AOBS = isset($_POST['AOBS']) ? sanitize($_POST['AOBS']) : '';
$chutes_incinerators = isset($_POST['chutes_incinerators']) ? sanitize($_POST['chutes_incinerators']) : '';
$CIS = isset($_POST['CIS']) ? sanitize($_POST['CIS']) : '';
$PMEC = isset($_POST['PMEC']) ? sanitize($_POST['PMEC']) : '';
$fire_wall = isset($_POST['fire_wall']) ? sanitize($_POST['fire_wall']) : '';
$fw_extension = isset($_POST['fw_extension']) ? sanitize($_POST['fw_extension']) : '';
$wall_type = isset($_POST['wall_type']) ? sanitize($_POST['wall_type']) : '';


// Prepare SQL query with placeholders
$sql = "INSERT INTO tbl_bfire_safety_inspection (inspection_id,
    fire_extinguisher_size, num_extinguishers, extinguisher_location,
    seals_tags, markings, conditions, pressure_gauge, battery_lights,
    hoods_vents, hoods_filter, utilities_cooking, hvac,
    smoke_control_systems, AHR, PSRA, EACM, USWF, AMH, AOBS, 
    chutes_incinerators, CIS, PMEC, fire_wall, fw_extension, wall_type
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE 
            fire_extinguisher_size = VALUES(fire_extinguisher_size),
            num_extinguishers = VALUES(num_extinguishers),
            extinguisher_location = VALUES(extinguisher_location),
            seals_tags = VALUES(seals_tags),
            markings = VALUES(markings),
            conditions = VALUES(conditions),
            pressure_gauge = VALUES(pressure_gauge),
            battery_lights = VALUES(battery_lights),
            hoods_vents = VALUES(hoods_vents),
            hoods_filter = VALUES(hoods_filter),
            utilities_cooking = VALUES(utilities_cooking),
            hvac = VALUES(hvac),
            smoke_control_systems = VALUES(smoke_control_systems),
            AHR = VALUES(AHR),
            PSRA = VALUES(PSRA),
            EACM = VALUES(EACM),
            USWF = VALUES(USWF),
            AMH = VALUES(AMH),
            AOBS = VALUES(AOBS), 
            chutes_incinerators = VALUES(chutes_incinerators),
            CIS = VALUES(CIS),
            PMEC = VALUES(PMEC),
            fire_wall = VALUES(fire_wall),
            fw_extension = VALUES(fw_extension),
            wall_type = VALUES(wall_type)";


// Initialize and prepare the statement
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

// Bind parameters
$stmt->bind_param(
    "isssssssssssssssssssssssss",
$inspectionId, $fire_extinguisher_size, $num_extinguishers, $extinguisher_location,
    $seals_tags, $markings, $condition, $pressure_gauge, $battery_lights,
    $hoods_vents, $hoods_filter, $utilities_cooking, $hvac,
    $smoke_control_systems, $AHR, $PSRA, $EACM, $USWF, $AMH, $AOBS,
    $chutes_incinerators, $CIS, $PMEC, $fire_wall, $fw_extension, $wall_type
);


// Execute the statement and check for errors
if (!$stmt->execute()) {
    echo "Error inserting into tbl_bfire_safety_inspection: " . $stmt->error . "<br>";
    $inspection_failed = true;
}

$stmt->close();

// Determine if horizontal components inspection failed based on status fields
$horizontal_status = [
    $doorsStatus,
    $corridorsStatus,
    $passagewaysStatus,
    $lobbyStatus,
    $rampsStatus,
    $commonPathStatus,
    $deadEndStatus,
    $travelDistanceStatus
];

foreach ($horizontal_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

// Determine if exit access inspection failed based on status fields
$exit_access_status = [
    $EA1status,
    $EA2status,
    $EA3status,
    $EA4status,
    $EA5status,
    $EA6status,
    $EA7status,
    $EA8status
];


foreach ($exit_access_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

// Gather statuses for binding
$bexit_components_status = [
    $EDstatus,
    $NSstatus,
    $CSstatus,
    $WSstatus,
    $HEstatus,
    $OSstatus,
    $EPstatus,
    $FESstatus,
    $FELstatus,
    $SEstatus
];

// Determine if any status indicates a failure

foreach ($bexit_components_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

// Gather statuses for checking failures
$bexit_doors_requirements_status = [
    $ED1status,
    $ED2status,
    $ED3status,
    $ED4status,
    $ED5status,
    $ED6status,
    $ED7status,
    $ED8status,
    $ED9status,
    $ED10status,
    $ED11status,
    $ED12status,
    $ED13status,
    $ED14status,
    $ED15status
];


foreach ($bexit_doors_requirements_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

// Gather statuses for checking failures
$bexit_discharge_requirements_status = [
    $C1status,
    $C2status,
    $C3status,
    $C4status
];


foreach ($bexit_discharge_requirements_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

$signs_lighting_exits_status = [
    $actual_dim1,
    $status_A_1,
    $status_A_2,
    $location_status,
    $location_status1,
    $status1_plan,
    $status2_plan,
    $status3_plan,
    $result_1,
    $result_2,
    $result_stairs,
    $result_lighting,
    $result_system,
    $result_testing
];

foreach ($signs_lighting_exits_status as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

$hazard_statuses = [
    $sealed_containers,
    $properly_dispensed,
    $no_smoking_sign,
    $no_smoking_area,
    $gasoline_storage,
    $HMSWresult_1,
    $HMSWresult_2,
    $HMSWresult_3
];


foreach ($hazard_statuses as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}


$fire_protection_statuses = [
    $sprinkler_pumps,
    $sprinkler_valves,
    $sprinkler_alarm,
    $cabinet_door,
    $hose_condition,
    $nozzle,
    $hose_hung,
    $valves_handles,
    $pump_system,
    $pippings,
    $motor,
    $electrical_system,
    $valves_in_place,
    $fire_detection,
    $location_signs,
    $alarm_panels,
    $lifts_home,
    $lift_fans,
    $fireman_lift
];




foreach ($fire_protection_statuses as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}


$fire_safety_statuses = [
    $fire_extinguisher_size,
    $num_extinguishers,
    $extinguisher_location,
    $seals_tags,
    $markings,
    $condition, // Assuming this is the field you want to check
    $pressure_gauge,
    $battery_lights,
    $hoods_vents,
    $hoods_filter,
    $utilities_cooking,
    $hvac,
    $smoke_control_systems,
    
];


foreach ($fire_safety_statuses as $status) {
    if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
        $inspection_failed = true;
        break;
    }
}

function collectFailureReasons($conn,  $inspectionId) {
    $failureReasons = [];

    // Check tbl_means_of_egress
    $sql_egress = "SELECT doors_status, corridors_status, passageways_status, lobby_status, ramps_status, common_path_status, dead_end_status, travel_distance_status FROM tbl_bhorizontal_components_summary WHERE inspection_id = ?";
    $stmt_egress = $conn->prepare($sql_egress);
    $stmt_egress->bind_param("i",  $inspectionId);
    $stmt_egress->execute();
    $result_egress = $stmt_egress->get_result();
    if ($row_egress = $result_egress->fetch_assoc()) {
        foreach ($row_egress as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status; // e.g., "Doors Status: Failed"
            }
        }
    }

    // Check tbl_exit_access
    $sql_exit_access = "SELECT EA1_status, EA2_status, EA3_status, EA4_status, EA5_status, EA6_status, EA7_status, EA8_status FROM tbl_bexit_access_requirements WHERE inspection_id = ?";
    $stmt_exit_access = $conn->prepare($sql_exit_access);
    $stmt_exit_access->bind_param("i",  $inspectionId);
    $stmt_exit_access->execute();
    $result_exit_access = $stmt_exit_access->get_result();
    if ($row_exit_access = $result_exit_access->fetch_assoc()) {
        foreach ($row_exit_access as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_bexit_components
    $sql_bexit_components = "SELECT ED_status, NS_status, CS_status, WS_status, HE_status, OS_status, EP_status, FES_status, FEL_status, SE_status FROM tbl_bexit_components WHERE inspection_id = ?";
    $stmt_bexit_components = $conn->prepare($sql_bexit_components);
    $stmt_bexit_components->bind_param("i",  $inspectionId);
    $stmt_bexit_components->execute();
    $result_bexit_components = $stmt_bexit_components->get_result();
    if ($row_bexit_components = $result_bexit_components->fetch_assoc()) {
        foreach ($row_bexit_components as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_bexit_doors_requirements
    $sql_bexit_doors = "SELECT ED1_status, ED2_status, ED3_status, ED4_status, ED5_status, ED6_status, ED7_status, ED8_status, ED9_status, ED10_status, ED11_status, ED12_status, ED13_status, ED14_status, ED15_status FROM tbl_bexit_doors_requirements WHERE inspection_id = ?";
    $stmt_bexit_doors = $conn->prepare($sql_bexit_doors);
    $stmt_bexit_doors->bind_param("i",  $inspectionId);
    $stmt_bexit_doors->execute();
    $result_bexit_doors = $stmt_bexit_doors->get_result();
    if ($row_bexit_doors = $result_bexit_doors->fetch_assoc()) {
        foreach ($row_bexit_doors as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_bexit_discharge_requirements
    $sql_bexit_discharge = "SELECT C1_status, C2_status, C3_status, C4_status FROM tbl_bexit_discharge_requirements WHERE inspection_id = ?";
    $stmt_bexit_discharge = $conn->prepare($sql_bexit_discharge);
    $stmt_bexit_discharge->bind_param("i",  $inspectionId);
    $stmt_bexit_discharge->execute();
    $result_bexit_discharge = $stmt_bexit_discharge->get_result();
    if ($row_bexit_discharge = $result_bexit_discharge->fetch_assoc()) {
        foreach ($row_bexit_discharge as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_signs_lighting_exits
    $sql_signs_lighting = "SELECT  status_A_0, status_A_1, status_A_2, location_status, location_status1, status1, status2, status3, result_1, result_2, result_stairs, result_lighting, result_system, result_testing FROM tbl_bsigns_lighting_exits WHERE inspection_id = ?";
    $stmt_signs_lighting = $conn->prepare($sql_signs_lighting);
    $stmt_signs_lighting->bind_param("i",  $inspectionId);
    $stmt_signs_lighting->execute();
    $result_signs_lighting = $stmt_signs_lighting->get_result();
    if ($row_signs_lighting = $result_signs_lighting->fetch_assoc()) {
        foreach ($row_signs_lighting as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_hazards
    $sql_hazards = "SELECT sealed_containers, properly_dispensed, no_smoking_sign, no_smoking_area, gasoline_storage, HMSWresult_1, HMSWresult_2, HMSWresult_3 FROM tbl_bhazards WHERE inspection_id = ?";
    $stmt_hazards = $conn->prepare($sql_hazards);
    $stmt_hazards->bind_param("i",  $inspectionId);
    $stmt_hazards->execute();
    $result_hazards = $stmt_hazards->get_result();
    if ($row_hazards = $result_hazards->fetch_assoc()) {
        foreach ($row_hazards as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_fire_protection
    $sql_fire_protection = "SELECT sprinkler_pumps, sprinkler_valves, sprinkler_alarm, cabinet_door, hose_condition, nozzle, hose_hung, valves_handles, pump_system, pippings, motor, electrical_system, valves_in_place, fire_detection, location_signs, alarm_panels, lifts_home, lift_fans, fireman_lift FROM tbl_bfire_protection_inspection WHERE inspection_id = ?";
    $stmt_fire_protection = $conn->prepare($sql_fire_protection);
    $stmt_fire_protection->bind_param("i",  $inspectionId);
    $stmt_fire_protection->execute();
    $result_fire_protection = $stmt_fire_protection->get_result();
    if ($row_fire_protection = $result_fire_protection->fetch_assoc()) {
        foreach ($row_fire_protection as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    // Check tbl_fire_safety
    $sql_fire_safety = "SELECT fire_extinguisher_size, num_extinguishers, extinguisher_location, seals_tags, markings, conditions, pressure_gauge, battery_lights, hoods_vents, hoods_filter, utilities_cooking, hvac, smoke_control_systems FROM tbl_bfire_safety_inspection WHERE inspection_id = ?";
    $stmt_fire_safety = $conn->prepare($sql_fire_safety);
    $stmt_fire_safety->bind_param("i",  $inspectionId);
    $stmt_fire_safety->execute();
    $result_fire_safety = $stmt_fire_safety->get_result();
    if ($row_fire_safety = $result_fire_safety->fetch_assoc()) {
        foreach ($row_fire_safety as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status;
            }
        }
    }

    return $failureReasons;
}

// After all the insert statements, determine if inspection failed and collect reasons
$failureReasons = collectFailureReasons($conn,  $inspectionId);
$inspection_failed = !empty($failureReasons);


$mail = new PHPMailer(true);
try {
    // Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'bfp.sflu@gmail.com';  // Your Gmail
    $mail->Password   = 'dxjg cfci fpvc yqjr';  // App-specific password
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;
    // Recipient
    $mail->setFrom('bfp.sflu@gmail.com', 'Bureau of Fire Protection');
    $mail->addAddress($applicantEmail);  // Send to the applicant's email

    // Email content based on inspection result
    $mail->isHTML(true);
    if ($inspection_failed) {
        $mail->Subject = 'Inspection Failed: Compliance Required';
        $mail->Body = '
        <div style="font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;">
            <div style="background-color: #e74c3c; padding: 15px; border-radius: 5px; text-align: center;">
                <h1 style="color: #fff; margin: 0;">Inspection Failed</h1>
            </div>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;">
                <p style="font-size: 16px; color: #e74c3c;">Dear Applicant,</p>
                <p style="font-size: 16px; color: #333;">We regret to inform you that your inspection has <strong>failed</strong>. The following issues were noted:</p>
                <ul style="font-size: 16px; color: #333;">';
        foreach ($failureReasons as $reason) {
            $mail->Body .= '<li>' . htmlspecialchars($reason) . '</li>';
        }
        $mail->Body .= '</ul>
                <p style="font-size: 16px; color: #333;">Please review the inspection report and rectify the issues before scheduling a reinspection.</p>
                <p style="font-size: 14px; color: #777;">Regards,<br>Bureau of Fire Protection</p>
            </div>
            <div style="text-align: center; font-size: 12px; color: #999; margin-top: 20px;">
                <p>This is an automated message. Please do not reply to this email.</p>
            </div>
        </div>';
    } else {
        $mail->Subject = 'Inspection Passed';
        $mail->Body = '
        <div style="font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;">
            <div style="background-color: #2ecc71; padding: 15px; border-radius: 5px; text-align: center;">
                <h1 style="color: #fff; margin: 0;">Inspection Passed</h1>
            </div>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;">
                <p style="font-size: 16px; color: #2ecc71;">Dear Applicant,</p>
                <p style="font-size: 16px; color: #333;">We are pleased to inform you that your inspection has <strong>passed</strong>. Your application is now ready for the next steps.</p>
                <p style="font-size: 14px; color: #777;">Regards,<br>Bureau of Fire Protection</p>
            </div>
            <div style="text-align: center; font-size: 12px; color: #999; margin-top: 20px;">
                <p>This is an automated message. Please do not reply to this email.</p>
            </div>
        </div>';
    }
    // Send the email
    $mail->send();
    echo "Email has been sent.";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
} else {
echo "No email found for the given application ID.";
}
// Update the status in tbl_inspections based on the results
if ($inspection_failed) {
// Update the status to 'Ready for Reinspection'
$sql = "UPDATE tbl_inspections SET status = 'Reinspection' WHERE inspection_id = ?";
} else {
// Update the status to 'Passed'
$sql = "UPDATE tbl_inspections SET status = 'Passed' WHERE inspection_id = ?";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $inspectionId);
if ($stmt->execute()) {
    echo "Inspection status updated successfully.<br>";
} else {
    echo "Error updating inspection status: " . $stmt->error . "<br>";
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>