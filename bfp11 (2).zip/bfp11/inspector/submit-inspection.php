<?php
// Include database connection
include('../connection.php');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Get inspection_id from the form submission
$inspection_id = $_POST['inspection_id'] ?? '';

// Ensure inspection_id is not empty or invalid
if (empty($inspection_id)) {
    die("Inspection ID is required.");
}
// Prepare the SQL query to retrieve inspection details
$sql = "SELECT * FROM tbl_inspections WHERE inspection_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $inspection_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $application_id = $row['application_id'];  // Assuming the tbl_inspections has application_id
    // Fetch the applicant email from tbl_applications using the application_id
    $sql_email = "SELECT email FROM tbl_applications WHERE application_id = ?";
    $stmt_email = $conn->prepare($sql_email);
    $stmt_email->bind_param("i", $application_id);
    $stmt_email->execute();
    $result_email = $stmt_email->get_result();

    if ($result_email->num_rows > 0) {
        $row_email = $result_email->fetch_assoc();
        $applicantEmail = $row_email['email'];  // Fetch the applicant's email
        $inspection_failed = false;
        $insert_success = true; // Assume success until proven otherwise
       // Collect and insert into tbl_reference
    $order_no = $_POST['order_no'] ?? '';
    $date_issued = $_POST['date_issued'] ?? '';
    $date_inspected = $_POST['date_inspected'] ?? '';
    $inspection_type = isset($_POST['inspection_type']) ? implode(', ', $_POST['inspection_type']) : '';
    $others = $_POST['others'] ?? '';

    $sql = "INSERT INTO tbl_reference (inspection_id, order_no, date_issued, date_inspected, inspection_type, others)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            order_no = VALUES(order_no),
            date_issued = VALUES(date_issued),
            date_inspected = VALUES(date_inspected),
            inspection_type = VALUES(inspection_type),
            others = VALUES(others)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $inspection_id, $order_no, $date_issued, $date_inspected, $inspection_type, $others);
    if (!$stmt->execute()) {
        echo "Error inserting into tbl_reference: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }

    // Collect and insert into tbl_business_details
    $business_name = $_POST['business_name'] ?? '';
    $building_name = $_POST['building_name'] ?? '';
    $business_address = $_POST['business_address'] ?? '';
    $owner_name = $_POST['owner_name'] ?? '';
    $contact_number = $_POST['contact_number'] ?? '';
    $business_nature = $_POST['business_nature'] ?? '';
    $policy_number = $_POST['policy_number'] ?? '';
    $pol_date_issued = $_POST['pol_date_issued'] ?? '';
    $fsic_number = $_POST['fsic_number'] ?? '';
    $fsic_date_issued = $_POST['fsic_date_issued'] ?? '';
    $fsec_number = $_POST['fsec_number'] ?? '';
    $fsec_date_issued = $_POST['fsec_date_issued'] ?? '';
    $building_permit = $_POST['building_permit'] ?? '';
    $rp_date_issued = $_POST['rp_date_issued'] ?? '';
    $bpermit_number = $_POST['bpermit_number'] ?? '';
    $bp_date_issued = $_POST['bp_date_issued'] ?? '';

    $sql = "INSERT INTO tbl_business_details 
        (inspection_id, business_name, building_name, business_address, owner_name, contact_number, business_nature, 
        policy_number, pol_date_issued, fsic_number, fsic_date_issued, fsec_number, fsec_date_issued, 
        building_permit, rp_date_issued, bpermit_number, bp_date_issued)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            business_name = VALUES(business_name),
            building_name = VALUES(building_name),
            business_address = VALUES(business_address),
            owner_name = VALUES(owner_name),
            contact_number = VALUES(contact_number),
            business_nature = VALUES(business_nature),
            policy_number = VALUES(policy_number),
            pol_date_issued = VALUES(pol_date_issued),
            fsic_number = VALUES(fsic_number),
            fsic_date_issued = VALUES(fsic_date_issued),
            fsec_number = VALUES(fsec_number),
            fsec_date_issued = VALUES(fsec_date_issued),
            building_permit = VALUES(building_permit),
            rp_date_issued = VALUES(rp_date_issued),
            bpermit_number = VALUES(bpermit_number),
            bp_date_issued = VALUES(bp_date_issued)";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "issssssssssssssss", 
        $inspection_id, $business_name, $building_name, $business_address, $owner_name, $contact_number, 
        $business_nature, $policy_number, $pol_date_issued, $fsic_number, $fsic_date_issued, 
        $fsec_number, $fsec_date_issued, $building_permit, $rp_date_issued, 
        $bpermit_number, $bp_date_issued
    );
    if (!$stmt->execute()) {
        echo "Error inserting into tbl_business_details: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }

    // Collect and insert into tbl_building_details
    $occupancy_type = $_POST['occupancy_type'] ?? '';
    $construction_type = isset($_POST['construction_type']) ? implode(', ', $_POST['construction_type']) : '';
    $floor_area = $_POST['floor_area'] ?? '';
    $occupant_load = $_POST['occupant_load'] ?? '';
    $building_height = $_POST['building_height'] ?? '';
    $Stories_num = $_POST['Stories_num'] ?? '';
    $Portion_Occupied = $_POST['Portion_Occupied'] ?? '';
    $mezzanine_type = isset($_POST['mezzanine_type']) ? implode(', ', $_POST['mezzanine_type']) : '';
    $Handrails_type = isset($_POST['Handrails_type']) ? implode(', ', $_POST['Handrails_type']) : '';

    $sql = "INSERT INTO tbl_building_details 
        (inspection_id, occupancy_type, construction_type, floor_area, occupant_load, building_height, Stories_num, Portion_Occupied, mezzanine_type, Handrails_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            occupancy_type = VALUES(occupancy_type),
            construction_type = VALUES(construction_type),
            floor_area = VALUES(floor_area),
            occupant_load = VALUES(occupant_load),
            building_height = VALUES(building_height),
            Stories_num = VALUES(Stories_num),
            Portion_Occupied = VALUES(Portion_Occupied),
            mezzanine_type = VALUES(mezzanine_type),
            Handrails_type = VALUES(Handrails_type)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "issssiiiss", 
        $inspection_id, $occupancy_type, $construction_type, $floor_area, $occupant_load, $building_height, 
        $Stories_num, $Portion_Occupied, $mezzanine_type, $Handrails_type
    );
    if (!$stmt->execute()) {
        echo "Error inserting into tbl_building_details: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }

    // Collect and insert into tbl_means_of_egress
    $doorsDim = $_POST['doorsDim'] ?? '';
    $doors_status = $_POST['doors'] ?? '';
    $corridorDim = $_POST['corridorDim'] ?? '';
    $corridor_status = $_POST['corri_hall'] ?? '';
    $exitsdoorsDim = $_POST['exitsdoorsDim'] ?? '';
    $exitsdoors_status = $_POST['exitsdoors'] ?? '';
    $stairsDim = $_POST['stairsDim'] ?? '';
    $stairs_status = $_POST['stairs'] ?? '';
    $horizontalexitDim = $_POST['horizontalexitDim'] ?? '';
    $horizontalexit_status = $_POST['horizontalexit'] ?? '';
    $MLH_status = $_POST['MLH'] ?? '';
    $EED_status = $_POST['EED'] ?? '';
    $ESPI_status = $_POST['ESPI'] ?? '';
    $remarks = $_POST['remarks'] ?? '';

    $sql = "INSERT INTO tbl_means_of_egress 
            (inspection_id, doors_dim, doors_status, corridor_dim, corridor_status, exitsdoors_dim, exitsdoors_status, 
            stairs_dim, stairs_status, horizontalexit_dim, horizontalexit_status, MLH_status, EED_status, ESPI_status, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                doors_dim = VALUES(doors_dim),
                doors_status = VALUES(doors_status),
                corridor_dim = VALUES(corridor_dim),
                corridor_status = VALUES(corridor_status),
                exitsdoors_dim = VALUES(exitsdoors_dim),
                exitsdoors_status = VALUES(exitsdoors_status),
                stairs_dim = VALUES(stairs_dim),
                stairs_status = VALUES(stairs_status),
                horizontalexit_dim = VALUES(horizontalexit_dim),
                horizontalexit_status = VALUES(horizontalexit_status),
                MLH_status = VALUES(MLH_status),
                EED_status = VALUES(EED_status),
                ESPI_status = VALUES(ESPI_status),
                remarks = VALUES(remarks)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issssssssssssss", 
        $inspection_id, $doorsDim, $doors_status, $corridorDim, $corridor_status, $exitsdoorsDim, $exitsdoors_status, 
        $stairsDim, $stairs_status, $horizontalexitDim, $horizontalexit_status, $MLH_status, $EED_status, 
        $ESPI_status, $remarks
    );
    if (!$stmt->execute()) {
        echo "Error inserting into tbl_means_of_egress: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }
    // Collect and insert into tbl_hazards
    $hazard_classification = $_POST['hazard_classification'] ?? '';
    $storage_clearance = $_POST['storage_clearance'] ?? '';
    $FS_clearance = $_POST['FS_clearance'] ?? '';
    $fsdate_issued = $_POST['fsdate_issued'] ?? '';
    $control_num = $_POST['control_num'] ?? '';
    $hazard_content = $_POST['hazard_content'] ?? '';
    $total_volume = $_POST['total_volume'] ?? '';
    $location = $_POST['location'] ?? '';
    $CC_status = $_POST['CC'] ?? '';
    $GDD_status = $_POST['GDD'] ?? '';
    $LPG = $_POST['LPG'] ?? '';
    $ins_clearance = $_POST['ins_clearance'] ?? '';
    $isndate_issued = $_POST['isndate_issued'] ?? '';
    $inscontrol_num = $_POST['inscontrol_num'] ?? '';
    $ssmc = $_POST['ssmc'] ?? '';
    $NSS = $_POST['NSS'] ?? '';
    $remarks = $_POST['remarks'] ?? '';

    $sql = "INSERT INTO tbl_hazards 
            (inspection_id, hazard_classification, storage_clearance, FS_clearance, fsdate_issued, control_num, 
            hazard_content, total_volume, location, CC_status, GDD_status, LPG, ins_clearance, isndate_issued, 
            inscontrol_num, ssmc, NSS, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
            hazard_classification = VALUES(hazard_classification),
            storage_clearance = VALUES(storage_clearance),
            FS_clearance = VALUES(FS_clearance),
            fsdate_issued = VALUES(fsdate_issued),
            control_num = VALUES(control_num),
            hazard_content = VALUES(hazard_content),
            total_volume = VALUES(total_volume),
            location = VALUES(location),
            CC_status = VALUES(CC_status),
            GDD_status = VALUES(GDD_status),
            LPG = VALUES(LPG),
            ins_clearance = VALUES(ins_clearance),
            isndate_issued = VALUES(isndate_issued),
            inscontrol_num = VALUES(inscontrol_num),
            ssmc = VALUES(ssmc),
            NSS = VALUES(NSS),
            remarks = VALUES(remarks)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssssssssssssssss", 
        $inspection_id, $hazard_classification, $storage_clearance, $FS_clearance, $fsdate_issued, $control_num, 
        $hazard_content, $total_volume, $location, $CC_status, $GDD_status, $LPG, $ins_clearance, 
        $isndate_issued, $inscontrol_num, $ssmc, $NSS, $remarks
    );
    if (!$stmt->execute()) {
        echo "Error inserting into tbl_hazards: " . $stmt->error . "<br>";
        $inspection_failed = true;
    }
            // Collect form data for tbl_fire_protection
        $fire_extinguisher_size = $_POST['fire_extinguisher_size'] ?? '';
        $minimum_number_extinguisher = $_POST['minimum_number_extinguisher'] ?? '';
        $location_status = $_POST['location_status'] ?? '';
        $seals_tags = $_POST['seals_tags'] ?? '';
        $markings = $_POST['markings'] ?? '';
        $condition_status = $_POST['condition_status'] ?? '';
        $pressure = $_POST['pressure'] ?? '';
        $firepro_remarks = $_POST['remarks'] ?? '';
        $type = $_POST['type'] ?? '';
        $quantity = $_POST['Quantity'] ?? '';
        $capacity = $_POST['Capacity'] ?? '';
        $ELS_provided = $_POST['ELS_provided'] ?? '';
        $ELS_functional = $_POST['ELS_functional'] ?? '';
        $ELS_Locations = $_POST['ELS_Locations'] ?? '';
        $ELS_others = $_POST['ELS_others'] ?? '';
        $FDA_provided = $_POST['FDA_provided'] ?? '';
        $FDA_functional = $_POST['FDA_functional'] ?? '';
        $UPF = $_POST['UPF'] ?? '';
        $FDA_adequate = $_POST['FDA_adequate'] ?? '';
        $LCP = $_POST['LCP'] ?? '';

        // Insert into tbl_fire_protection
        $sql = "INSERT INTO tbl_fire_protection 
                (inspection_id, fire_extinguisher_size, minimum_number_extinguisher, location_status, seals_tags, markings, condition_status, 
                pressure, remarks, type, quantity, capacity, ELS_provided, ELS_functional, ELS_Locations, ELS_others, 
                FDA_provided, FDA_functional, UPF, FDA_adequate, LCP) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                fire_extinguisher_size = VALUES(fire_extinguisher_size),
                minimum_number_extinguisher = VALUES(minimum_number_extinguisher),
                location_status = VALUES(location_status),
                seals_tags = VALUES(seals_tags),
                markings = VALUES(markings),
                condition_status = VALUES(condition_status),
                pressure = VALUES(pressure),
                remarks = VALUES(remarks),
                type = VALUES(type),
                quantity = VALUES(quantity),
                capacity = VALUES(capacity),
                ELS_provided = VALUES(ELS_provided),
                ELS_functional = VALUES(ELS_functional),
                ELS_Locations = VALUES(ELS_Locations),
                ELS_others = VALUES(ELS_others),
                FDA_provided = VALUES(FDA_provided),
                FDA_functional = VALUES(FDA_functional),
                UPF = VALUES(UPF),
                FDA_adequate = VALUES(FDA_adequate),
                LCP = VALUES(LCP)";
                
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssssssssssssssssss", 
            $inspection_id, $fire_extinguisher_size, $minimum_number_extinguisher, $location_status, $seals_tags, $markings, $condition_status, 
            $pressure, $firepro_remarks, $type, $quantity, $capacity, $ELS_provided, $ELS_functional, $ELS_Locations, $ELS_others, 
            $FDA_provided, $FDA_functional, $UPF, $FDA_adequate, $LCP
        );
        if (!$stmt->execute()) {
            echo "Error inserting into tbl_fire_protection: " . $stmt->error . "<br>";
        }

        // Determine if fire protection inspection failed based on status fields
        $firepro_statuses = [$condition_status, $ELS_functional, $FDA_functional];
        foreach ($firepro_statuses as $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $inspection_failed = true;
                break;
            }
        }
    // Check tbl_hazards failure conditions
    $hazard_statuses = [$CC_status, $GDD_status, $LPG];
    foreach ($hazard_statuses as $status) {
        if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
            $inspection_failed = true;
            break;
        }
    }
    // Check tbl_means_of_egress failure conditions
    $egress_statuses = [$doors_status, $corridor_status, $exitsdoors_status, $stairs_status, $horizontalexit_status];
    foreach ($egress_statuses as $status) {
        if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
            $inspection_failed = true;
            break;
        }
    }
    // ... (rest of your existing code)
// Function to colect failure reasons
function collectFailureReasons($conn, $inspection_id) {
    $failureReasons = [];
    // Check tbl_means_of_egress
    $sql_egress = "SELECT doors_status, corridor_status, exitsdoors_status, stairs_status, horizontalexit_status,MLH_status, EED_status, ESPI_status FROM tbl_means_of_egress WHERE inspection_id = ?";
    $stmt_egress = $conn->prepare($sql_egress);
    $stmt_egress->bind_param("i", $inspection_id);
    $stmt_egress->execute();
    $result_egress = $stmt_egress->get_result();
    if ($row_egress = $result_egress->fetch_assoc()) {
        foreach ($row_egress as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst(str_replace('_', ' ', $key)) . ': ' . $status; // e.g., "Doors Status: Failed"
            }
        }
    }
     // Check tbl_hazards
     $sql_protection = "SELECT fire_extinguisher_size, minimum_number_extinguisher, seals_tags, markings, pressure  FROM tbl_fire_protection WHERE inspection_id = ?";
     $stmt_protection = $conn->prepare($sql_protection);
     $stmt_protection->bind_param("i", $inspection_id);
     $stmt_protection->execute();
     $result_protection = $stmt_protection->get_result();
     if ($row_protection = $result_protection->fetch_assoc()) {
         foreach ($row_protection as $key => $status) {
             if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                 $failureReasons[] = ucfirst($key) . ': ' . $status; // e.g., "CC Status: Failed"
             }
         }
     }
 
    // Check tbl_hazards
    $sql_hazards = "SELECT location, CC_status, GDD_status FROM tbl_hazards WHERE inspection_id = ?";
    $stmt_hazards = $conn->prepare($sql_hazards);
    $stmt_hazards->bind_param("i", $inspection_id);
    $stmt_hazards->execute();
    $result_hazards = $stmt_hazards->get_result();
    if ($row_hazards = $result_hazards->fetch_assoc()) {
        foreach ($row_hazards as $key => $status) {
            if (strtolower($status) === 'failed' || strtolower($status) === 'non-compliant') {
                $failureReasons[] = ucfirst($key) . ': ' . $status; // e.g., "CC Status: Failed"
            }
        }
    }
    return $failureReasons;
}
// After all the insert statements, determine if inspection failed and collect reasons
$failureReasons = collectFailureReasons($conn, $inspection_id);
$inspection_failed = !empty($failureReasons);

        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'bfp.sflu@gmail.com';  // Your Gmail
            $mail->Password   = 'dxjg cfci fpvc yqjr';  // App-specific password
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;
            // Recipient
            $mail->setFrom('bfp.sflu@gmail.com', 'Bureau of Fire Protection');
            $mail->addAddress($applicantEmail);  // Send to the applicant's email

            // Email content based on inspection result
            $mail->isHTML(true);
            if ($inspection_failed) {
                $mail->Subject = 'Inspection Failed: Compliance Required';
                $mail->Body = '
                <div style="font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;">
                    <div style="background-color: #e74c3c; padding: 15px; border-radius: 5px; text-align: center;">
                        <h1 style="color: #fff; margin: 0;">Inspection Failed</h1>
                    </div>
                    <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;">
                        <p style="font-size: 16px; color: #e74c3c;">Dear Applicant,</p>
                        <p style="font-size: 16px; color: #333;">We regret to inform you that your inspection has <strong>failed</strong>. The following issues were noted:</p>
                        <ul style="font-size: 16px; color: #333;">';
                foreach ($failureReasons as $reason) {
                    $mail->Body .= '<li>' . htmlspecialchars($reason) . '</li>';
                }
                $mail->Body .= '</ul>
                        <p style="font-size: 16px; color: #333;">Please review the inspection report and rectify the issues before scheduling a reinspection.</p>
                        <p style="font-size: 14px; color: #777;">Regards,<br>Bureau of Fire Protection</p>
                    </div>
                    <div style="text-align: center; font-size: 12px; color: #999; margin-top: 20px;">
                        <p>This is an automated message. Please do not reply to this email.</p>
                    </div>
                </div>';
            } else {
                $mail->Subject = 'Inspection Passed';
                $mail->Body = '
                <div style="font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4; padding: 20px; border-radius: 8px;">
                    <div style="background-color: #2ecc71; padding: 15px; border-radius: 5px; text-align: center;">
                        <h1 style="color: #fff; margin: 0;">Inspection Passed</h1>
                    </div>
                    <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; margin-top: 10px;">
                        <p style="font-size: 16px; color: #2ecc71;">Dear Applicant,</p>
                        <p style="font-size: 16px; color: #333;">We are pleased to inform you that your inspection has <strong>passed</strong>. Your application is now ready for the next steps.</p>
                        <p style="font-size: 14px; color: #777;">Regards,<br>Bureau of Fire Protection</p>
                    </div>
                    <div style="text-align: center; font-size: 12px; color: #999; margin-top: 20px;">
                        <p>This is an automated message. Please do not reply to this email.</p>
                    </div>
                </div>';
            }
            // Send the email
            $mail->send();
            echo "Email has been sent.";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "No email found for the given application ID.";
    }
 // Update the status in tbl_inspections based on the results
 if ($inspection_failed) {
    // Update the status to 'Ready for Reinspection'
    $sql = "UPDATE tbl_inspections SET status = 'Reinspection' WHERE inspection_id = ?";
} else {
    // Update the status to 'Passed'
    $sql = "UPDATE tbl_inspections SET status = 'Passed' WHERE inspection_id = ?";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $inspection_id);
if ($stmt->execute()) {
    echo "Inspection status updated successfully.<br>";
} else {
    echo "Error updating inspection status: " . $stmt->error . "<br>";
}
} else {
echo "No inspection found with the given ID.";

}
error_reporting(E_ALL);
ini_set('display_errors', 1);

?>  