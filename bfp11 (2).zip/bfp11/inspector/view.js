$(document).ready(function () {

    // When the #viewDetailsModal is shown, populate modal with data
    $('#viewDetailsModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var status = button.data('status');
        var registrationId = button.data('registration-id');

        // Populate modal fields with data
        $('#modalBusinessName').text(button.data('business'));
        $('#modalBuildingName').text(button.data('building'));
        $('#modalBusinessAddress').text(button.data('address'));
        $('#modalOwnerName').text(button.data('owner'));
        $('#modalOccupancyType').text(button.data('occupancy'));
        $('#modalContactNumber').text(button.data('contact'));
        $('#modalBuildingHeight').text(button.data('buildingheight'));
        $('#modalTotalArea').text(button.data('totalarea'));
        $('#modalNumberOfFloors').text(button.data('numberoffloors'));
        $('#modalEmail').text(button.data('email'));
        $('#modalFsicexpiry').text(button.data('fsicexpiry'));
    });

    // When the #editModal is shown, populate modal with form data
    $('#editBusInfoModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        console.log(button.data());
        var registrationId = button.data('registration-id');
        var buildingName = button.data('building-name');
        var buildingHeight = button.data('building-height');
        var totalArea = button.data('total-area');
        var numberOfFloors = button.data('number-of-floors');
        var address = button.data('address1');
        var barangay = button.data('barangay');
        var owner = button.data('owner');
        var contactNumber = button.data('contact-number');
        var businessNature = button.data('business-nature');
        var businessName = button.data('business-name');
        var occupancy = button.data('occupancy');
        var email = button.data('email');
        var fsicExpiry = button.data('fsic-expiry');

        // Update the modal's fields with the data from the button
        var modal = $(this);
        modal.find('#editRegistrationId').val(registrationId);
        modal.find('#editBuildingName').val(buildingName);
        modal.find('#editBuildingHeight').val(buildingHeight);
        modal.find('#editTotalArea').val(totalArea);
        modal.find('#editNumberOfFloors').val(numberOfFloors);
        modal.find('#editAddress').val(address);
        modal.find('#editBarangay').val(barangay);
        modal.find('#editOwner').val(owner);
        modal.find('#editContactNumber').val(contactNumber);
        modal.find('#editBusinessNature').val(businessNature);
        modal.find('#editBusinessName').val(businessName);
        modal.find('#editOccupancy').val(occupancy);
        modal.find('#editEmail').val(email);
        modal.find('#editFSICExpiry').val(fsicExpiry);
    });


    // Barangay population based on district selection
    const barangays = {
        "District I": ["Barangay I", "Barangay II", "Barangay III", "Barangay IV"],
        "District II": ["Ilocanos Sur", "Ilocanos Norte", "Pagdaraoan"],
        "District III": ["Catbangen", "Parian", "Madayegdeg"],
        "District IV": ["Canaoay", "Poro", "San Agustin", "San Francisco"],
        "District V": ["Carlatan", "Dalumpinas Este", "Dalumpinas Oeste", "Lingsat"],
        "District VI": ["Abut", "Bangcusay", "Bato", "Biday", "Mameltac", "Namtutan", "Saoay"],
        "District VII": ["Pagdalagan", "Pagudpud", "San Vicente", "Sevilla"],
        "District VIII": ["Birunget", "Bungro", "Narra Este", "Narra Oeste", "Sagayad", "Sibuan-Otong"],
        "District IX": ["Cabaroan", "Dallangayan Oeste", "Santiago Sur", "Tangqui"],
        "District X": ["Cadaclan", "Camansi", "Dallangayan Este", "Pias", "Santiago Norte"],
        "District XI": ["Cabarsican", "Masicong", "Nagyubyuban", "Pacpaco", "Pao Norte", "Pao Sur", "Sacyud"],
        "District XII": ["Apaleng", "Bacsil", "Bangbangolan", "Baraoas", "Calabugao", "Puspus"]
    };

    // Populate barangays based on selected district
    $('#businessAddress').change(function () {
        const district = $(this).val();
        const barangaySelect = $('#barangay');

        barangaySelect.empty();
        barangaySelect.append('<option value="">Select Barangay</option>');

        if (district in barangays) {
            barangays[district].forEach(barangay => {
                barangaySelect.append(new Option(barangay, barangay));
            });
        }
    });

    // Filter functionality for district and barangay
    $('#filterBtn').click(function () {
        const selectedDistrict = $('#businessAddress').val();
        const selectedBarangay = $('#barangay').val();

        // If no filters are applied, show all rows
        if (selectedDistrict === "" && selectedBarangay === "") {
            $('#dataTable tbody tr').show();
            return;
        }

        // Check if both district and barangay are selected
        if (selectedDistrict !== "" && selectedBarangay !== "") {
            $('#dataTable tbody tr').each(function () {
                const rowAddress = $(this).find('td').eq(2).text().trim(); // Business Address (District and Barangay)

                // Extract the district and barangay from the business address column
                const [rowDistrict, rowBarangay] = rowAddress.split(',').map(item => item.trim());

                // Show or hide rows based on selected district and barangay
                if (rowDistrict === selectedDistrict && rowBarangay === selectedBarangay) {
                    $(this).show();  // Show row if it matches the filter
                } else {
                    $(this).hide();  // Hide row if it doesn't match
                }
            });
        } else {
            alert('Please select both Business District and Barangay');
        }
    });
});




