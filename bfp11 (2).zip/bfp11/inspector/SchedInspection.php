<?php
ob_start(); // Start output buffering
session_start();
include('../header/header2.php'); // Adjust the path as necessary
include('../sidebar/sidebarinspector.php'); // Adjust the path as necessary
include('../connection.php'); // Adjust the path as necessary

// Check if the user is logged in, redirect if not
if (!isset($_SESSION['userlevel']) || $_SESSION['userlevel'] !== 'Inspector') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Fetch approved inspections for the logged-in inspector, excluding certain statuses
$query = "SELECT i.*, b.business_name, b.district, b.barangay, b.occupancy_type, 
                 o.owner_name, o.contact_number, r.email, r.FSIC_expiry,
                 bu.building_name, bu.building_height, bu.total_area, bu.number_of_floors, 
                 r.application_id, u.fname, u.mname, u.lname AS inspector_fname 
          FROM tbl_inspections i 
          JOIN tbl_applications r ON i.application_id = r.application_id
          JOIN tbl_businesses b ON r.business_id = b.business_id
          JOIN tbl_owners o ON r.owner_id = o.owner_id
          JOIN tbl_users u ON i.inspector_fname = u.fname
          LEFT JOIN tbl_buildings bu ON r.building_id = bu.building_id
          WHERE u.username = ?
          AND i.status NOT IN ('Reinspection', 'Ready for Reinspection', 'Passed', 'For Approval', 'Approved')"; // Exclude unwanted statuses

$stmt = $conn->prepare($query);

// Check if the prepare statement failed
if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();

// Check for errors in execution
if ($stmt->error) {
    die("Error executing query: " . $stmt->error);
}

$result = $stmt->get_result();

$inspections = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $inspections[] = $row;
    }
}

$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Approved Inspections</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../style.css">
    <style>
        .custom-btn {
            background-color: #b92828;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            border: none;
            border-radius: 5px;
        }

        .custom-btn i {
            color: white;
        }

        .inspect-btn,
        .view-btn .mr-2 {
            margin-right: 10px;
        }
    </style>
    <style>
        .modal-header {
            background-color: #dc3545;
            border-bottom: none;
        }

        .modal-body {
            font-size: 1.1rem;
        }

        .modal-footer {
            border-top: none;
            justify-content: center;
        }

        .btn-outline-success,
        .btn-outline-info {
            width: 48%;
            padding: 15px;
            font-size: 1rem;
        }

        .btn-outline-success:hover,
        .btn-outline-info:hover {
            background-color: #28a745;
            color: #fff;
        }

        .btn-outline-info:hover {
            background-color: #17a2b8;
            color: #fff;
        }
    </style>
</head>


<body>
    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h5 class="mb-0 text-dark nav-user-name">
                            <i class="fa fa-user"></i>
                            <?php
                            if (isset($_SESSION['user_id'])) {
                                // Assuming you have a connection to the database in $conn
                                $user_id = intval($_SESSION['user_id']);

                                // Query to get the user details from tbl_users
                                $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $user_id); // Bind the user_id
                                $stmt->execute();
                                $result = $stmt->get_result();

                                if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc();
                                    // Sanitize the output to prevent XSS attacks
                                    $fname = htmlspecialchars($row['fname']);
                                    $mname = htmlspecialchars($row['mname']);
                                    $lname = htmlspecialchars($row['lname']);
                                    echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                                } else {
                                    echo 'Welcome, User';
                                }

                                $stmt->close();
                            }
                            ?>
                        </h5>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Approved Inspections</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <h5 class="card-header"><i class="fa fa-fw fa-file-word"></i>My Approved Inspections</h5>
                        <div class="card-body">
                            <div id="message"></div>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered first">
                                    <thead>
                                        <tr>
                                            <th>Business Name</th>
                                            <th>Inspection Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (!empty($inspections)) {
                                            foreach ($inspections as $row) {
                                                ?>
                                                <tr>
                                                    <td><?php echo isset($row['business_name']) ? htmlspecialchars($row['business_name']) : ''; ?>
                                                    </td>
                                                    <td><?php echo isset($row['inspection_date']) ? htmlspecialchars($row['inspection_date']) : ''; ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex justify-content-start align-items-center">
                                                            <!-- Inspect Button -->
                                                            <button type="button" class="btn btn-primary inspect-btn mr-2"
                                                                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                data-inspection-id="<?php echo isset($row['inspection_id']) ? $row['inspection_id'] : ''; ?>"
                                                                data-toggle="modal" data-target="#inspectModal">
                                                                Inspect
                                                            </button>

                                                            <!-- View Button -->
                                                            <button type="button" class="btn btn-info view-details-btn"
                                                                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                data-inspection-id="<?php echo isset($row['inspection_id']) ? $row['inspection_id'] : ''; ?>"
                                                                data-business="<?php echo htmlspecialchars($row['business_name']); ?>"
                                                                data-building="<?php echo htmlspecialchars($row['building_name']); ?>"
                                                                data-address="<?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>"
                                                                data-owner="<?php echo htmlspecialchars($row['owner_name']); ?>"
                                                                data-occupancy="<?php echo htmlspecialchars($row['occupancy_type']); ?>"
                                                                data-contact="<?php echo htmlspecialchars($row['contact_number']); ?>"
                                                                data-buildingheight="<?php echo htmlspecialchars($row['building_height']); ?>"
                                                                data-totalarea="<?php echo htmlspecialchars($row['total_area']); ?>"
                                                                data-numberoffloors="<?php echo htmlspecialchars($row['number_of_floors']); ?>"
                                                                data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                                data-fsicexpiry="<?php echo htmlspecialchars($row['FSIC_expiry']); ?>"
                                                                data-status="<?php echo htmlspecialchars($row['status']); ?>"
                                                                data-toggle="modal" data-target="#viewDetailsModal">
                                                                View
                                                            </button>
                                                        </div>

                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='4'>No records found</td></tr>";
                                        }
                                        ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="inspectModal" tabindex="-1" role="dialog" aria-labelledby="inspectModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header text-white">
                        <h5 class="modal-title" id="inspectModalLabel">Select Business Type</h5>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-center">Please choose the type of business for inspection:</p>
                        <div class="d-flex justify-content-around mt-4">
                            <button id="smallBusinessChecklistBtn" class="btn btn-outline-success btn-lg"
                                data-inspection-id="">Small Business</button>
                            <button id="bigBusinessChecklistBtn" class="btn btn-outline-info btn-lg"
                                data-inspection-id="">Big Business</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal for View Details -->
        <div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog"
            aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header text-white">
                        <h5 class="modal-title" id="viewDetailsModalLabel">View Inspection Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Business Name:</strong> <span id="modalBusinessName"></span></p>
                                    <p><strong>Building Name:</strong> <span id="modalBuildingName"></span></p>
                                    <p><strong>Business Address:</strong> <span id="modalBusinessAddress"></span></p>
                                    <p><strong>Owner Name:</strong> <span id="modalOwnerName"></span></p>
                                    <p><strong>Occupancy Type:</strong> <span id="modalOccupancyType"></span></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Contact Number:</strong> <span id="modalContactNumber"></span></p>
                                    <p><strong>Building Height:</strong> <span id="modalBuildingHeight"></span></p>
                                    <p><strong>Total Area:</strong> <span id="modalTotalArea"></span></p>
                                    <p><strong>Number of Floors:</strong> <span id="modalNumberOfFloors"></span></p>
                                    <p><strong>Email:</strong> <span id="modalEmail"></span></p>
                                    <p><strong>FSIC Expiration:</strong> <span id="modalFsicexpiry"></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer d-flex">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="printButton" class="btn btn-info view-details-btn"
                            data-inspection-id="">Print</button>
                    </div>

                </div>
            </div>
        </div>




        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
        <script src="../assets/libs/js/main-js.js"></script>
        <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
        <script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
        <script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
        <script src="../assets/vendor/datatables/js/data-table.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="view.js"></script>
        <script src="print.js"></script>
        <script>
            $(document).ready(function () {
                // When the inspect button is clicked, capture the inspection_id and pass it to the modal
                $('.inspect-btn').click(function () {
                    var inspectionId = $(this).data('inspection-id'); // Get the inspection_id from the clicked button
                    var status = $(this).data('status');  // Correctly get the status from the button

                    // Pass the inspection_id and status to the Small and Big Business buttons inside the modal
                    $('#smallBusinessChecklistBtn').data('inspection-id', inspectionId);
                    $('#bigBusinessChecklistBtn').data('inspection-id', inspectionId);
                    $('#smallBusinessChecklistBtn').data('status', status);
                    $('#bigBusinessChecklistBtn').data('status', status);
                });

                // Handle small business checklist button click
                $('#smallBusinessChecklistBtn').click(function () {
                    var inspectionId = $(this).data('inspection-id');  // Get the inspection ID from the button
                    window.location.href = 'SmallBusinesschecklist.php?inspection_id=' + inspectionId;
                });

                // Handle big business checklist button click
                $('#bigBusinessChecklistBtn').click(function () {
                    var inspectionId = $(this).data('inspection-id');  // Get the inspection ID from the button
                    window.location.href = 'BigBusinesschecklist.php?inspection_id=' + inspectionId;
                });
            });
        </script>
</body>

</html>