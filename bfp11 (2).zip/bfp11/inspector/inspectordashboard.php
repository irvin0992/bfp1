<?php
include('../session_validate.php');
include('../header/header2.php'); // Adjust the path as necessary
include('../sidebar/sidebarinspector.php'); // Adjust the path as necessary
include '../connection.php';

// Fetch the number of permits
$permits_query = "SELECT COUNT(*) as count FROM tbl_inspections WHERE status = 'Ready for Inspection' ";
$permits_result = mysqli_query($conn, $permits_query);
$permits_count = mysqli_fetch_assoc($permits_result)['count'];

// Fetch the number of inspections
$inspections_query = "SELECT COUNT(*) as count FROM tbl_inspections WHERE status =  'Ready for Reinspection' ";
$inspections_result = mysqli_query($conn, $inspections_query);
$inspections_count = mysqli_fetch_assoc($inspections_result)['count'];
?>


<!-- HTML and Bootstrap code -->
<div class="dashboard-wrapper">
    <div class="container-fluid dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader  -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h5 class="mb-0 text-dark nav-user-name">
                        <i class="fa fa-user"></i>
                        <?php
                        if (isset($_SESSION['user_id'])) {
                            // Assuming you have a connection to the database in $conn
                            $user_id = intval($_SESSION['user_id']);

                            // Query to get the user details from tbl_users
                            $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                            $stmt = $conn->prepare($query);
                            $stmt->bind_param("i", $user_id); // Bind the user_id
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                // Sanitize the output to prevent XSS attacks
                                $fname = htmlspecialchars($row['fname']);
                                $mname = htmlspecialchars($row['mname']);
                                $lname = htmlspecialchars($row['lname']);
                                echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                            } else {
                                echo 'Welcome, User';
                            }

                            $stmt->close();
                        }
                        ?>
                    </h5>
                    <h2 class="pageheader-title" style="margin-top:10px;">
                        <h2 class="pageheader-title"><i class="fa fa-fw fa-tachometer-alt"></i> Dashboard </h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Home</li>
                                </ol>
                            </nav>
                        </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- pageheader  -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- metric -->
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-inline-block">
                            <h5 class="text-muted">Inspections</h5>
                            <h2 class="mb-0"><?php echo $permits_count; ?></h2>
                        </div>
                        <div class="float-right icon-circle-medium icon-box-lg bg-info-light mt-1">
                            <i class="fa fas fa-file-alt fa-fw fa-sm text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!-- metric -->
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-inline-block">
                            <h5 class="text-muted">Reinspections</h5>
                            <h2 class="mb-0"><?php echo $inspections_count; ?></h2>
                        </div>
                        <div class="float-right icon-circle-medium icon-box-lg bg-info-light mt-1">
                            <i class="fa fas fa-archive fa-fw fa-sm text-info"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /. metric -->
        </div>

        <!-- ============================================================== -->
        <!-- Chart Area -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-muted text-center">Inspection Statistics</h5>
                        <div class="d-flex justify-content-center">
                            <canvas id="inspectionChart" style="width:100%; max-width:600px; height:300px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end chart area -->
        <!-- ============================================================== -->
        <!-- end chart area  -->
        <!-- ============================================================== -->
    </div>
</div>

<!-- Optional JavaScript -->
<!-- jquery 3.3.1 js-->
<script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<!-- bootstrap bundle js-->
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<!-- slimscroll js-->
<script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<!-- chartjs js-->
<script src="../assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
<script src="../assets/vendor/charts/charts-bundle/chartjs.js"></script>
<!-- main js-->
<script src="../assets/libs/js/main-js.js"></script>

<script>
    // Chart.js script for displaying the inspections statistics
    var ctx = document.getElementById('inspectionChart').getContext('2d');
    var inspectionChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Inspections', 'Reinspections'],
            datasets: [{
                label: 'Count',
                data: [<?php echo $permits_count; ?>, <?php echo $inspections_count; ?>],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)', // Light green for Inspections
                    'rgba(153, 102, 255, 0.2)' // Light purple for Reinspections
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)', // Darker green for Inspections
                    'rgba(153, 102, 255, 1)' // Darker purple for Reinspections
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
</script>

</body>

</html>