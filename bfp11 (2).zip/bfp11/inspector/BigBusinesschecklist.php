<?php
// Include session validation, header, sidebar, and connection files
include('../session_validate.php');
include('../header/header2.php');
include('../sidebar/sidebarinspector.php');
include('../connection.php');

// Retrieve inspection_id from URL parameter
$inspectionId = isset($_GET['inspection_id']) ? intval($_GET['inspection_id']) : 0;

if ($inspectionId === 0) {
    die('Inspection ID is required.');
}

$query = "
    SELECT 
        bd.building_name,
        b.district,
        b.barangay,
        b.business_name,
        b.occupancy_type,
        o.owner_name,
        o.contact_number,
        b.business_nature,
        i.status
    FROM tbl_inspections i
    INNER JOIN tbl_applications r ON i.application_id = r.application_id
    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
    INNER JOIN tbl_buildings bd ON r.building_id = bd.building_id
    WHERE i.inspection_id = ?
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("i", $inspectionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('No data found for inspection ID: ' . $inspectionId);
}

$row = $result->fetch_assoc();

// Assign retrieved values to variables
$buildingName = $row['building_name'];
$businessAddress = $row['district'] . ', ' . $row['barangay'];
$businessName = $row['business_name'];
$occupancyType = $row['occupancy_type'];
$ownerName = $row['owner_name'];
$contactNumber = $row['contact_number'];
$businessNature = $row['business_nature'];
$status = $row['status']; // Fetch the status

// Generate FSIC number and FSEC number

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Big Business Inspection Checklist</title>
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <style>
        input[type="radio"] {
            display: inline-block;
            margin: 0;
        }
    </style>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Only apply to text inputs within .section5 */
        .section5 input[type='text'] {
            width: 90%;
        }

        .section5 input[type='radio'] {
            margin: 0 10px;
        }

        .section5 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
    </style>
    <style>
        .section6 table {
            width: 100%;
            border-collapse: collapse;
        }

        .section6 table,
        th,
        td {
            border: 1px solid black;
        }

        .section6 th,
        td {
            padding: 8px;
            text-align: left;
        }

        .section6 th {
            background-color: #f2f2f2;
        }
    </style>


</head>

<div class="dashboard-wrapper">
    <div class="container-fluid dashboard-content">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <h5 class="card-header">Big Business Inspection Checklist</h5>
                    <div class="card-body">
                        <form id="inspectionForm" method="POST">
                            <input type="hidden" name="inspection_id" value="<?php echo $inspectionId; ?>">
                            <input type="hidden" id="inspectionStatus" value="<?php echo htmlspecialchars($status); ?>">

                            <div id="section1">
                                <!-- I. REFERENCE -->
                                <div class="section">
                                    <h2>I. REFERENCE</h2><br>
                                    <label for="order_no">Inspection Order No:</label>
                                    <input type="text" style="margin-right: 110px;" id="order_no" name="order_no"><br>

                                    <label for="date_issued">Date Issued:</label>
                                    <input type="date" style="margin-right: 110px;" id="date_issued"
                                        name="date_issued"><br>

                                    <label for="date_inspected">Date Inspected:</label>
                                    <input type="date" style="margin-right: 110px;" id="date_inspected"
                                        name="date_inspected"><br>
                                </div><br>

                                <!-- II. NATURE OF INSPECTION CONDUCTED -->
                                <div class="section">
                                    <h2>II. NATURE OF INSPECTION CONDUCTED</h2><br>


                                    <input type="radio" name="inspection_type[]" value="construction" id="construction"
                                        class="single-checkbox">
                                    <label for="construction">Inspection during construction</label><br>

                                    <input type="radio" name="inspection_type[]" value="PEZA" id="PEZA"
                                        class="single-checkbox">
                                    <label for="PEZA">FSIC for Certificate of Annual Inspection
                                        (PEZA)</label><br>


                                    <input type="radio" name="inspection_type[]" value="fsic_occupancy">
                                    <label for="fsic_occupancy" id="fsic_occupancy" class="single-checkbox">FSIC for
                                        Certificate for Occupancy</label><br>

                                    <input type="radio" name="inspection_type[]" value="verification" id="verification"
                                        class="single-checkbox">
                                    <label for="verification"> Verification Inspection for
                                        Compliance</label><br>
                                    <input type="radio" name="inspection_type[]" value="fsic_new" id="fsic_new"
                                        class="single-checkbox">
                                    <label for="fsic_new"> FSIC for
                                        Business Permit (New)</label><br>

                                    <input type="radio" name="inspection_type[]" value="ntc" id="ntc"
                                        class="single-checkbox">
                                    <label for="ntc"> NTC /</label>
                                    <input type="radio" name="inspection_type[]" value="ntcv" id="ntcv"
                                        class="single-checkbox">
                                    <label for="ntcv"> NTCV /</label>
                                    <input type="radio" name="inspection_type[]" value="abatement" id="abatement"
                                        class="single-checkbox">
                                    <label for="abatement"> Abatement / </label>
                                    <input type="radio" name="inspection_type[]" value="closure" id="closure"
                                        class="single-checkbox">
                                    <label for="closure"> Closure </label><br>

                                    <input type="radio" name="inspection_type[]" value="fsic_renewal">
                                    <label for="fsic_renewal" id="fsic_renewal" class="single-checkbox"> FSIC for
                                        Business Permit (Renewal)</label><br>

                                    <input type="radio" name="inspection_type[]" value="others">
                                    Others (Specify):
                                    <input type="text" name="others"><br><br>
                                </div>

                                <div class="section">
                                    <h2>III. REQUIREMENTS</h2><br>

                                    <input type="radio" name="occufsic" value="occufsic" id="occufsic"
                                        class="single-checkbox">
                                    <label for="occufsic">FSIC for Occupancy</label><br>

                                    <label for="FSCCR" style="margin-left: 110px; ">Fire Safety Compliance and
                                        Commissioning Report(FSCCR)(if applicable)</label>
                                    <input type="radio" name="FSCCR" value="yes" id="yes" class="single-checkbox"> Yes /
                                    <input type="radio" name="FSCCR" value="no" id="no" class="single-checkbox"> No
                                    <br>

                                    <input type="radio" name="NRAOfsec" value="NRAOfsec" id="NRAOfsec"
                                        class="single-checkbox">
                                    <label for="NRAOfsec">FSIC for New / Renewal/ Annual Inspection / Others:
                                    </label><br>

                                    <label for="FSMR" style="margin-left: 110px; ">Fire Safety Maintenance
                                        Report(FSMR)(if applicable)</label>
                                    <input type="radio" name="FSMR" value="yes" id="yes" class="single-checkbox"> Yes /
                                    <input type="radio" name="FSMR" value="no" id="no" class="single-checkbox"> No<br>
                                </div>
                                <button type="button" onclick="nextSection(2)" class="btn btn-primary">Next</button>
                            </div>

                            <div id="section2" style="display:none;">
                                <div class="section">
                                    <h2>IV. GENERAL INFORMATION</h2>
                                    <br>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="business_name">Business Name:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="business_name"
                                                value="<?php echo htmlspecialchars($businessName); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="building_name">Building Name:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="building_name"
                                                value="<?php echo htmlspecialchars($buildingName); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="business_address">Business Address:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="business_address"
                                                value="<?php echo htmlspecialchars($businessAddress); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="occupancy_type">Occupancy Type:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="occupancy_type"
                                                value="<?php echo htmlspecialchars($occupancyType); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="owner_name">Owner Name:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="owner_name"
                                                value="<?php echo htmlspecialchars($ownerName); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="contact_number">Contact Number:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="contact_number"
                                                value="<?php echo htmlspecialchars($contactNumber); ?>" readonly>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="business_nature">Business Nature:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="business_nature"
                                                value="<?php echo htmlspecialchars($businessNature); ?>" readonly>
                                        </div>
                                    </div>

                                    <input type="radio" name="GIoccufsic" value="GIoccufsic" id="GIoccufsic"
                                        class="single-checkbox">
                                    <label for="GIoccufsic">FSIC for Occupancy</label><br>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="fsec_number">FSEC No:</label>
                                            <input type="text" class="form-control" id="fsec_number" name="fsec_number">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="fsec_date_issued">Date Issued:</label>
                                            <input type="date" class="form-control" id="fsec_date_issued"
                                                name="fsec_date_issued">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="bpermit_number">Building Permit</label>
                                            <input type="text" class="form-control" id="bpermit_number"
                                                name="bpermit_number">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="bp_date_issued">Date Issued:</label>
                                            <input type="date" class="form-control" id="bp_date_issued"
                                                name="bp_date_issued">
                                        </div>
                                    </div>
                                </div>
                                <input type="radio" name="GINRAOfsec" value="GINRAOfsec" id="GINRAOfsec"
                                    class="single-checkbox">
                                <label for="GINRAOfsec">FSIC for New / Renewal/ Annual Inspection / Others:
                                </label><br>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="fsic_number">FSIC No:</label>
                                        <input type="text" class="form-control" id="fsic_number" name="fsic_number">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="fsic_date_issued">Date Issued:</label>
                                        <input type="date" class="form-control" id="fsic_date_issued"
                                            name="fsic_date_issued">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="CFD">Certificate of Fire Drill</label>
                                        <input type="text" class="form-control" id="CFD" name="CFD">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="_CFD_date_issued">Date Issued:</label>
                                        <input type="date" class="form-control" id="CFD_date_issued"
                                            name="CFD_date_issued">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="building_permit">Building/Renovation Permit:</label>
                                        <input type="text" class="form-control" id="building_permit"
                                            name="building_permit">
                                    </div>

                                    <div class="col-md-6">
                                        <label for="rp_date_issued">Date Issued:</label>
                                        <input type="date" class="form-control" id="rp_date_issued"
                                            name="rp_date_issued">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="policy_number">Fire Insurance Policy No:</label>
                                        <input type="text" class="form-control" id="policy_number" name="policy_number">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="pol_date_issued">Date Issued:</label>
                                        <input type="date" class="form-control" id="pol_date_issued"
                                            name="pol_date_issued">
                                    </div>
                                </div>


                                <button type="button" onclick="nextSection(1)"
                                    class="btn btn-secondary">Previous</button>
                                <button type="button" onclick="nextSection(3)" class="btn btn-primary">Next</button>
                            </div>


                            <div id="section3" style="display:none;">
                                <div class="section">
                                    <h2>CONTRUCTION TYPE</h2>

                                    <input type="radio" name="construction_type[]" value="TypeI" id="TypeI"
                                        class="single-checkbox">
                                    <label for="TypeI">Type I : Concrete & Steel (Fire Resistive) </label><br>

                                    <input type="radio" name="construction_type[]" value="TypeII" id="TypeII"
                                        class="single-checkbox">
                                    <label for="TypeII">Type II : Concrete & Exposed Steel (Noncombustible)</label><br>

                                    <input type="radio" name="construction_type[]" value="TypeIII">
                                    <label for="TypeIII" id="TypeIII" class="single-checkbox">Type III : Concrete & Wood
                                        (Ordinary)</label><br>

                                    <input type="radio" name="construction_type[]" value="TypeIV" id="TypeIV"
                                        class="single-checkbox">
                                    <label for="TypeIV"> Type IV : Heavy Timber (Large masss wood)</label><br>

                                    <input type="radio" name="construction_type[]" value="TypeV" id="TypeV"
                                        class="single-checkbox">
                                    <label for="TypeV"> Type V : Wood Frame (Lightweight wood) </label><br>
                                </div>

                                <div class="section">
                                    <br>
                                    <h2>WALLS/CEILING INTERIOR FINISH</h2>

                                    <input type="radio" name="Wall_type[]" value="ClassA" id="ClassA"
                                        class="single-checkbox">
                                    <label for="ClassA">Class A : Flame spread index, 0-25;smoke developed index, 0-450
                                    </label><br>

                                    <input type="radio" name="Wall_type[]" value="ClassB" id="ClassB"
                                        class="single-checkbox">
                                    <label for="ClassB">Class B : Flame spread index, 26-75;smoke developed index,
                                        0-450</label><br>

                                    <input type="radio" name="Wall_type[]" value="ClassC">
                                    <label for="ClassC" id="ClassC" class="single-checkbox">Class C : Flame spread
                                        index, 76-200;smoke developed index, 0-450label><br>
                                </div>

                                <div class="section">
                                    <br>
                                    <h2>FLOOR INTERTIOR FINISH</h2>

                                    <input type="radio" name="Floor_type[]" value="ClassI" id="ClassI"
                                        class="single-checkbox">
                                    <label for="ClassI">Class I : Critical radiant flux, not less than 0.45 W/cm2
                                    </label><br>

                                    <input type="radio" name="Floor_type[]" value="ClassII" id="ClassII"
                                        class="single-checkbox">
                                    <label for="ClassII">Class II : Critical radiant flux, not more than 0.22 W/cm2, not
                                        less than 0.45 W/cm2 </label><br>

                                </div><br>

                                <button type="button" onclick="nextSection(2)"
                                    class="btn btn-secondary">Previous</button>
                                <button type="button" onclick="nextSection(4)" class="btn btn-primary">Next</button>
                            </div>


                            <div id="section4" style="display:none;">
                                <div class="section">
                                    <h2>SECTIONAL OOCUPANCY (INDICATE SPECIFIC USAGE OF EACH FLOOR, PART OR PORTION OF
                                        THE BUILDING)</h2>
                                    <br>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="Basement">Basement:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="Basement" id="Basement">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="Ground_Floor">Ground Floor:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="Ground_Floor"
                                                id="Ground_Floor">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="Second_Floor">Second Floor:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="Second_Floor"
                                                id="Second_Floor">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="Third_Floor">Third_Floor:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="Third_Floor" id="Third_Floor">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label for="Nth_Floor">Nth Floor:</label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" name="Nth_Floor" id="Nth_Floor">
                                        </div>
                                    </div>

                                    <div class="section">
                                        <h2>OTHER INFORMATION</h2><br>


                                        <label for="occupant_load">Maximum Occupant Load:</label>
                                        <input type="number" id="occupant_load" name="occupant_load">

                                        <label for="Stories_num" style="margin-left: 110px; ">No of Stories:</label>
                                        <input type="number" id="Stories_num" name="Stories_num"><br>

                                        <label for="building_height">Building Height:</label>
                                        <input type="number" id="building_height" name="building_height">
                                        m

                                        <label for="mezzanine" style="margin-left: 110px; ">With Mezzanine:</label>
                                        <input type="radio" name="mezzanine_type[]" value="yes" id="yes"
                                            class="single-checkbox"> Yes /
                                        <input type="radio" name="mezzanine_type[]" value="no" id="no"
                                            class="single-checkbox"> No

                                    </div><br>

                                    <button type="button" onclick="nextSection(3)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(5)" class="btn btn-primary">Next</button>
                                </div>
                            </div>

                            <div id="section5" style="display:none;">
                                <div class="section">

                                    <h2>V. Means of Egress Section </h2>
                                    <th colspan="4">A. EXIT ACCESS</th><br>

                                    <input type="radio" name="GOC_type[]" value="Doors" id="Doors"
                                        class="single-checkbox">
                                    <label for="Doors"> Doors /</label>
                                    <input type="radio" name="GOC_type[]" value="Corridors" id="Corridors"
                                        class="single-checkbox">
                                    <label for="Corridors"> Corridors /</label>
                                    <input type="radio" name="GOC_type[]" value="Hallways" id="Hallways"
                                        class="single-checkbox">
                                    <label for="Hallways"> Hallways / </label>
                                    <input type="radio" name="GOC_type[]" value="Passageways" id="Passageways"
                                        class="single-checkbox">
                                    <label for="Passageways"> Passageways / </label>
                                    <input type="radio" name="GOC_type[]" value="Anterooms" id="Anterooms"
                                        class="single-checkbox">
                                    <label for="Anterooms"> Anterooms /</label>
                                    <input type="radio" name="GOC_type[]" value="Ramps" id="Ramps"
                                        class="single-checkbox">
                                    <label for="Ramps"> Ramps /</label><br>

                                    <table border="1" cellpadding="5" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Horizontal Components</th>
                                                <th>Actual Dimensions (m)</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                                <th>Remarks / Corrective Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Doors</td>
                                            <td><input type='number' name='Doorsdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='Doors' value='passed' /></td>
                                            <td><input type='radio' name='Doors' value='failed' /></td>
                                            <td><input type='text' name='Doorsremarks[]' /></td>
                                        </tr>
                                        <tr>
                                            <td>Corridors / Hallways</td>
                                            <td><input type='number' name='CHdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='CH' value='passed' /></td>
                                            <td><input type='radio' name='CH' value='failed' /></td>
                                            <td><input type='text' name='CHremarks[]' /></td>
                                        </tr>
                                        <tr>
                                            <td>Passageways</td>
                                            <td><input type='number' name='Passagewaysdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='Passageways' value='passed' /></td>
                                            <td><input type='radio' name='Passageways' value='failed' /></td>
                                            <td><input type='text' name='Passagewaysremarks[]' /></td>
                                        </tr>
                                        <tr>
                                            <td>Lobby / Anteroom</td>
                                            <td><input type='number' name='LAdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='LA' value='passed' /></td>
                                            <td><input type='radio' name='LA' value='failed' /></td>
                                            <td><input type='text' name='LAremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Ramps</td>
                                            <td><input type='number' name='Rampsdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='Ramps' value='passed' /></td>
                                            <td><input type='radio' name='Ramps' value='failed' /></td>
                                            <td><input type='text' name='Rampsremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Common path of travel</td>
                                            <td><input type='number' name='CPTdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='CPT' value='passed' /></td>
                                            <td><input type='radio' name='CPT' value='failed' /></td>
                                            <td><input type='text' name='CPTremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Dead end</td>
                                            <td><input type='number' name='Deadenddimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='Deadend' value='passed' /></td>
                                            <td><input type='radio' name='Deadend' value='failed' /></td>
                                            <td><input type='text' name='Deadendremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Travel distance</td>
                                            <td><input type='number' name='TDdimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='TD' value='passed' /></td>
                                            <td><input type='radio' name='TD' value='failed' /></td>
                                            <td><input type='text' name='TDremarks[]'/></td>
                                        </tr>
                                        </tbody>
                                    </table><br>

                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Description</th>
                                                <th>Actual Dim. (m)</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Any door leaf in a means of egress shall leave not less than one-half of the required width of an aisle, a corridor, a passageway, or a landing unobstructed.</td>
                                            <td><input type='number' name='EA1dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='EA1' value='passed' /></td>
                                            <td><input type='radio' name='EA1' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Any door leaf in a means of egress shall not project more than 180 mm into the required width of an aisle, a corridor, a passageway, or a landing, unless the door leaf is equipped with an approved self-closing device.</td>
                                            <td><input type='number' name='EA2dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='EA2' value='passed' /></td>
                                            <td><input type='radio' name='EA2' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>At least two (2) means of egress for each room with occupant load ≥ 50 or with hazard content.</td>
                                            <td><input type='number' name='EA3dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='EA3' value='passed' /></td>
                                            <td><input type='radio' name='EA3' value='failed' /></td>
                                        </tr>  
                                        <tr>
                                            <td>Each guest door used as means of egress shall at least 20 minutes fire resistant.</td>
                                            <td><input type='number' name='EA4dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='EA4' value='passed' /></td>
                                            <td><input type='radio' name='EA4' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Doors that open directly onto exit access corridors shall be self-closing and self-latching.</td>
                                            <td></td>
                                            <td><input type='radio' name='EA5' value='passed' /></td>
                                            <td><input type='radio' name='EA5' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>There shall be no openings in corridor partitions other than door openings.</td>
                                            <td></td>
                                            <td><input type='radio' name='EA6' value='passed' /></td>
                                            <td><input type='radio' name='EA6' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Free from any obstruction.</td>
                                            <td></td>
                                            <td><input type='radio' name='EA7' value='passed' /></td>
                                            <td><input type='radio' name='EA7' value='failed' /></td>
                                        </tr> 
                                         <tr>
                                            <td>No flammable material stored.</td>
                                            <td></td>
                                            <td><input type='radio' name='EA8' value='passed' /></td>
                                            <td><input type='radio' name='EA8' value='failed' /></td>
                                        </tr>
                                        </tbody>
                                    </table><br>
                                    <button type="button" onclick="nextSection(4)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(6)" class="btn btn-primary">Next</button>
                                </div>
                            </div>


                            <div id="section6" style="display:none;">
                                <div class="section">
                                    <h2>B. EXITS</h2>

                                    <!-- Stairs Options -->
                                    <label><input type="Radio" name="exits[]" value="Normal Stairs"> Normal
                                        Stairs</label> /
                                    <label><input type="Radio" name="exits[]" value="Curved Stairs"> Curved
                                        Stairs</label> /
                                    <label><input type="Radio" name="exits[]" value="Spiral Stairs"> Spiral
                                        Stairs</label> /
                                    <label><input type="Radio" name="exits[]" value="Winding Stairs"> Winding
                                        Stairs</label>
                                    <br>

                                    <!-- Horizontal and Outside Stairs Options -->
                                    <label><input type="Radio" name="exits1[]" value="Horizontal Exits"> Horizontal
                                        Exits</label> /
                                    <label><input type="Radio" name="exits1[]" value="OSEF"> Outside
                                        Stairs / Exit Passageways / Fire Escape Stairs</label>
                                    <br>

                                    <!-- Fire Escape Ladder -->
                                    <label><input type="Radio" name="exits3[]" value="Fire Escape Ladder"> Fire Escape
                                        Ladder (for 1 & 2 family dwelling only)</label>
                                    <br>

                                    <!-- Slide Escape -->
                                    <label><input type="Radio" name="exits4[]" value="Slide Escape"> Slide Escape (for
                                        Industrial Occupancy Only)</label>
                                    <br>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Components</th>
                                                <th>Clear Width (m)</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                                <th>Remarks / Corrective Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Exits Doors</td>
                                            <td><input type='text' name='EDclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='ED' value='passed' /></td>
                                            <td><input type='radio' name='ED' value='failed' /></td>
                                            <td><input type='text' name='EDremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Normal Stairs</td>
                                            <td><input type='text' name='NSclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='NS' value='passed' /></td>
                                            <td><input type='radio' name='NS' value='failed' /></td>
                                            <td><input type='text' name='NSremarks[]'/></td>
                                        </tr>    
                                         <tr>
                                            <td>Curve Stairs</td>
                                            <td><input type='text' name='CSclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='CS' value='passed' /></td>
                                            <td><input type='radio' name='CS' value='failed' /></td>
                                            <td><input type='text' name='CSremarks[]'/></td>
                                        </tr>   
                                          <tr>
                                            <td>Winding Stairs</td>
                                            <td><input type='text' name='WSclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='WS' value='passed' /></td>
                                            <td><input type='radio' name='WS' value='failed' /></td>
                                            <td><input type='text' name='WSremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Horizontal Exits</td>
                                            <td><input type='text' name='HEclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='HE' value='passed' /></td>
                                            <td><input type='radio' name='HE' value='failed' /></td>
                                            <td><input type='text' name='HEremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Outside Stairs</td>
                                            <td><input type='text' name='OSclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='OS' value='passed' /></td>
                                            <td><input type='radio' name='OS' value='failed' /></td>
                                            <td><input type='text' name='OSremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Exit Passageways</td>
                                            <td><input type='text' name='EPclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='EP' value='passed' /></td>
                                            <td><input type='radio' name='EP' value='failed' /></td>
                                            <td><input type='text' name='EPremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Fire Escape Stairs</td>
                                            <td><input type='text' name='FESclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='FES' value='passed' /></td>
                                            <td><input type='radio' name='FES' value='failed' /></td>
                                            <td><input type='text' name='FESremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Fire Escape Ladders</td>
                                            <td><input type='text' name='FELclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='FEL' value='passed' /></td>
                                            <td><input type='radio' name='FEL' value='failed' /></td>
                                            <td><input type='text' name='FELremarks[]'/></td>
                                        </tr>
                                        <tr>
                                            <td>Fire Escape Ladders</td>
                                            <td><input type='text' name='SEclear_width[]' placeholder='m' /></td>
                                            <td><input type='radio' name='SE' value='passed' /></td>
                                            <td><input type='radio' name='SE' value='failed' /></td>
                                            <td><input type='text' name='SEremarks[]'/></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <br />

                                    <button type="button" onclick="nextSection(5)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(7)" class="btn btn-primary">Next</button>
                                </div>
                            </div>


                            <div id="section7" style="display:none;">
                                <div class="section">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Description</th>
                                                <th>Actual Dim.</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>At least two (2) means of egress for each floor.</td>
                                            <td><input type='text'  name='ED1dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED1' value='passed' /></td>
                                            <td><input type='radio' name='ED1' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Doors assembly: 60 minutes fire resistant for three (3) communicating levels and below.</td>
                                            <td><input type='text'  name='ED2dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED2' value='passed' /></td>
                                            <td><input type='radio' name='ED2' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Doors assembly: 90 minutes fire resistant for four (4) communicating levels and above.</td>
                                            <td><input type='text'  name='ED3dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED3' value='passed' /></td>
                                            <td><input type='radio' name='ED3' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Exits Doors provided with Re-entry mechanism at every four (4) storey.</td>
                                            <td><input type='text'  name='ED4dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED4' value='passed' /></td>
                                            <td><input type='radio' name='ED4' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Stair tread: Minimum depth = 280 mm.</td>
                                            <td><input type='text'  name='ED5dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED5' value='passed' /></td>
                                            <td><input type='radio' name='ED5' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Stair riser: Minimum / Maximum height = 100 mm / 180 mm.</td>
                                            <td><input type='text'  name='ED6dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED6' value='passed' /></td>
                                            <td><input type='radio' name='ED6' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Minimum stair head room: 2000 mm.</td>
                                            <td><input type='text'  name='ED7dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED7' value='passed' /></td>
                                            <td><input type='radio' name='ED7' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Stair Provided with Guards and Handrails.</td>
                                            <td><input type='text'  name='ED8dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED8' value='passed' /></td>
                                            <td><input type='radio' name='ED8' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Maximum handrails projections: 114 mm.</td>
                                            <td><input type='text'  name='ED9dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED9' value='passed' /></td>
                                            <td><input type='radio' name='ED9' value='failed' /></td>
                                        </tr>         
                                        <tr>           
                                            <td>Stair landing shall not be less than the required width of exit door.</td>
                                            <td><input type='text' name='ED10dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='ED10' value='passed' /></td>
                                            <td><input type='radio' name='ED10' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Exits doors open and close properly.</td>
                                            <td></td>
                                            <td><input type='radio' name='ED11' value='passed' /></td>
                                            <td><input type='radio' name='ED11' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Doors swing in direction of egress.</td>
                                            <td></td>
                                            <td><input type='radio' name='ED12' value='passed' /></td>
                                            <td><input type='radio' name='ED12' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Exit Doors provided with panic hardware, vision panel, and self-closing mechanism.</td>
                                            <td></td>
                                            <td><input type='radio' name='ED13' value='passed' /></td>
                                            <td><input type='radio' name='ED13' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>There shall be no enclosed usable space under the stairs in an exit enclosure nor shall the open space under such stairs be used for any purpose.</td>
                                            <td></td>
                                            <td><input type='radio' name='ED14' value='passed' /></td>
                                            <td><input type='radio' name='ED14' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Interior finish: Class B</td>
                                            <td></td>
                                            <td><input type='radio' name='ED15' value='passed' /></td>
                                            <td><input type='radio' name='ED15' value='failed' /></td>
                                        </tr>
                                     </tbody>
                                    </table><br>
                                    <th colspan="4">C. EXIT DISCHARGE</th><br>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Description</th>
                                                <th>Actual Dim.</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Remoteness of exit discharge not less than 1/2 of length of the overall dimension of the building or area to be served.</td>
                                            <td><input type='text'  name='C1dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='C1' value='passed' /></td>
                                            <td><input type='radio' name='C1' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Remoteness of exit discharge not less than 1/3 of length of the overall dimension of the building or area to be served is protected throughout by ASASS.</td>
                                            <td><input type='text'  name='C2dimensions[]' placeholder='__ m' required /></td>
                                            <td><input type='radio' name='C2' value='passed' /></td>
                                            <td><input type='radio' name='C2' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Exterior grounds are kept clear of objects that might impede evacuation or firefighting equipment.</td>
                                            <td></td>
                                            <td><input type='radio' name='C3' value='passed' /></td>
                                            <td><input type='radio' name='C3' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>Terminate directly at a public way or at an exterior exit discharge.</td>
                                            <td></td>
                                            <td><input type='radio' name='C4' value='passed' /></td>
                                            <td><input type='radio' name='C4' value='failed' /></td>
                                        </tr>
                                        </tbody>
                                    </table><br>
                                    <button type="button" onclick="nextSection(6)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(8)" class="btn btn-primary">Next</button>
                                </div>
                            </div>


                            <div id="section8" style="display:none;">
                                <div class="section"></div>
                                <h3>VI. SIGNS, LIGHTNING AND EXITS SIGNAGE</h3>
                                <th colspan="4">A. MARKINGS OF MEANS OF EGRESS(Exit)</th><br>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Actual Dim.</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Minimum letter height, 150 mm</td>
                                            <td><input type='text' name='actual_dim[]' placeholder='Actual Dim.' /></td>
                                            <td><input type='radio' name='status_A_0' value='passed' /></td>
                                            <td><input type='radio' name='status_A_0' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>EXIT signs are posted along Exit access, Exits and Exit discharge</td>
                                            <td><input type='text' name='actual_dim[]' placeholder='Actual Dim.' /></td>
                                            <td><input type='radio' name='status_A_1' value='passed' /></td>
                                            <td><input type='radio' name='status_A_1' value='failed' /></td>
                                        </tr>
                                        <tr>
                                            <td>EXIT signs are properly illuminated</td>
                                            <td><input type='text' name='actual_dim[]' placeholder='Actual Dim.' /></td>
                                            <td><input type='radio' name='status_A_2' value='passed' /></td>
                                            <td><input type='radio' name='status_A_2' value='failed' /></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <br>

                                <th colspan="4">B. MARKINGS OF MEANS OF EGRESS(Emergency Evaluation Plan)</th>

                                <br>
                                <!-- New section from the uploaded image -->
                                <table>
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                    </thead>
                                    <tr>
                                        <td>Posted on strategic and conspicuous location inside the building</td>
                                        <td><input type="radio" name="location_status" value="Passed"></td>
                                        <td><input type="radio" name="location_status" value="Failed"></td>
                                    </tr>
                                    <tr>
                                        <td> Drawn with a photo-luminescent background to be readable in case of power
                                            failure.
                                            <br>
                                            Containing the following basic information:
                                            <br>
                                            1. "You Are Here"/ room number/ building/ marking
                                            <br>
                                            2. Fire Exits
                                            <br>
                                            3. Primary Route to Exit (Nearest to the viewer)
                                            <br>
                                            4. Secondary Route to Exit (Second nearest to the viewer)
                                            <br>
                                            5. Fire alarm pull stations and annunciators
                                            <br>
                                            6. Fire extinguishers/ hose cabinets
                                            <br>
                                            7. Emergency Light
                                            <br>
                                            8. First Aid Kit locations (if applicable)
                                            <br>
                                            9. Emergency Call stations (if applicable)
                                            <br>
                                            10. Areas of safe refuge (for high-rise buildings)
                                            <br>
                                            11. Assembly areas instructions
                                            <br>
                                            12. "In Case of Emergency" instructions
                                        </td>
                                        <td><input type="radio" name="location_status1" value="Passed"></td>
                                        <td><input type="radio" name="location_status1" value="Failed"></td>
                                    </tr>
                                </table>

                                <table>
                                    <tr>
                                        <th></th>
                                        <th>Actual Dimension</th>
                                        <th>Passed</th>
                                        <th>Failed</th>
                                    </tr>

                                    <!-- Size 330.2 mm wide x 215.9 mm height -->
                                    <tr>
                                        <td>Emergency Evacuation Plan:<br>
                                            <input type="radio" name="215.9mm" value="215.9mm"> 330.2 mm wide x 215.9 mm
                                            height (Floor area < 50 m²) <br>
                                                <li>Room or Spaces</li>
                                        </td>
                                        <td><input type="text" name="actual_dim1"></td>
                                        <td><input type="radio" name="status1" value="Passed"></td>
                                        <td><input type="radio" name="status1" value="Failed"></td>
                                    </tr>

                                    <!-- Size 609.6 mm wide x 457.2 mm height -->
                                    <tr>
                                        <td>
                                            <input type="radio" name="457.2mm" value="457.2mm"> 609.6 mm wide x 457.2 mm
                                            height (Floor area = 50 – 150 m²)
                                            <li>Room or Spaces</li>
                                            <li>Building lobbies upon entry</li>
                                            <li>Elevator lobbies at every floor</li>
                                            <li>Hallways and corridors</li>
                                            <li>On every bend/corner Or every 25m interval in the case of long hallway.
                                            </li>

                                        </td>
                                        <td><input type="text" name="actual_dim2"></td>
                                        <td><input type="radio" name="status2" value="Passed"></td>
                                        <td><input type="radio" name="status2" value="Failed"></td>
                                    </tr>

                                    <!-- Size 609.6 mm wide x 914.4 mm height -->
                                    <tr>
                                        <td>
                                            <input type="radio" name="914.4mm"" value=" 914.4mm"> 609.6 mm wide x 914.4
                                            mm height (Floor area ≈ 151 m²)
                                            <li>Room or Spaces</li>
                                            <li>Upon entry of building</li>
                                            <li>Area of assembly or every 25mm interval in the case auditorium &
                                                gymnasium.</li>
                                            <br>
                                            Symbols/icons/logos to be used for the marking shall be in<br>
                                            accordance with NFPA 170, Standard for Signs and Symbols.
                                        </td>
                                        <td><input type="text" name="actual_dim3"></td>
                                        <td><input type="radio" name="status3" value="Passed"></td>
                                        <td><input type="radio" name="status3" value="Failed"></td>
                                    </tr>
                                </table>

                                <th colspan="4">C. ILLUMINATION OF MEANS OF EGRESS<br> (All Data Below Shall be Referred
                                    from Manufacturers Specifications)</th>

                                <table>
                                    <tr>
                                        <th></th>
                                        <th>Actual Lux/Time</th>
                                        <th>Passed</th>
                                        <th>Failed</th>
                                    </tr>
                                    <tr>
                                        <td>Floors and other walking surfaces: shall be at least 1 ft-candle (10.8 lux),
                                            measured at the floor.</td>
                                        <td><input type="text" name="lux_time_1" placeholder="Enter Lux/Time"></td>
                                        <td><input type="radio" name="result_1" value="passed"></td>
                                        <td><input type="radio" name="result_1" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>In assembly occupancies: walking surfaces of exit access shall be at least
                                            0.2 ft-candle (2.2 lux).</td>
                                        <td><input type="text" name="lux_time_2" placeholder="Enter Lux/Time"></td>
                                        <td><input type="radio" name="result_2" value="passed"></td>
                                        <td><input type="radio" name="result_2" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>Stairs: shall be at least 10 ft-candle (108 lux), measured at the walking
                                            surfaces.</td>
                                        <td><input type="text" name="measurement_stairs"
                                                placeholder="Enter Measurement"></td>
                                        <td><input type="radio" name="result_stairs" value="passed"></td>
                                        <td><input type="radio" name="result_stairs" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Emergency Lighting:
                                            <br>
                                            <input type="radio" name="10.8lux" value="10.8lux"> Illumination not less
                                            than an average of 1 ft-candle (10.8 lux) and, at
                                            any point, not less than 0.1 ft-candle (1.1 lux), measured along the path of
                                            egress at floor level.
                                        </td>
                                        <td><input type="text" name="measurement_lighting"
                                                placeholder="Enter Measurement"></td>
                                        <td><input type="radio" name="result_lighting" value="passed"></td>
                                        <td><input type="radio" name="result_lighting" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type="radio" name="1.5-hour" value="1.5-hour"> Emergency lighting
                                            system shall be arranged to provide the required
                                            illumination automatically in the event of any interruption of normal
                                            lighting (e.g., failure of a public utility, etc.) for a period of at least
                                            1.5-hour.
                                        </td>
                                        <td><input type="text" name="measurement_system"
                                                placeholder="Enter Measurement"></td>
                                        <td><input type="radio" name="result_system" value="passed"></td>
                                        <td><input type="radio" name="result_system" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type="radio" name="Writtenrecord" value="Writtenrecord">Periodic
                                            Testing of Emergency Lighting Equipment (Written record).
                                        </td>
                                        <td><input type="text" name="measurement_testing"
                                                placeholder="Enter Measurement"></td>
                                        <td><input type="radio" name="result_testing" value="passed"></td>
                                        <td><input type="radio" name="result_testing" value="failed"></td>
                                    </tr>
                                </table>
                                <br>

                                <button type="button" onclick="nextSection(7)"
                                    class="btn btn-secondary">Previous</button>
                                <button type="button" onclick="nextSection(9)" class="btn btn-primary">Next</button>
                            </div>

                            <div id="section9" style="display:none;">
                                <div class="section"></div>

                                <h2>VII. Hazard</h2>
                                <label for="hazard_contents">Hazard Contents:</label>
                                <input type="text" id="hazard_contents" name="hazard_contents" required>
                                <label for="quantity" style="margin-left: 180px;">Quantity (Vol / Weight):</label>
                                <input type="text" id="quantity" name="quantity" required><br><br>

                                <label for="hazard_pla">Hazard Identification Placard:</label>
                                <input type="text" id="hazard_pla" name="hazard_pla" required>
                                <label for="maq" style="margin-left: 110px;">Within MAQ:</label>
                                <input type="radio" id="maq_yes" name="maq" value="Yes" required> Yes
                                <input type="radio" id="maq_no" name="maq" value="No" required> No<br><br>



                                <label for="hazard_no">Hazard Identification No:</label>
                                <input type="text" id="hazard_no" name="hazard_no" required>
                            
                                <label for="hazard_classification">Hazard Classification:</label>
                                <input type="radio" id="hazard_low" name="hazard_classification" value="Low" required>
                                Low
                                <input type="radio" id="hazard_ordinary" name="hazard_classification" value="Ordinary"
                                    required> Ordinary
                                <input type="radio" id="hazard_high" name="hazard_classification" value="High" required>
                                High<br><br>

                                <label for="Class">Class:</label>
                                <input type="text" id="Class" name="Class" required>
                                <label for="flash_point" style="margin-left: 160px;">Flash Point:</label>
                                <input type="text" id="flash_point" name="flash_point" required><br><br>
                                <h3>Other Flammable Liquids (i.e. Alcohol, Ether, etc.)</h3>

                                <table border="1" cellpadding="10">
                                    <tr>
                                        <th>Criteria</th>
                                        <th>Passed</th>
                                        <th>Failed</th>
                                    </tr>
                                    <tr>
                                        <td>Stored in sealed metal containers</td>
                                        <td><input type="radio" id="sealed_yes" name="sealed_containers" value="Passed"
                                                required> Passed</td>
                                        <td><input type="radio" id="sealed_no" name="sealed_containers" value="Failed"
                                                required> Failed</td>
                                    </tr>
                                    <tr>
                                        <td>Properly dispensed as per SOP</td>
                                        <td><input type="radio" id="dispensed_yes" name="properly_dispensed"
                                                value="Passed" required> Passed</td>
                                        <td><input type="radio" id="dispensed_no" name="properly_dispensed"
                                                value="Failed" required> Failed</td>
                                    </tr>
                                    <tr>
                                        <td>Provided with "NO SMOKING" sign</td>
                                        <td><input type="radio" id="smoking_yes" name="no_smoking_sign" value="Passed"
                                                required> Passed</td>
                                        <td><input type="radio" id="smoking_no" name="no_smoking_sign" value="Failed"
                                                required> Failed</td>
                                    </tr>
                                </table>

                                <h3>Miscellaneous Hazards (Mechanical Equipment Room, Storage, Supply Room)</h3>

                                <table border="1" cellpadding="10">
                                    <tr>
                                        <th>Criteria</th>
                                        <th>Passed</th>
                                        <th>Failed</th>
                                    </tr>
                                    <tr>
                                        <td>All no smoking areas have adequate signs</td>
                                        <td><input type="radio" id="area_passed" name="no_smoking_area" value="Passed"
                                                required> Passed</td>
                                        <td><input type="radio" id="area_failed" name="no_smoking_area" value="Failed"
                                                required> Failed</td>
                                    </tr>

                                    <tr>
                                        <td>Gasoline/Diesel is stored in the proper place and in a metal safety can.
                                        </td>
                                        <td><input type="radio" name="result_3" value="passed"></td>
                                        <td><input type="radio" name="result_3" value="failed"></td>
                                    </tr>
                                </table>
                                <th colspan="4">C. HOUSEKEEPING, MAINTANANCE, STORAGE AND WASTE DISPOSAL</th>

                                <table>
                                    <tr>
                                        <th></th>
                                        <th>Passed</th>
                                        <th>Failed</th>
                                    </tr>
                                    <tr>
                                        <td>Brooms, mops , rags and other cleaning supplies stored in metal
                                            cabinets or approved cans</td>
                                        <td><input type="radio" name="HMSWresult_1" value="passed"></td>
                                        <td><input type="radio" name="HMSWresult_1" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>Paint, solvents and other flammables stored in metal cabinet: oily
                                            rags in metal containers </td>
                                        <td><input type="radio" name="HMSWresult_2" value="passed"></td>
                                        <td><input type="radio" name="HMSWresult_2" value="failed"></td>
                                    </tr>
                                    <tr>
                                        <td>Dry leaves, shrubbery trimmings and other combustibles kept away
                                            from buildings
                                        </td>
                                        <td><input type="radio" name="HMSWresult_3" value="passed"></td>
                                        <td><input type="radio" name="HMSWresult_3" value="failed"></td>
                                    </tr>
                                </table>
                                <br>
                                <button type="button" onclick="nextSection(8)"
                                    class="btn btn-secondary">Previous</button>
                                <button type="button" onclick="nextSection(10)" class="btn btn-primary">Next</button>
                            </div>


                            <div id="section10" style="display:none;">
                                <div class="section">
                                    <h2>VIII. Fire Protection Inspection</h2>
                                    <table>
                                        <tr>
                                            <th>Item to Inspect</th>
                                            <th>Procedure How to Inspect</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                        <tr>
                                            <td colspan="4"><strong>A. Automatic Fire Suppression System
                                                    (Sprinkler)</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Sprinkler Pumps</td>
                                            <td>Check automatic start and pressure.</td>
                                            <td><input type="radio" name="sprinkler_pumps" value="passed"></td>
                                            <td><input type="radio" name="sprinkler_pumps" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Sprinkler Valves</td>
                                            <td>Valves are locked in the open position, no leaks, corrosion, or
                                                defects noted.</td>
                                            <td><input type="radio" name="sprinkler_valves" value="passed"></td>
                                            <td><input type="radio" name="sprinkler_valves" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Sprinkler Water Flow Alarm</td>
                                            <td>Open test valve and ensure manual alarm bell functions and sprinkler
                                                pumps start.</td>
                                            <td><input type="radio" name="sprinkler_alarm" value="passed"></td>
                                            <td><input type="radio" name="sprinkler_alarm" value="failed"></td>
                                        </tr>

                                        <!-- Wet Standpipe/Fire Hose Cabinet -->
                                        <tr>
                                            <td colspan="4"><strong>B. Wet Standpipe/Fire Hose Cabinet</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Cabinet Door Operative</td>
                                            <td>Check that door is unobstructed and opens properly.</td>
                                            <td><input type="radio" name="cabinet_door" value="passed"></td>
                                            <td><input type="radio" name="cabinet_door" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Hose Condition</td>
                                            <td>Check that hose is not rotted, wet, moldy, etc.</td>
                                            <td><input type="radio" name="hose_condition" value="passed"></td>
                                            <td><input type="radio" name="hose_condition" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Nozzle</td>
                                            <td>Check that nozzle is in place and operates correctly.</td>
                                            <td><input type="radio" name="nozzle" value="passed"></td>
                                            <td><input type="radio" name="nozzle" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Hose Hung Properly</td>
                                            <td>Check that hose is hung properly so it can easily be unrolled if
                                                needed.</td>
                                            <td><input type="radio" name="hose_hung" value="passed"></td>
                                            <td><input type="radio" name="hose_hung" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Valves and Valve Handles</td>
                                            <td>Check that valve handles are in place and that valves operate
                                                properly and are in the open position.</td>
                                            <td><input type="radio" name="valves_handles" value="passed"></td>
                                            <td><input type="radio" name="valves_handles" value="failed"></td>
                                        </tr>

                                        <!-- Fire Pump -->
                                        <tr>
                                            <td colspan="4"><strong>C. Fire Pump</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Pump System</td>
                                            <td>Inspect accuracy of pressure gauges and sensors.</td>
                                            <td><input type="radio" name="pump_system" value="passed"></td>
                                            <td><input type="radio" name="pump_system" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Pippings</td>
                                            <td>Check Pippins if there is leaks.</td>
                                            <td><input type="radio" name="pippings" value="passed"></td>
                                            <td><input type="radio" name="pippings" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Motor</td>
                                            <td>Check unusual noise or vibrations.</td>
                                            <td><input type="radio" name="motor" value="passed"></td>
                                            <td><input type="radio" name="motor" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Electrical System</td>
                                            <td>Check if there is corrosion in PCBs, cracked cable/wire insulation,
                                                leak in plumbing parts, signs of water in the electrical part.</td>
                                            <td><input type="radio" name="electrical_system" value="passed"></td>
                                            <td><input type="radio" name="electrical_system" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Valves and valve handles</td>
                                            <td>Check that valve handles are in place and that valves operate properly
                                                and are in the open position</td>
                                            <td><input type="radio" name="valves_in_place" value="1"></td>
                                            <td><input type="radio" name="valves_in_place" value="0"></td>
                                        </tr>

                                        <tr>
                                            <td colspan="4"><strong>D. Fire Detection System</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Fire Detection System</td>
                                            <td>Random test of call points and smoke detectors</td>
                                            <td><input type="radio" name="fire_detection" value="1"></td>
                                            <td><input type="radio" name="fire_detection" value="0"></td>
                                        </tr>

                                        <tr>
                                            <td colspan="4"><strong>E. Fire Alarm Facilities</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Location Signs</td>
                                            <td>Check all signs are in place and legible</td>
                                            <td><input type="radio" name="location_signs" value="1"></td>
                                            <td><input type="radio" name="location_signs" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Alarm Panels</td>
                                            <td>Check that all alarm panels are functioning correctly and are
                                                unobstructed</td>
                                            <td><input type="radio" name="alarm_panels" value="1"></td>
                                            <td><input type="radio" name="alarm_panels" value="0"></td>
                                        </tr>

                                        <tr>
                                            <td colspan="4"><strong>F. Lifts (Elevator)</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Lifts</td>
                                            <td>All lifts "home" to ground floor during fire test, doors open until lift
                                                stops</td>
                                            <td><input type="radio" name="lifts_home" value="1"></td>
                                            <td><input type="radio" name="lifts_home" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Lift Fans</td>
                                            <td>Check all lift fans operate correctly</td>
                                            <td><input type="radio" name="lift_fans" value="1"></td>
                                            <td><input type="radio" name="lift_fans" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Fireman’s Lift</td>
                                            <td>Fireman’s lift can be keyed to operate during fire alarm test</td>
                                            <td><input type="radio" name="fireman_lift" value="1"></td>
                                            <td><input type="radio" name="fireman_lift" value="0"></td>
                                        </tr>
                                    </table>
                                    <br>
                                    <button type="button" onclick="nextSection(9)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(11)"
                                        class="btn btn-primary">Next</button>
                                </div>
                            </div>

                            <div id="section11" style="display:none;">
                                <div class="section">
                                    <table>

                                        <tr>
                                            <td colspan="4"><strong>G. First Aid Fire Protection (Fire
                                                    Extinguishers)</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Fire Extinguisher Size</td>
                                            <td>Minimal sizes for extinguishers for listed grades of hazards</td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="1"></td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Number of Extinguishers</td>
                                            <td>The minimum number of extinguishers should meet the requirements</td>
                                            <td><input type="radio" name="num_extinguishers" value="1"></td>
                                            <td><input type="radio" name="num_extinguishers" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Location</td>
                                            <td>Extinguishers are in their proper locations</td>
                                            <td><input type="radio" name="extinguisher_location" value="1"></td>
                                            <td><input type="radio" name="extinguisher_location" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Seals & Tags</td>
                                            <td>Seals and tags are intact and extinguisher was serviced in the last 12
                                                months</td>
                                            <td><input type="radio" name="seals_tags" value="1"></td>
                                            <td><input type="radio" name="seals_tags" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Markings</td>
                                            <td>Proper marking on extinguisher to indicate the type of fire the
                                                extinguisher can be used on</td>
                                            <td><input type="radio" name="markings" value="1"></td>
                                            <td><input type="radio" name="markings" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Condition</td>
                                            <td>No leaks, corrosion or other defects noticed</td>
                                            <td><input type="radio" name="condition" value="1"></td>
                                            <td><input type="radio" name="condition" value="0"></td>
                                        </tr>
                                        <tr>
                                            <td>Pressure</td>
                                            <td>Pressure gauge reads in the "green" area</td>
                                            <td><input type="radio" name="pressure_gauge" value="1"></td>
                                            <td><input type="radio" name="pressure_gauge" value="0"></td>
                                        </tr>

                                        <tr>
                                            <td colspan="4"><strong>H. Emergency Lighting Systems</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Battery Lights</td>
                                            <td>All battery powered emergency lighting turns on when mains power is
                                                removed
                                            </td>
                                            <td><input type="radio" name="battery_lights" value="passed"> 
                                        </td>
                                            <td><input type="radio" name="battery_lights" value="failed"> </td>
                                        </tr>

                                        <tr>
                                            <td colspan="4"><strong>I. Kitchen</strong></td>
                                        </tr>
                                        <tr>
                                            <td>Hood and Vents</td>
                                            <td>Hoods, Vents, fans and ducts in good condition and free from grease</td>
                                            <td><input type="radio" name="hoods_vents" value="passed"> </td>
                                            <td><input type="radio" name="hoods_vents" value="failed"> </td>
                                        </tr>
                                        <tr>
                                            <td>Hood Filters</td>
                                            <td>Hood Filters Date of Last Cleaning</td>
                                            <td><input type="radio" name="hoods_filter" value="passed"> </td>
                                            <td><input type="radio" name="hoods_filter" value="failed"> </td>
                                        </tr>
                                    </table>
                                    <table>
                                    
                                        <tr>
                                            <th colspan="3">J. Building Service Equipment</th>
                                        </tr>
                                        <tr>
                                            <th></th>
                        
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                       
                                        <tr>
                                            <td>Utilities: Cooking equipment protected by AKHFFSS (Restaurant and
                                                similar establishment with Occupant Load > 50p)</td>
                                            <td><input type="radio" name="utilities_cooking" value="passed"> </td>
                                            <td><input type="radio" name="utilities_cooking" value="failed"> </td>
                                        </tr>

                                        <!-- Heating, Ventilating, and Air-conditioning Row -->
                                        <tr>
                                            <td>Heating, Ventilating and Air-conditioning: Design & Installation in
                                                accordance with PMEC</td>
                                            <td><input type="radio" name="hvac" value="passed"> </td>
                                            <td><input type="radio" name="hvac" value="failed"> </td>
                                        </tr>

                                        <!-- Smoke Control Systems / Smoke Management -->
                                        <tr>
                                            <th colspan="3">Smoke Control Systems / Smoke Management shall be provided
                                                in the following:</th>
                                        </tr>

                                        <tr>
                                            <td><input type="radio" name="AHR" value="AHR">All high-rise buildings
                                                (stairwells, at least 1 elevator shaft, zoned
                                                smoke control, and vestibule)
                                                <input type="radio" name="PSRA" value="PSRA">Pressurization of smoke
                                                refuge area<br>

                                                <input type="radio" name="EACM" value="EACM">Every Atrium of covered
                                                mall of over 2+ levels / Other type of occupancy
                                                over 3+ levels<br>
                                                <input type="radio" name="USWF" value="USWF">Underground structure and
                                                windowless facilities<br>

                                                <input type="radio" name="AMH" value="AMH">All movie houses<br>
                                                <input type="radio" name="AOBS" value="AOBS">All other buildings or
                                                structures with at least 1,115m² single floor
                                                area
                                            </td>
                                            <td><input type="radio" name="Smoke_Control_Systems" value="passed">
                                            </td>
                                            <td><input type="radio" name="Smoke_Control_Systems" value="failed">
                                            </td>
                                        </tr>


                                        <tr>
                                            <th colspan="3">Rubbish Chutes, Laundry Chutes, and Flue-Fed
                                                Incinerators:<br>
                                                (not applyto detached single- or two-family dwelling)</th>
                                        </tr>

                                        <tr>
                                            <td> <input type="radio" name="CIS" value="CIS">Chutes & Incinerators shall
                                                be enclosed <br>
                                                <input type="radio" name="PMEC" value="PMEC">Design and Maintained in
                                                accordance with the latest edition of PMEC
                                            </td>
                                            <td><input type="radio" name="chutes_incinerators" value="passed">
                                            </td>
                                            <td><input type="radio" name="chutes_incinerators" value="failed">
                                            </td>
                                        </tr>
                                    </table>
                                    <table>
                                        <tr>
                                            <th>Fire Wall</th>
                                            <th></th>
                                        </tr>
                                        <tr>
                                            <td>Provided with Fire Wall (minimum 2 hours fire resistance)</td>
                                            <td>
                                                <input type="radio" name="fire_wall" value="yes" required> Yes
                                                <input type="radio" name="fire_wall" value="no"> No
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>FW extension above the roof surface shall not be less than 760mm</td>
                                            <td>
                                                <input type="radio" name="fw_extension" value="yes" required> Yes
                                                <input type="radio" name="fw_extension" value="no"> No
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Wall type:
                                                <input type="radio" name="wall_type" value="125mm_solid_concrete"
                                                    required> 125mm Solid Concrete /
                                                <input type="radio" name="wall_type" value="150mm_solid_masonry"> 150mm
                                                Solid Masonry /
                                                <input type="radio" name="wall_type" value="200mm_hollow_unit_masonry">
                                                200mm Hollow Unit Masonry
                                            </td>
                                        </tr>
                                    </table>

                                    <button type="button" onclick="nextSection(10)"
                                        class="btn btn-secondary">Previous</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
            <!-- Optional JavaScript -->
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="submitbig.js"></script>
    <script>
        function nextSection(sectionNumber) {
            // Hide all sections
            document.querySelectorAll('div[id^="section"]').forEach(function (section) {
                section.style.display = 'none';
            });

            // Show the desired section
            document.getElementById('section' + sectionNumber).style.display = 'block';
        }

        function prevSection(sectionNumber) {
            nextSection(sectionNumber);
        }
    </script>


    </body>

</html>

