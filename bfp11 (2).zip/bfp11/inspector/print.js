
$('#viewDetailsModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var inspectionId = button.data('inspection-id'); // Extract inspection_id from data-* attribute
    
    // Set the inspection_id to the print button's data attribute
    $('#printButton').data('inspection-id', inspectionId);
    
    // Also populate the modal with details from the data-* attributes
    $('#modalBusinessName').text(button.data('business'));
    $('#modalBuildingName').text(button.data('building'));
    $('#modalBusinessAddress').text(button.data('address'));
    $('#modalOwnerName').text(button.data('owner'));
    $('#modalOccupancyType').text(button.data('occupancy'));
    $('#modalContactNumber').text(button.data('contact'));
    $('#modalBuildingHeight').text(button.data('buildingheight'));
    $('#modalTotalArea').text(button.data('totalarea'));
    $('#modalNumberOfFloors').text(button.data('numberoffloors'));
    $('#modalEmail').text(button.data('email'));
    $('#modalFsicexpiry').text(button.data('fsicexpiry'));
    });
    
    // Set the click event for the print button
    $('#printButton').off('click').on('click', function () {
    // Get the inspection ID from the data attribute
    var inspectionId = $(this).data('inspection-id');
    
    if (inspectionId) {
    // Construct the print URL
    var printUrl = '../ReportGen/print.php?inspection_id=' + inspectionId;
    
    // Redirect to the print URL
    window.location.href = printUrl;
    } else {
    console.log("Inspection ID not found.");
    }
    });
    