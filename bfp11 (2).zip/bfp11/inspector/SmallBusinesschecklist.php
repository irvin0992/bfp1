<?php
// Include session validation, header, sidebar, and connection files
include('../session_validate.php');
include('../header/header2.php');
include('../sidebar/sidebarinspector.php');
include('../connection.php');

// Retrieve inspection_id from URL parameter
$inspectionId = isset($_GET['inspection_id']) ? intval($_GET['inspection_id']) : 0;

if ($inspectionId === 0) {
    die('Inspection ID is required.');
}

$query = "
    SELECT 
        bd.building_name,
        bd.building_height,
        bd.total_area,
        bd.number_of_floors,
        b.district,
        b.barangay,
        b.business_name,
        b.occupancy_type,
        o.owner_name,
        o.contact_number,
        b.business_nature,
        i.status
    FROM tbl_inspections i
    INNER JOIN tbl_applications r ON i.application_id = r.application_id
    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
    INNER JOIN tbl_buildings bd ON r.building_id = bd.building_id
    WHERE i.inspection_id = ?
";


$stmt = $conn->prepare($query);
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("i", $inspectionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('No data found for inspection ID: ' . $inspectionId);
}

$row = $result->fetch_assoc();

// Assign retrieved values to variables
// Assign retrieved values to variables
$buildingName = $row['building_name'];
$buildingHeight = $row['building_height'];
$totalArea = $row['total_area'];
$numberOfFloors = $row['number_of_floors'];
$businessAddress = $row['district'] . ', ' . $row['barangay'];
$businessName = $row['business_name'];
$occupancyType = $row['occupancy_type'];
$ownerName = $row['owner_name'];
$contactNumber = $row['contact_number'];
$businessNature = $row['business_nature'];
$status = $row['status'];


// Generate FSIC number and FSEC number

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Small Business Inspection Checklist</title>
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <style>
        input[type="radio"] {
            display: inline-block;
            margin: 0;
        }
    </style>
</head>

<body>
    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <h5 class="card-header">Small Business Inspection Checklist</h5>
                        <div class="card-body">
                            <form id="inspectionForm" method="POST">
                                <input type="hidden" name="inspection_id" value="<?php echo $inspectionId; ?>">
                                <input type="hidden" id="inspectionStatus"
                                    value="<?php echo htmlspecialchars($status); ?>">
                                <!-- General Information Section -->

                                <div id="section1">
                                    <!-- I. REFERENCE -->
                                    <div class="section">
                                        <h2>I. REFERENCE</h2><br>
                                        <label for="order_no">Inspection Order No:</label>
                                        <input type="text" style="margin-right: 110px;" id="order_no"
                                            name="order_no"><br>

                                        <label for="date_issued">Date Issued:</label>
                                        <input type="date" style="margin-right: 110px;" id="date_issued"
                                            name="date_issued"><br>

                                        <label for="date_inspected">Date Inspected:</label>
                                        <input type="date" style="margin-right: 110px;" id="date_inspected"
                                            name="date_inspected"><br>
                                    </div><br><br>

                                    <!-- II. NATURE OF INSPECTION CONDUCTED -->
                                    <div class="section">
                                        <h2>II. NATURE OF INSPECTION CONDUCTED</h2><br>

                                        <input type="radio" name="inspection_type[]" value="construction"
                                            id="construction" class="single-checkbox">
                                        <label for="construction">Inspection during construction</label>

                                        <input type="radio" style="margin-left: 120px;" name="inspection_type[]"
                                            value="PEZA" id="PEZA" class="single-checkbox">
                                        <label for="PEZA">FSIC for Certificate of Annual Inspection
                                            (PEZA)</label><br>


                                        <input type="radio" name="inspection_type[]" value="fsic_occupancy">
                                        <label for="fsic_occupancy" id="fsic_occupancy" class="single-checkbox">FSIC for
                                            Certificate for Occupancy</label>

                                        <input type="radio" style="margin-left: 110px;" name="inspection_type[]"
                                            value="verification" id="verification" class="single-checkbox">
                                        <label for="verification"> Verification Inspection for
                                            Compliance</label><br>


                                        <input type="radio" name="inspection_type[]" value="fsic_new" id="fsic_new"
                                            class="single-checkbox">
                                        <label for="fsic_new"> FSIC for
                                            Business Permit (New)</label>

                                        <input type="radio" style="margin-left: 120px;" name="inspection_type[]"
                                            value="ntc" id="ntc" class="single-checkbox">
                                        <label for="ntc"> NTC /</label>
                                        <input type="radio" name="inspection_type[]" value="ntcv" id="ntcv"
                                            class="single-checkbox">
                                        <label for="ntcv"> NTCV /</label>
                                        <input type="radio" name="inspection_type[]" value="abatement" id="abatement"
                                            class="single-checkbox">
                                        <label for="abatement"> Abatement / </label>
                                        <input type="radio" name="inspection_type[]" value="closure" id="closure"
                                            class="single-checkbox">
                                        <label for="closure"> Closure </label><br>

                                        <input type="radio" name="inspection_type[]" value="fsic_renewal">
                                        <label for="fsic_renewal" id="fsic_renewal" class="single-checkbox"> FSIC for
                                            Business Permit (Renewal)</label>

                                        <input type="radio" style="margin-left: 105px;" name="inspection_type[]"
                                            value="disapproval" id="disapproval" class="single-checkbox">
                                        <label for="disapproval">Notice of
                                            Disapproval, if Certificate of Occupancy</label><br>

                                        <input type="radio" style="margin-left: 350px;" name="inspection_type[]"
                                            value="others">
                                        Others (Specify):
                                        <input type="text" name="others"><br><br>
                                    </div>

                                    <button type="button" onclick="nextSection(2)" class="btn btn-primary">Next</button>
                                </div>


                                <div id="section2" style="display:none;">
                                    <div class="section">
                                        <h2>III. GENERAL INFORMATION</h2>
                                        <br>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="business_name">Business Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_name"
                                                    value="<?php echo htmlspecialchars($businessName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="building_name">Building Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="building_name"
                                                    value="<?php echo htmlspecialchars($buildingName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="business_address">Business Address:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_address"
                                                    value="<?php echo htmlspecialchars($businessAddress); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="owner_name">Owner Name:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="owner_name"
                                                    value="<?php echo htmlspecialchars($ownerName); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="contact_number">Contact Number:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="contact_number"
                                                    value="<?php echo htmlspecialchars($contactNumber); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="business_nature">Business Nature:</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" name="business_nature"
                                                    value="<?php echo htmlspecialchars($businessNature); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="policy_number">Fire Insurance Policy No:</label>
                                                <input type="text" class="form-control" id="policy_number"
                                                    name="policy_number">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="pol_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="pol_date_issued"
                                                    name="pol_date_issued">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="fsic_number">FSIC No:</label>
                                                <input type="text" class="form-control" id="fsic_number"
                                                    name="fsic_number">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="fsic_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="fsic_date_issued"
                                                    name="fsic_date_issued">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="fsec_number">FSEC No:</label>
                                                <input type="text" class="form-control" id="fsec_number"
                                                    name="fsec_number">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="fsec_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="fsec_date_issued"
                                                    name="fsec_date_issued">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="building_permit">Building/Renovation Permit:</label>
                                                <input type="text" class="form-control" id="building_permit"
                                                    name="building_permit">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="rp_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="rp_date_issued"
                                                    name="rp_date_issued">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="bpermit_number">Business Permit No:</label>
                                                <input type="text" class="form-control" id="bpermit_number"
                                                    name="bpermit_number">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="bp_date_issued">Date Issued:</label>
                                                <input type="date" class="form-control" id="bp_date_issued"
                                                    name="bp_date_issued">
                                            </div>
                                        </div>


                                        <button type="button" onclick="nextSection(1)"
                                            class="btn btn-secondary">Previous</button>
                                        <button type="button" onclick="nextSection(3)"
                                            class="btn btn-primary">Next</button>
                                    </div>
                                </div>

                                <div id="section3" style="display:none;">
                                    <div class="section">
                                        <h2>IV. OTHER INFORMATION</h2>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <label for="occupancy_type">Occupancy Type:</label>
                                            </div>
                                            <div class=>
                                                <input type="text" class="form-control" name="occupancy_type"
                                                    value="<?php echo htmlspecialchars($occupancyType); ?>" readonly>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="section">
                                        <label for="construction_type" style="margin-right: 80px;">Construction
                                            Type:</label>

                                        <input type="radio" name="construction_type[]" value="timber" id="timber"
                                            class="single-checkbox">
                                        <label for="timber" style="margin-right: 100px;">Timber Framed and
                                            Walls</label>
                                        <input type="radio" name="construction_type[]" value="reinforced_concrete"
                                            id="reinforced_concrete" class="single-checkbox">
                                        Reinforced Concrete Framed with Masonry Walls
                                        <br>

                                        <input type="radio" style="margin-left: 205px;" name="construction_type[]"
                                            value="steel" id="steel" class="single-checkbox">
                                        <label for="steel" style="margin-right: 110px;">Steel
                                            Framed
                                            and Walls</label>
                                        <input type="radio" name="construction_type[]" value="mixed_construction"
                                            id="mixed_construction" class="single-checkbox">
                                        Mixed Construction<br><br>
                                    </div>


                                    <div class="section">

                                        <label for="floor_area">Total Floor Area:</label>
                                        <input type="text" id="floor_area" name="floor_area"
                                            value="<?php echo htmlspecialchars($totalArea); ?>" readonly> m²

                                        <label for="occupant_load" style="margin-left: 110px;">Occupant Load:</label>
                                        <input type="number" id="occupant_load" name="occupant_load"><br>

                                        <label for="building_height">Building Height:</label>
                                        <input type="number" id="building_height" name="building_height"
                                            value="<?php echo htmlspecialchars($buildingHeight); ?>" readonly> m

                                        <label for="Stories_num" style="margin-left: 110px; ">No of Stories:</label>
                                        <input type="number" id="Stories_num" name="Stories_num"
                                            value="<?php echo htmlspecialchars($numberOfFloors); ?>" readonly><br><br>

                                        <label for="Portion_Occupied">Portion
                                            Occupied:</label>
                                        <input type="number" id="Portion_Occupied:" name="Portion_Occupied">
                                        m

                                        <label for="mezzanine" style="margin-left: 110px; ">With Mezzanine:</label>
                                        <input type="radio" name="mezzanine_type[]" value="yes" id="yes"
                                            class="single-checkbox"> Yes /
                                        <input type="radio" name="mezzanine_type[]" value="no" id="no"
                                            class="single-checkbox"> No

                                        <label for="Handrails" style="margin-left: 110px; ">Handrails/Raillings
                                            Provided:</label>
                                        <input type="radio" name="Handrails_type[]" value="yes" id="yes"
                                            class="single-checkbox"> Yes /
                                        <input type="radio" name="Handrails_type[]" value="no" id="no"
                                            class="single-checkbox"> No<br><br>

                                        <button type="button" onclick="nextSection(2)"
                                            class="btn btn-secondary">Previous</button>
                                        <button type="button" onclick="nextSection(4)"
                                            class="btn btn-primary">Next</button>
                                    </div>
                                </div>

                                <!-- Means of Egress Section -->
                                <div id="section4" style="display:none;">
                                    <h2>V. Means of Egress Section </h2>
                                    <th colspan="4">A. EXIT ACCESS</th>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Horizontal components</th>
                                            <th>Actual Dim.</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>

                                        <tr>
                                            <td>Doors</td>
                                            <td><input type="text" class="form-control" name="doorsDim" id="doorsDim"
                                                    required>
                                            </td>
                                            <td><input type="radio" name="doors" value="passed"></td>
                                            <td><input type="radio" name="doors" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Corridors/ Hallways</td>
                                            <td><input type="text" class="form-control" name="corridorDim"
                                                    id="corridorDim" required>
                                            </td>
                                            <td><input type="radio" name="corri_hall" value="passed"></td>
                                            <td><input type="radio" name="corri_hall" value="failed"></td>
                                        </tr>

                                    </table>

                                    <th colspan="4">B. EXITS</th>

                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Horizontal components</th>
                                            <th>Actual Dim.</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                        <tr>
                                            <td>Exits Doors</td>
                                            <td><input type="text" class="form-control" name="exitsdoorsDim"
                                                    id="exitsdoorsDim" required>
                                            </td>
                                            <td><input type="radio" name="exitsdoors" value="passed"></td>
                                            <td><input type="radio" name="exitsdoors" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Stairs</td>
                                            <td><input type="text" class="form-control" name="stairsDim" id="stairsDim"
                                                    required>
                                            </td>
                                            <td><input type="radio" name="stairs" value="passed"></td>
                                            <td><input type="radio" name="stairs" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Horizontal Exits</td>
                                            <td><input type="text" class="form-control" name="horizontalexitDim"
                                                    id="horizontalexitDim" required>
                                            </td>
                                            <td><input type="radio" name="horizontalexit" value="passed"></td>
                                            <td><input type="radio" name="horizontalexit" value="failed"></td>
                                        </tr>
                                    </table>

                                    <!-- VI. SIGNS, LIGHTING, AND EXITS SIGNAGE -->
                                    <table class="table table-bordered">

                                        <h2>VI. SIGNS, LIGHTING, AND EXITS SIGNAGE</h2>

                                        <tr>
                                            <th>Components</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                        <tr>

                                            <td>Mininum letter height, 150mm; Width od Stroke, 19mm
                                            </td>
                                            <td><input type="radio" name="MLH" value="passed"></td>
                                            <td><input type="radio" name="MLH" value="failed"></td>
                                        </tr>
                                        <tr>

                                            <td>EXIT signs are posted along Exit acces, Exits and Exit discharge
                                            </td>
                                            <td><input type="radio" name="EED" value="passed"></td>
                                            <td><input type="radio" name="EED" value="failed"></td>
                                        </tr>
                                        <tr>

                                            <td>EXIT signs are properly illuminated.</td>
                                            <td><input type="radio" name="ESPI" value="passed"></td>
                                            <td><input type="radio" name="ESPI" value="failed"></td>
                                        </tr>

                                        <tr class="remarksSection" style="display: none;">
                                            <td>Remarks:</td>
                                            <td colspan="3"><textarea class="form-control" name="remarks"
                                                    rows="3"></textarea></td>
                                        </tr>
                                    </table>

                                    <button type="button" onclick="nextSection(3)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(5)" class="btn btn-primary">Next</button>
                                </div>


                                <div id="section5" style="display:none;">


                                    <div class="section">
                                        <h2>VII. HAZARD</h2>
                                        <label for="hazard_classification">Hazard Classification:</label>
                                        <input type="radio" name="hazard_classification" value="low"> Low
                                        <input type="radio" name="hazard_classification" value="ordinary">
                                        Ordinary
                                        <input type="radio" name="hazard_classification" value="high"> High

                                        <label for="storage_clearance">Storage Clearance Required:</label>
                                        <input type="radio" name="storage_clearance" value="yes"> Yes
                                        <input type="radio" name="storage_clearance" value="no"> No<br><br>

                                        <label for="FS_clearance">Fire Safety Clearance For Storage:</label>
                                        <input type="radio" name="FS_clearance" value="yes"> Yes
                                        <input type="radio" name="FS_clearance" value="no"> No

                                        <label for="fsdate_issued">Date Issued:</label>
                                        <input type="date" id="fsdate_issued" name="fsdate_issued">

                                        <label for="control_num">Control No.</label>
                                        <input type="text" id="control_num" name="control_num"><br><br>

                                        <label for="hazard_content">Hazard Content:</label>
                                        <input type="text" id="hazard_content" name="hazard_content">

                                        <label for="total_volume">Total Volume:</label>
                                        <input type="text" id="total_volume" name="total_volume"><br><br>

                                        <label for="location">Location :</label>
                                        <input type="text" id="location" name="location"><br><br>

                                        <th colspan="4">A. First Aid Fire Protection (Fire Extinguishers)</th>
                                        <br><br>

                                        <table class="table table-bordered">

                                            <tr>
                                                <th>Components</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                            </tr>
                                            <tr>

                                                <td>Clearance of stocks from the Ceiling
                                                </td>
                                                <td><input type="radio" name="CC" value="passed"></td>
                                                <td><input type="radio" name="CC" value="failed"></td>
                                            </tr>
                                            <tr>

                                                <td>Gas Detector and Shut Off Device for LPG
                                                </td>
                                                <td><input type="radio" name="GDD" value="passed"></td>
                                                <td><input type="radio" name="GDD" value="failed"></td>
                                            </tr>

                                            <tr id="remarksSection" style="display: none;">
                                                <td>Remarks:</td>
                                                <td colspan="3"><textarea class="form-control" name="remarks"
                                                        rows="3"></textarea>
                                                </td>
                                            </tr>
                                        </table>

                                        <label for="LPG">LPG Systems provided with Approved Plans, (if 300
                                            kgs.300GWC)</label>
                                        <input type="radio" name="LPG" value="yes"> Yes /
                                        <input type="radio" name="LPG" value="no"> No<br><br>

                                        <label for="ins_clearance">Installation Clearance </label>
                                        <input type="radio" name="ins_clearance" value="yes"> Yes
                                        <input type="radio" name="ins_clearance" value="no"> No

                                        <label for="isndate_issued">Date Issued:</label>
                                        <input type="date" id="isndate_issued" name="isndate_issued">

                                        <label for="inscontrol_num">Control No.</label>
                                        <input type="text" id="inscontrol_num" name="inscontrol_num"><br><br>

                                        <label for="ssmc">Stored in sealed metal Container</label>
                                        <input type="radio" name="ssmc" value="yes"> Yes
                                        <input type="radio" name="ssmc" value="no"> No

                                        <label for="NSS">Provided with "NO SMOKING" sign? </label>
                                        <input type="radio" name="NSS" value="yes"> Yes
                                        <input type="radio" name="NSS" value="no"> No

                                    </div>
                                    <button type="button" onclick="nextSection(4)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="button" onclick="nextSection(6)" class="btn btn-primary">Next</button>
                                </div>

                                <div id="section6" style="display:none;">
                                    <h2>VIII. FIRE PROTECTION</h2>
                                    <th colspan="4">A. First Aid Fire Protection (Fire Extinguishers)</th>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Item to Inspect</th>
                                            <th>Identification</th>
                                            <th>Passed</th>
                                            <th>Failed</th>
                                        </tr>
                                        <tr>
                                            <td>Fire Extinguisher Size</td>
                                            <td>Minimal sizes of fire extinguishers for the listed grades of hazards
                                                shall be provided on the basis of table 7 & 8 of RIRR of RA 9514.</td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="passed"></td>
                                            <td><input type="radio" name="fire_extinguisher_size" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Minimum number of Extinguisher</td>
                                            <td>The minimum number of extinguishers shall be sufficient to meet the
                                                requirements of table 7 & 8 of RIRR of RA 9514.</td>
                                            <td><input type="radio" name="minimum_number_extinguisher" value="passed">
                                            </td>
                                            <td><input type="radio" name="minimum_number_extinguisher" value="failed">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Location</td>
                                            <td>All extinguishers are in their proper location.</td>
                                            <td><input type="radio" name="location_status" value="passed"></td>
                                            <td><input type="radio" name="location_status" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Seals & Tags</td>
                                            <td>Extinguisher seals and tags are intact and extinguisher was serviced in
                                                the last 12 months.</td>
                                            <td><input type="radio" name="seals_tags" value="passed"></td>
                                            <td><input type="radio" name="seals_tags" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Markings</td>
                                            <td>Proper marking on extinguisher to indicate the type of fire the
                                                extinguisher can be used on.</td>
                                            <td><input type="radio" name="markings" value="passed"></td>
                                            <td><input type="radio" name="markings" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Condition</td>
                                            <td>No leaks, corrosion or other defects noticed.</td>
                                            <td><input type="radio" name="condition_status" value="passed"></td>
                                            <td><input type="radio" name="condition_status" value="failed"></td>
                                        </tr>
                                        <tr>
                                            <td>Pressure</td>
                                            <td>Pressure gauge arrow pointing in the “green” area indicating the
                                                extinguisher is fully charged.</td>
                                            <td><input type="radio" name="pressure" value="passed"></td>
                                            <td><input type="radio" name="pressure" value="failed"></td>
                                        </tr>
                                        <tr id="remarksSection" style="display: none;">
                                            <td>Remarks:</td>
                                            <td colspan="3"><textarea class="form-control" name="remarks"
                                                    rows="3"></textarea></td>
                                        </tr>
                                    </table>



                                    <label for="type">Type: </label>
                                    <input type="text" style="margin-right: 125px;" id="type" name="type">

                                    <label for="Quantity">Quantity: </label>
                                    <input type="text" style="margin-right: 125px;" id="Quantity" name="Quantity">

                                    <label for="Capacity">Capacity: </label>
                                    <input type="text" style="margin-right: 125px;" id="Capacity" name="Capacity"><br>


                                    <th colspan="4">B. Emergency Light Systems</th>

                                    <label for="ELS_provided">Provided: </label>
                                    <input type="radio" name="ELS_provided" value="yes"> Yes
                                    <input type="radio" name="ELS_provided" value="no"> No

                                    <label for="ELS_functional">Functional: </label>
                                    <input type="radio" name="ELS_functional" value="yes"> Yes
                                    <input type="radio" name="ELS_functional" value="no"> No <br>

                                    <label for="ELS_Locations">Locations: </label>
                                    <input type="radio" name="ELS_Locations" value="low"> Hallways
                                    <input type="radio" name="ELS_Locations" value="ordinary"> Exits Doors
                                    <input type="radio" name="ELS_Locations" value="high"> Stairways Landings
                                    <input type="text" name="ELS_others" placeholder="ELS_others (Specify)">
                                    Others
                                    Specify <br>

                                    <th colspan="4">C. Fire detection and alarm</th>

                                    <label for="FDA_provided">Provided: </label>
                                    <input type="radio" name="FDA_provided" value="yes"> Yes /
                                    <input type="radio" name="FDA_provided" value="no"> No
                                    <input type="radio" name="FDA_provided" value="smoke"> Smoke
                                    <input type="radio" name="FDA_provided" value="heat"> Heat
                                    <input type="radio" name="FDA_provided" value="manual"> Manual /
                                    <input type="radio" name="FDA_provided" value="automatic"> Automatic<br>


                                    <label for="FDA_functional">Functional: </label>
                                    <input type="radio" name="FDA_functional" value="yes"> Yes
                                    <input type="radio" name="FDA_functional" value="no"> No

                                    <label for="UPF">Unit per floor:</label>
                                    <input type="text" id="UPF" name="UPF">

                                    <label for="FDA_adequate">Adequate: </label>
                                    <input type="radio" name="FDA_adequate" value="yes"> Yes /
                                    <input type="radio" name="FDA_adequate" value="no"> No <br>

                                    <label for="LCP">Location of Control Panel( is Applicable):</label>
                                    <input type="text" id="LCP" name="LCP"><br><br>


                                    <button type="button" onclick="nextSection(5)"
                                        class="btn btn-secondary">Previous</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                <br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Optional JavaScript -->
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="submitSmall.js"></script>

        <script>
            // Handle checkbox change event
            $('input.failed').change(function () {
                var isAnyFailedChecked = $('input.failed:checked').length > 0;
                $('#remarksSection').toggle(isAnyFailedChecked);
            });

            // Handle the section navigation logic
            $(document).ready(function () {
                window.nextSection = function (section) {
                    // Hide all sections
                    $('[id^=section]').hide();
                    // Show the selected section
                    $('#section' + section).show();
                };

                // Get all tables and attach event listeners to "failed" radio buttons
                const tables = document.querySelectorAll('table');

                tables.forEach(table => {
                    const failedRadios = table.querySelectorAll('input[type="radio"][value="failed"]');

                    // Add event listeners to each "failed" radio button
                    failedRadios.forEach(radio => {
                        radio.addEventListener('change', () => {
                            // Check if any "failed" radio is checked within this table
                            const isFailed = Array.from(failedRadios).some(r => r.checked);

                            // Show or hide the remarks section based on the result
                            table.querySelector('.remarksSection').style.display = isFailed ? "table-row" : "none";
                        });
                    });
                });
            });
        </script>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
</body>

</html>