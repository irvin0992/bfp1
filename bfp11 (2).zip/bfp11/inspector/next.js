function nextSection(sectionNumber) {
    const currentSection = document.getElementById(`section${sectionNumber - 1}`);
    const nextSection = document.getElementById(`section${sectionNumber}`);
    
    // Select all required fields within the current section
    const requiredFields = currentSection.querySelectorAll('input[required]');
    let allFilled = true;

    // Check if all required fields are filled
    requiredFields.forEach(function(field) {
        if (!field.value) {
            allFilled = false;
            field.classList.add('error');  // Highlight the missing field
        } else {
            field.classList.remove('error');
        }
    });

    // If all fields are filled, proceed to the next section
    if (allFilled) {
        currentSection.style.display = 'none';
        nextSection.style.display = 'block';
    } else {
        Swal.fire({
            title: 'Incomplete Fields',
            text: 'Please fill out all required fields before proceeding.',
            icon: 'warning',
            confirmButtonText: 'OK'
        });
    }
}