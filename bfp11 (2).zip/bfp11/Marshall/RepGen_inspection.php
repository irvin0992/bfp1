<?php
require('../ReportGen/fpdf185/fpdf.php');
include('../connection.php');


// Assuming you have the database connection setup
$application_id = $_GET['app_id']; // Get application ID from URL or request

// Prepare the SQL statement with the specific application ID
$sql = "SELECT a.*, b.building_name, b.building_height, b.total_area, b.number_of_floors, 
               bu.business_name, bu.district, bu.barangay, o.owner_name, bu.occupancy_type, 
               o.contact_number, a.requirements_file, bu.business_nature
        FROM tbl_applications a
        INNER JOIN tbl_buildings b ON a.building_id = b.building_id
        INNER JOIN tbl_businesses bu ON a.business_id = bu.business_id
        INNER JOIN tbl_owners o ON a.owner_id = o.owner_id
        INNER JOIN tbl_inspections i ON a.application_id = i.application_id
        WHERE a.application_id = ?";  // The placeholder for the application ID

$stmt = $pdo->prepare($sql);
$stmt->execute([$application_id]);
$applicationData = $stmt->fetch();

// Fetch the business name from the result
$business_name = $applicationData['business_name'];

class PDF extends FPDF
{
    function Header()
    {
        $this->Ln(5); // Line break
        // DILG and BFP logos, adjusted for alignment
        $this->Image('../logos/dilg.png', 5, 10, 65); // DILG logo on the left
        $this->Image('../logos/BFP.png', 161, 18, 26); // BFP logo on the right

        // Set font for the title
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'Republic of the Philippines', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 5, 'Department of the Interior and Local Government', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 5, 'BUREAU OF FIRE PROTECTION', 0, 1, 'C');
        $this->SetFont('Arial', '', 12);
        $this->Cell(0, 5, 'Region 1', 0, 1, 'C');

        // Add lines with no extra space between
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');

        // Set no vertical spacing between the line and the description
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'District/Provincial Office', 0, 1, 'C'); // Set height to 0

        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Station', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Station Address', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 7, '____________________________________', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 5);
        $this->Cell(0, 0, 'Telephone No./Email Address', 0, 1, 'C');
    }

    function Footer()
    {
        // Set a thicker line width for the border
        $this->SetLineWidth(1.5); // Adjust the value for a thicker border
        $this->Rect(10, 10, 190, 277); // A4 page width = 210mm, height = 297mm, so margin is 10mm
    }
}



// Create a new PDF document with 1-inch margins on left and right
$pdf = new PDF('P', 'mm', 'A4');
$pdf->SetMargins(25.4, 10, 25.4); // Set 1-inch margins on the left and right, 10mm top and bottom
$pdf->AddPage();


$pdf->SetFont('Arial', 'B', 10);
$pdf->Ln(5); // Line break

$pdf->SetTextColor(255, 0, 0);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'FSIC NO. R__________________________', 0, 0, 'L');
$pdf->SetTextColor(0, 0, 0);
$pdf->Cell(0, 5, ' ___________________', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, 'Date              ', 0, 1, 'R');

$pdf->SetFont('Arial', 'B', 17);
$pdf->Ln(5);
$pdf->Cell(0, 10, 'FIRE SAFETY INSPECTION CERTIFICATE', 0, 1, 'C');

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, 'FOR CERTIFICATE OF OCCUPANCY', 0, 1, 'C');
$pdf->Cell(0, 5, 'FOR BUSINESS PERMIT (NEW/RENEWAL)', 0, 1, 'C');
$pdf->Cell(0, 5, 'OTHERS ____________________', 0, 1, 'C');

$pdf->Ln(5);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 5, 'TO WHOM IT MAY CONCERN:', 0, 1, 'L');
$pdf->Ln(5);

$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 5, '           By virtue of the provisions of RA 9514, otherwise known as the Fire Code of the Philippines of', 0, 'J');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 5, '2008,       the        application       for       FIRE       SAFETY      INSPECTION      CERTIFICATE      of', 0, 1, 'J');

$pdf->Cell(0, 5, '________________________________________________________________________________', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, $business_name, 0, 1, 'C');  // Print the fetched business name
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(0, 5, 'owned and managed by___________________________________________with postal address at', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Name of Owner/Representative)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(0, 5, '________________________________________________________________________________', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Address)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->MultiCell(0, 5, 'is hereby GRANTED after said building structure or facility has been duly inspected with the finding that it has fully complied with the fire safety and protection requirements of the Fire Code of the Philippines of 2008 and its Revised Implementing Rules and Regulations.', 0, 'J');

$pdf->Ln(2);

$pdf->Cell(0, 5, 'This certification is valid for___________________________________________________________', 0, 1, 'L');
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 3, '(Description)', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(0, 5, '________________________________________valid until_________________________________', 0, 1, 'L');
$pdf->SetFont('Arial', '', 10);
$pdf->SetFont('Arial', '', 10);

$pdf->Ln(5);

$pdf->MultiCell(0, 5, '                Violation of Fire Code provisions shall cause this certificate null and void after appropriate ', 0, 'J');
$pdf->MultiCell(0, 5, ' proceeding and hold the owner liable to the penalties provided for by the said Fire Code.', 0, 'J');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'RECOMMEND APPROVAL:                ', 0, 1, 'R');
$pdf->Cell(0, 7, '_______________________________', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 3, 'Chief, Fire Safety Enforcement Section', 0, 1, 'R');

$pdf->Ln(6);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 5, 'APPROVED:                                        ', 0, 1, 'R');
$pdf->Cell(0, 7, '_______________________________', 0, 1, 'R');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 3, 'City/Municipal Fire Marshal          ', 0, 1, 'R');

$pdf->Ln(5);

$pdf->SetFont('Arial', 'I', 10);
$pdf->MultiCell(0, 4, '                NOTE: "This Certificate does not take the place of any license required by law and is not ', 0, 'J');
$pdf->SetFont('Arial', 'I', 10);
$pdf->MultiCell(0, 4, 'transferable. Any change in the use of occupancy of the premises shall require a new certificate."', 0, 'R');


$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 7, 'THIS CERTIFICATE SHALL BE POSTED CONSPICUOUSLY', 0, 1, 'C');

$pdf->SetTextColor(255, 0, 0);

$pdf->SetFont('Arial', '', 7);
$pdf->MultiCell(0, 3, '"PAALALA: MAHIGPIT NA IPINAGBABAWAL NG PAMUNUAN NG BUREAU OF FIRE PROTECTION SA MGA KAWANI NITO ', 0, 'C');
$pdf->MultiCell(0, 5, 'ANG MAGBENTA O MAGREREKOMENDA NG ANOMANG BRAND NG FIRE EXTINGUISHER"', 0, 'C');

// Reset text color to black (optional if you want to go back to default color after this)
$pdf->SetTextColor(0, 0, 0);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 5, '"FIRE SAFETY IS OUR MAIN CONCERN"', 0, 1, 'C');

$pdf->Output('fire_safety_inspection_certificate.pdf', 'I');
?>