<?php
// Include necessary files
include('../connection.php');

// Fetch inspectors data
$inspectors = [];
$inspectors_result = $conn->query("SELECT id, name FROM tbl_users WHERE userlevel = 'Inspector'");

if ($inspectors_result && $inspectors_result->num_rows > 0) {
    while ($row = $inspectors_result->fetch_assoc()) {
        $inspectors[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fire Safety Applications</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../style.css">

    <style>
        .custom-btn {
            background-color: #b92828;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            border: none;
            border-radius: 5px;
        }

        .custom-btn i {
            color: white;
        }

        .status-pending {
            color: #b92828;
        }

        .status-ready {
            color: #1b5e20;
        }

        .status-reinspect {
            color: #ffa500;
        }

        .status-passed {
            color: #0000FF
        }

        .status-for-approval {
            color: #808080;
        }

        .approve-btn {
            background-color: #1b5e20;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            border: none;
            border-radius: 5px;
        }

        .approve-btn i {
            color: white;
        }

        .approve-btn.disabled {
            background-color: #d3d3d3;
            cursor: not-allowed;
        }
    </style>
    <style>
        .modal-header {
            background-color: #dc3545;
            border-bottom: none;
        }

        .modal-body {
            font-size: 1.1rem;
        }

        .modal-footer {
            border-top: none;
            justify-content: center;
        }

        .btn-outline-success,
        .btn-outline-info {
            width: 48%;
            padding: 15px;
            font-size: 1rem;
        }

        .btn-outline-success:hover,
        .btn-outline-info:hover {
            background-color: #28a745;
            color: #fff;
        }

        .btn-outline-info:hover {
            background-color: #17a2b8;
            color: #fff;
        }
    </style>
</head>

<body>
    <?php include('../session_validate.php'); ?>
    <?php include('../header/header2.php'); ?>
    <?php include('../sidebar/sidebarmarshall.php'); ?>

    <div class="dashboard-wrapper">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h5 class="mb-0 text-dark nav-user-name">
                            <i class="fa fa-user"></i>
                            <?php
                            if (isset($_SESSION['user_id'])) {
                                // Assuming you have a connection to the database in $conn
                                $user_id = intval($_SESSION['user_id']);

                                // Query to get the user details from tbl_users
                                $query = "SELECT fname, mname, lname FROM tbl_users WHERE id = ?";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $user_id); // Bind the user_id
                                $stmt->execute();
                                $result = $stmt->get_result();

                                if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc();
                                    // Sanitize the output to prevent XSS attacks
                                    $fname = htmlspecialchars($row['fname']);
                                    $mname = htmlspecialchars($row['mname']);
                                    $lname = htmlspecialchars($row['lname']);
                                    echo 'Welcome ' . $fname . ' ' . $mname . ' ' . $lname;
                                } else {
                                    echo 'Welcome, User';
                                }

                                $stmt->close();
                            }
                            ?>
                        </h5>

                        <h2 class="pageheader-title" style="margin-top:10px;">
                            <i class="fa fa-fw fa-file-word"></i> Inspection
                        </h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Inspection Checklist</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                var inspectors = <?php echo json_encode($inspectors); ?>;
            </script>

            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <h5 class="card-header">Inspection</h5>
                        <div class="card-body">
                            <div id="message"></div>
                            <div class="table-responsive">
                                <table id="inspectionTable" class="table table-striped table-bordered first">
                                    <thead>
                                        <tr>
                                            <th>Business Name</th>
                                            <th>Inspector Name</th>
                                            <th>Inspection Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Fetching inspections data including business name and status
                                        $inspection_result = $conn->query("
                                    SELECT i.*, b.business_name, r.FSIC_expiry, o.owner_name, bld.building_name, b.district, b.barangay, 
                                    bld.building_height, bld.total_area, bld.number_of_floors, b.occupancy_type, o.contact_number,r.email
                                    FROM tbl_inspections i
                                    INNER JOIN tbl_applications r ON i.application_id = r.application_id
                                    INNER JOIN tbl_businesses b ON r.business_id = b.business_id
                                    INNER JOIN tbl_owners o ON r.owner_id = o.owner_id
                                    INNER JOIN tbl_buildings bld ON r.building_id = bld.building_id
                                    WHERE i.status = 'For Approval'
                            ");

                                        // Check for errors in query execution
                                        if (!$inspection_result) {
                                            echo "<tr><td colspan='5'>Error: " . htmlspecialchars($conn->error) . "</td></tr>";
                                        } else if ($inspection_result->num_rows > 0) {
                                            while ($row = $inspection_result->fetch_assoc()) {
                                                $status = 'Passed'; // Set the status to For Approval
                                                $statusClass = ($status === 'Approved') ? 'status-approved' : 'status-for-approval';
                                                $buttonClass = ($status === 'Approved') ? 'disabled' : '';
                                                ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($row['business_name']); ?></td>
                                                        <td><?php echo htmlspecialchars($row['inspector_fname'] . ' ' . (!empty($row['inspector_mname']) ? $row['inspector_mname'] . ' ' : '') . $row['inspector_lname']); ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($row['inspection_date']); ?></td>
                                                        <td class="<?php echo $statusClass; ?>">
                                                        <?php echo htmlspecialchars($status); ?>
                                                        </td>
                                                        <td>

                                                            <button class="btn approve-btn <?php echo $buttonClass; ?>"
                                                                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                data-id="<?php echo $row['inspection_id']; ?>">
                                                                <i class="fa fa-check"></i> Approve
                                                            </button>
                                                            <button type="button"
                                                                style="background-color: #b92828; color: rgb(243, 245, 238); border-radius: 20px;"
                                                                class="btn btn-info view-details-btn" data-toggle="modal"
                                                                data-target="#viewDetailsModal"
                                                                data-registration-id="<?php echo $row['registration_id']; ?>"
                                                                data-business="<?php echo htmlspecialchars($row['business_name']); ?>"
                                                                data-building="<?php echo htmlspecialchars($row['building_name']); ?>"
                                                                data-address="<?php echo htmlspecialchars($row['district'] . ', ' . $row['barangay']); ?>"
                                                                data-owner="<?php echo htmlspecialchars($row['owner_name']); ?>"
                                                                data-occupancy="<?php echo htmlspecialchars($row['occupancy_type']); ?>"
                                                                data-contact="<?php echo htmlspecialchars($row['contact_number']); ?>"
                                                                data-buildingheight="<?php echo htmlspecialchars($row['building_height']); ?>"
                                                                data-totalarea="<?php echo htmlspecialchars($row['total_area']); ?>"
                                                                data-numberoffloors="<?php echo htmlspecialchars($row['number_of_floors']); ?>"
                                                                data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                                data-fsicexpiry="<?php echo htmlspecialchars($row['FSIC_expiry']); ?>"
                                                                data-status="<?php echo htmlspecialchars($row['status']); ?>">
                                                                View <!-- View icon -->
                                                            </button>

                                                        </td>
                                                    </tr>
                                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='5'>No records found</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Modal for View Details -->
                            <div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog"
                                aria-labelledby="viewDetailsModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header text-white">
                                            <h5 class="modal-title" id="viewDetailsModalLabel">View Inspection
                                                Details</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>Business Name:</strong> <span id="modalBusinessName"></span></p>
                                            <p><strong>Building Name:</strong> <span id="modalBuildingName"></span></p>
                                            <p><strong>Business Address:</strong> <span
                                                    id="modalBusinessAddress"></span></p>
                                            <p><strong>Owner Name:</strong> <span id="modalOwnerName"></span>
                                            </p>
                                            <p><strong>Occupancy Type:</strong> <span id="modalOccupancyType"></span>
                                            </p>
                                            <p><strong>Contact Number:</strong> <span id="modalContactNumber"></span>
                                            </p>
                                            <p><strong>Building Height:</strong> <span id="modalBuildingHeight"></span>
                                            </p>
                                            <p><strong>Total Area:</strong> <span id="modalTotalArea"></span>
                                            </p>
                                            <p><strong>Number of Floors:</strong> <span id="modalNumberOfFloors"></span>
                                            </p>
                                            <p><strong>Email:</strong> <span id="modalEmail"></span></p>
                                            <p><strong>Fsic Expiration:</strong> <span id="modalFsicexpiry"></span></p>

                                            <!-- Dynamic Buttons for Approve and Decline -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Optional JavaScript -->
            <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
            <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
            <script src="../assets/vendor/custom-js/jquery.multi-select.html"></script>
            <script src="../assets/libs/js/main-js.js"></script>
            <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
            <script src="../assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
            <script src="../assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
            <script src="../assets/vendor/datatables/js/data-table.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
            <script>
                $(document).ready(function () {
                    // When the #viewDetailsModal is shown, populate modal with data
                    $('#viewDetailsModal').on('show.bs.modal', function (event) {
                        var button = $(event.relatedTarget);
                        $('#modalBusinessName').text(button.data('business'));
                        $('#modalBuildingName').text(button.data('building'));
                        $('#modalBusinessAddress').text(button.data('address'));
                        $('#modalOwnerName').text(button.data('owner'));
                        $('#modalOccupancyType').text(button.data('occupancy'));
                        $('#modalContactNumber').text(button.data('contact'));
                        $('#modalBuildingHeight').text(button.data('buildingheight'));
                        $('#modalTotalArea').text(button.data('totalarea'));
                        $('#modalNumberOfFloors').text(button.data('numberoffloors'));
                        $('#modalEmail').text(button.data('email'));
                        $('#modalFsicexpiry').text(button.data('fsicexpiry'));
                    });

                    // Populate inspector options in the modal
                    inspectors.forEach(function (inspector) {
                        $('#inspectorName').append(new Option(inspector.name, inspector.name));
                    });

                    // Generate Report button click handler
                    $('#generateReportBtn').on('click', function () {
                        var fromDate = $('#fromDate').val();
                        var toDate = $('#toDate').val();
                        $('#startDate').val(fromDate);
                        $('#endDate').val(toDate);
                        $('#reportForm').submit();
                    });

                    // Edit button click handler to populate the modal with inspection data
                    $('#inspectionTable').on('click', '.edit-btn', function () {
                        var businessName = $(this).data('business-name');
                        var inspectorName = $(this).data('inspector-name');
                        var inspectionDate = $(this).data('inspection-date');
                        $('#businessName').val(businessName);
                        $('#inspectorName').val(inspectorName);
                        $('#inspectionDate').val(inspectionDate);
                        $('#editModal').modal('show');
                    });

                    // Approve button click handler
                    $('#inspectionTable').on('click', '.approve-btn', function () {
                        var id = $(this).data('id');
                        var row = $(this).closest('tr');

                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You are about to approve this inspection.",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, approve it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                $.ajax({
                                    url: 'approved_inspection.php',
                                    type: 'POST',
                                    data: { id: id },
                                    success: function (response) {
                                        if (response === 'success') {
                                            Swal.fire(
                                                'Approved!',
                                                'The inspection has been approved.',
                                                'success'
                                            ).then(() => {
                                                location.reload();
                                            });
                                        } else {
                                            Swal.fire(
                                                'Error!',
                                                'There was a problem approving the inspection.',
                                                'error'
                                            );
                                        }
                                    }
                                });
                            }
                        });
                    });

                    // Filter button click handler to filter table data based on date range
                    $('#filterBtn').on('click', function () {
                        var fromDate = $('#fromDate').val();
                        var toDate = $('#toDate').val();
                        console.log('From Date:', fromDate, 'To Date:', toDate);
                    });
                });
            </script>

</body>

</html>