<?php
include('../connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    // Start a transaction
    $conn->begin_transaction();

    // Update the status in tbl_inspections to 'Approved'
    $update_inspections_query = "UPDATE tbl_inspections SET status = 'Approved' WHERE inspection_id = ?";
    $stmt = $conn->prepare($update_inspections_query);

    if ($stmt) {
        // Bind the parameter and execute the statement
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            // Commit the transaction
            $conn->commit();
            echo 'success';
        } else {
            // Rollback the transaction if the update fails
            $conn->rollback();
            echo 'error';
        }
        // Close the statement
        $stmt->close();
    } else {
        // Rollback the transaction if the prepare fails
        $conn->rollback();
        echo 'error';
    }
} else {
    echo 'invalid';
}

$conn->close();
?>
