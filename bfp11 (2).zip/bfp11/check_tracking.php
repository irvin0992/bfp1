<?php
include('connection.php');

// Check if trackingNumber is set and not empty
if (isset($_POST['trackingNumber'])) {
    $trackingNumber = $_POST['trackingNumber'];

    // Query to check if tracking number exists in tbl_registrations
    $query = "SELECT * FROM tbl_registrations WHERE tracking_number = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $trackingNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there is a row returned
    if ($result->num_rows > 0) {
        // Tracking number exists
        $response = array('exists' => true);
    } else {
        // Tracking number does not exist
        $response = array('exists' => false);
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Handle case where trackingNumber is not set
    $response = array('exists' => false);
    header('Content-Type: application/json');
    echo json_encode($response);
}

$stmt->close();
$conn->close();
?>
