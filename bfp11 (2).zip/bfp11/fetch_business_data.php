<?php
// Include database connection
include 'connection.php';

// Check if trackingNumber is provided
if (isset($_GET['trackingNumber'])) {
    $trackingNumber = $_GET['trackingNumber'];

    // Prepare SQL statement to fetch business details and status
    $sql = "SELECT b.business_name, b.barangay, b.business_nature, b.occupancy_type, r.status
            FROM tbl_businesses b
            INNER JOIN tbl_registrations r ON b.business_id = r.business_id
            WHERE r.tracking_number = '$trackingNumber'";

    $result = $conn->query($sql);

    if ($result) {
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Output data as JSON
            echo json_encode($row);
        } else {
            // No matching records found
            echo json_encode(array('error' => 'No business details found for the provided tracking number.'));
        }
    } else {
        // Error executing the SQL query
        echo json_encode(array('error' => 'Error: ' . $conn->error));
    }
} else {
    // No tracking number provided
    echo json_encode(array('error' => 'Tracking number is not provided.'));
}

// Close connection
$conn->close();
?>
